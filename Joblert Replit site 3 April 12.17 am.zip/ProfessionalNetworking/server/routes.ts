import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertPostSchema, insertCommentSchema, insertConnectionSchema, 
  insertJobSchema, insertMessageSchema, insertNotificationSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // ===== POSTS ROUTES =====
  // Create a new post
  app.post("/api/posts", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const validatedData = insertPostSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (err) {
      next(err);
    }
  });
  
  // Get posts for feed
  app.get("/api/feed", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const posts = await storage.getFeedForUser(req.user.id);
      
      // Get author details, reactions and comments for each post
      const enrichedPosts = await Promise.all(posts.map(async (post) => {
        const author = await storage.getUser(post.userId);
        const reactions = await storage.getReactionsByPostId(post.id);
        const comments = await storage.getCommentsByPostId(post.id);
        return {
          ...post,
          author,
          reactions,
          comments,
          userReaction: await storage.getReactionByUserAndPost(req.user.id, post.id)
        };
      }));
      
      res.json(enrichedPosts);
    } catch (err) {
      next(err);
    }
  });
  
  // React to a post
  app.post("/api/posts/:id/react", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const postId = Number(req.params.id);
      const type = req.body.type || "like";
      
      // Validate post exists
      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Add reaction
      const reaction = await storage.createReaction({ 
        postId, 
        userId: req.user.id, 
        type 
      });
      
      // Create notification for post owner if not self
      if (post.userId !== req.user.id) {
        await storage.createNotification({
          userId: post.userId,
          type: "post_reaction",
          content: `${req.user.fullName} reacted to your post`,
          referenceId: postId
        });
      }
      
      res.status(201).json(reaction);
    } catch (err) {
      next(err);
    }
  });
  
  // Remove reaction from a post
  app.delete("/api/posts/:id/react", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const postId = Number(req.params.id);
      
      const result = await storage.removeReaction(req.user.id, postId);
      if (result) {
        res.sendStatus(204);
      } else {
        res.status(404).json({ message: "Reaction not found" });
      }
    } catch (err) {
      next(err);
    }
  });
  
  // Comment on a post
  app.post("/api/posts/:id/comment", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const postId = Number(req.params.id);
      
      // Validate post exists
      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const validatedData = insertCommentSchema.parse({
        postId,
        userId: req.user.id,
        content: req.body.content
      });
      
      const comment = await storage.createComment(validatedData);
      
      // Create notification for post owner if not self
      if (post.userId !== req.user.id) {
        await storage.createNotification({
          userId: post.userId,
          type: "comment",
          content: `${req.user.fullName} commented on your post`,
          referenceId: postId
        });
      }
      
      res.status(201).json(comment);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== CONNECTIONS ROUTES =====
  // Send connection request
  app.post("/api/connections", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const targetUserId = Number(req.body.userId);
      if (isNaN(targetUserId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const validatedData = {
        requesterId: req.user.id,
        requesteeId: targetUserId,
        status: "pending"
      };
      
      // Validate target user exists
      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const connection = await storage.createConnection(validatedData);
      
      // Create notification for connection request
      await storage.createNotification({
        userId: validatedData.requesteeId,
        type: "connection_request",
        content: `${req.user.fullName} sent you a connection request`,
        referenceId: connection.id
      });
      
      res.status(201).json(connection);
    } catch (err) {
      next(err);
    }
  });
  
  // Get connection requests
  app.get("/api/connections/requests", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const pendingConnections = await storage.getConnectionsByStatus(req.user.id, "pending");
      
      // Only include requests directed to the current user
      const receivedRequests = pendingConnections.filter(
        connection => connection.requesteeId === req.user.id
      );
      
      // Get requester details for each connection
      const requests = await Promise.all(
        receivedRequests.map(async (connection) => {
          const requester = await storage.getUser(connection.requesterId);
          const mutualCount = await storage.getMutualConnections(
            req.user.id, 
            connection.requesterId
          );
          
          return {
            connection,
            user: requester,
            mutualConnections: mutualCount
          };
        })
      );
      
      res.json(requests);
    } catch (err) {
      next(err);
    }
  });
  
  // Get sent connection requests
  app.get("/api/connections/sent", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const pendingConnections = await storage.getConnectionsByStatus(req.user.id, "pending");
      
      // Only include requests sent by the current user
      const sentRequests = pendingConnections.filter(
        connection => connection.requesterId === req.user.id
      );
      
      // Get requestee details for each connection
      const requests = await Promise.all(
        sentRequests.map(async (connection) => {
          const requestee = await storage.getUser(connection.requesteeId);
          const mutualCount = await storage.getMutualConnections(
            req.user.id, 
            connection.requesteeId
          );
          
          return {
            connection,
            user: requestee,
            mutualConnections: mutualCount
          };
        })
      );
      
      res.json(requests);
    } catch (err) {
      next(err);
    }
  });
  
  // Get connection suggestions
  app.get("/api/connections/suggestions", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const suggestedUsers = await storage.getConnectionSuggestions(req.user.id);
      
      // Get mutual connection count for each suggestion
      const suggestions = await Promise.all(
        suggestedUsers.map(async (user) => {
          const mutualCount = await storage.getMutualConnections(req.user.id, user.id);
          return {
            user,
            mutualConnections: mutualCount
          };
        })
      );
      
      res.json(suggestions);
    } catch (err) {
      next(err);
    }
  });
  
  // Get connections by status
  app.get("/api/connections/status/:status", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const status = req.params.status;
      const connections = await storage.getConnectionsByStatus(req.user.id, status);
      
      // Get user details for each connection
      const result = await Promise.all(
        connections.map(async (connection) => {
          const connectionUserId = 
            connection.requesterId === req.user.id 
              ? connection.requesteeId 
              : connection.requesterId;
          
          const user = await storage.getUser(connectionUserId);
          const mutualCount = await storage.getMutualConnections(req.user.id, connectionUserId);
          
          return { 
            connection, 
            user, 
            mutualConnections: mutualCount,
            isPending: connection.status === "pending",
            isRequester: connection.requesterId === req.user.id
          };
        })
      );
      
      res.json(result);
    } catch (err) {
      next(err);
    }
  });
  
  // Accept/reject connection request
  app.put("/api/connections/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const connectionId = Number(req.params.id);
      const action = req.body.action; // "accept" or "reject"
      
      if (action !== "accept" && action !== "reject") {
        return res.status(400).json({ message: "Invalid action" });
      }
      
      // Validate connection exists and user is the requestee
      const connection = await storage.getConnectionById(connectionId);
      if (!connection) {
        return res.status(404).json({ message: "Connection request not found" });
      }
      
      if (connection.requesteeId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to modify this connection" });
      }
      
      const status = action === "accept" ? "accepted" : "rejected";
      const updatedConnection = await storage.updateConnectionStatus(connectionId, status);
      
      // If accepted, create notification for the requester
      if (status === "accepted") {
        await storage.createNotification({
          userId: connection.requesterId,
          type: "connection_accepted",
          content: `${req.user.fullName} accepted your connection request`,
          referenceId: connectionId
        });
      }
      
      res.json(updatedConnection);
    } catch (err) {
      next(err);
    }
  });
  
  // Get connections (network)
  app.get("/api/connections", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const connections = await storage.getConnectionsByStatus(req.user.id, "accepted");
      
      // Get connection user details
      const networkConnections = await Promise.all(
        connections.map(async (connection) => {
          const connectionUserId = 
            connection.requesterId === req.user.id 
              ? connection.requesteeId 
              : connection.requesterId;
          
          const user = await storage.getUser(connectionUserId);
          return { connection, user };
        })
      );
      
      res.json(networkConnections);
    } catch (err) {
      next(err);
    }
  });
  
  // Get connection status with a specific user
  app.get("/api/connections/status/:userId", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const otherUserId = Number(req.params.userId);
      
      // Check if the user exists
      const user = await storage.getUser(otherUserId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Find any connection between the two users
      const connections = await storage.getConnectionsByUserId(req.user.id);
      const connection = connections.find(conn => 
        (conn.requesterId === req.user.id && conn.requesteeId === otherUserId) || 
        (conn.requesterId === otherUserId && conn.requesteeId === req.user.id)
      );
      
      if (!connection) {
        return res.json({ status: "none" });
      }
      
      // Determine the connection status and the user's role
      const isRequester = connection.requesterId === req.user.id;
      const status = {
        id: connection.id,
        status: connection.status,
        isRequester
      };
      
      res.json(status);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== JOBS ROUTES =====
  // Get all jobs
  app.get("/api/jobs", async (req, res, next) => {
    try {
      const query = req.query.q as string || "";
      const location = req.query.location as string;
      const remote = req.query.remote === "true";
      const type = req.query.type as string;
      const datePosted = req.query.datePosted ? Number(req.query.datePosted) : undefined;
      
      const filters: Record<string, any> = {};
      if (location) filters.location = location;
      if (remote) filters.remote = remote;
      if (type) filters.type = type;
      if (datePosted) filters.datePosted = datePosted;
      
      const jobs = await storage.searchJobs(query, filters);
      res.json(jobs);
    } catch (err) {
      next(err);
    }
  });
  
  // Get job by ID
  app.get("/api/jobs/:id", async (req, res, next) => {
    try {
      const jobId = Number(req.params.id);
      const job = await storage.getJobById(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Get company info (posted by user)
      const company = await storage.getUser(job.userId);
      
      res.json({ ...job, company });
    } catch (err) {
      next(err);
    }
  });
  
  // Create job (for employers)
  app.post("/api/jobs", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const validatedData = insertJobSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const job = await storage.createJob(validatedData);
      res.status(201).json(job);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== MESSAGING ROUTES =====
  // Get conversations
  app.get("/api/conversations", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const conversations = await storage.getConversationsForUser(req.user.id);
      res.json(conversations);
    } catch (err) {
      next(err);
    }
  });
  
  // Get messages between users
  app.get("/api/messages/:userId", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const otherUserId = Number(req.params.userId);
      if (isNaN(otherUserId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Validate other user exists
      const otherUser = await storage.getUser(otherUserId);
      if (!otherUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate users are connected
      const areConnected = await storage.areConnected(req.user.id, otherUserId);
      if (!areConnected) {
        return res.status(403).json({ message: "You need to be connected to view messages with this user" });
      }
      
      // Get messages
      const messages = await storage.getMessagesBetweenUsers(req.user.id, otherUserId);
      
      // Mark unread received messages as read
      await Promise.all(
        messages
          .filter(msg => msg.receiverId === req.user.id && !msg.read)
          .map(msg => storage.markMessageAsRead(msg.id))
      );
      
      res.json(messages);
    } catch (err) {
      next(err);
    }
  });
  
  // Send message
  app.post("/api/messages", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const validatedData = insertMessageSchema.parse({
        senderId: req.user.id,
        receiverId: req.body.receiverId,
        content: req.body.content
      });
      
      // Validate receiver exists
      const receiver = await storage.getUser(validatedData.receiverId);
      if (!receiver) {
        return res.status(404).json({ message: "Receiver not found" });
      }
      
      // Validate users are connected
      const areConnected = await storage.areConnected(req.user.id, validatedData.receiverId);
      if (!areConnected) {
        return res.status(403).json({ message: "You need to be connected to message this user" });
      }
      
      const message = await storage.createMessage(validatedData);
      
      // Create notification for receiver
      await storage.createNotification({
        userId: validatedData.receiverId,
        type: "message",
        content: `You received a message from ${req.user.fullName}`,
        referenceId: message.id
      });
      
      res.status(201).json(message);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== NOTIFICATIONS ROUTES =====
  // Get user notifications
  app.get("/api/notifications", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const notifications = await storage.getNotificationsByUserId(req.user.id);
      res.json(notifications);
    } catch (err) {
      next(err);
    }
  });
  
  // Mark notification as read
  app.put("/api/notifications/:id/read", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      const notificationId = Number(req.params.id);
      
      // Validate notification exists and belongs to user
      const notification = await storage.getNotificationById(notificationId);
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      if (notification.userId !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to modify this notification" });
      }
      
      const updatedNotification = await storage.markNotificationAsRead(notificationId);
      res.json(updatedNotification);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== USER ROUTES =====
  // Get all users (for search functionality)
  app.get("/api/users", async (req, res, next) => {
    try {
      // Get all users from storage
      const users = await Promise.all(
        Array(6).fill(0).map((_, i) => storage.getUser(i + 1))
      );
      res.json(users.filter(Boolean));
    } catch (err) {
      next(err);
    }
  });
  
  // Get user by username
  app.get("/api/users/:username", async (req, res, next) => {
    try {
      const { username } = req.params;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      next(err);
    }
  });
  
  // Get user by ID
  app.get("/api/users/by-id/:id", async (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      next(err);
    }
  });
  
  // ===== PROFILE ROUTES =====
  // Get user profile
  app.get("/api/profile/:username", async (req, res, next) => {
    try {
      const { username } = req.params;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get posts by this user
      const posts = await storage.getPostsByUserId(user.id);
      
      // If authenticated, check connection status
      let connectionStatus = null;
      if (req.isAuthenticated() && req.user.id !== user.id) {
        const connections = await storage.getConnectionsByUserId(req.user.id);
        const connection = connections.find(conn => 
          (conn.requesterId === req.user.id && conn.requesteeId === user.id) ||
          (conn.requesterId === user.id && conn.requesteeId === req.user.id)
        );
        
        connectionStatus = connection ? connection.status : null;
      }
      
      // Get connection count
      const connections = await storage.getConnectionsByStatus(user.id, "accepted");
      
      res.json({
        user,
        posts,
        connectionStatus,
        connectionCount: connections.length
      });
    } catch (err) {
      next(err);
    }
  });
  
  // Update user profile
  app.patch("/api/profile", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
      
      // Sanitize the input to only allow specific fields
      const allowedFields = ["fullName", "headline", "about", "website", "location", "industry", "email", "phoneNumber", "profileImage", "coverImage"];
      const updateData: Partial<any> = {};
      
      allowedFields.forEach(field => {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      });
      
      const updatedUser = await storage.updateUser(req.user.id, updateData);
      res.json(updatedUser);
    } catch (err) {
      if (err instanceof Error) {
        res.status(400).json({ message: err.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });
  
  // ===== SEARCH ROUTES =====
  // Search for users, jobs, and companies
  app.get("/api/search", async (req, res, next) => {
    try {
      const query = req.query.q as string || "";
      const tab = req.query.tab as string; // "people", "jobs", "companies", or undefined for all
      
      if (!query) {
        return res.json({ users: [], jobs: [], companies: [] });
      }
      
      const results: { users?: any[], jobs?: any[], companies?: any[] } = {};
      
      // Search for users (people)
      if (!tab || tab === "people") {
        const users = await storage.searchUsers(query);
        results.users = users;
      }
      
      // Search for jobs
      if (!tab || tab === "jobs") {
        const jobs = await storage.searchJobs(query);
        results.jobs = jobs;
      }
      
      // Search for companies (currently just returns an empty array)
      // In a real implementation, we would search a companies table
      if (!tab || tab === "companies") {
        results.companies = [];
      }
      
      res.json(results);
    } catch (err) {
      next(err);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
