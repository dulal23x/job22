import { 
  User, InsertUser, Post, InsertPost, 
  Reaction, InsertReaction, Comment, InsertComment,
  Connection, InsertConnection, Job, InsertJob,
  Message, InsertMessage, Notification, InsertNotification,
  users, posts, reactions, comments, connections, jobs, messages, notifications
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, sql } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Posts
  createPost(post: InsertPost): Promise<Post>;
  getPosts(): Promise<Post[]>;
  getPostById(id: number): Promise<Post | undefined>;
  getPostsByUserId(userId: number): Promise<Post[]>;
  getFeedForUser(userId: number): Promise<Post[]>;
  
  // Reactions
  createReaction(reaction: InsertReaction): Promise<Reaction>;
  getReactionsByPostId(postId: number): Promise<Reaction[]>;
  getReactionByUserAndPost(userId: number, postId: number): Promise<Reaction | undefined>;
  removeReaction(userId: number, postId: number): Promise<boolean>;
  
  // Comments
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByPostId(postId: number): Promise<Comment[]>;
  
  // Connections
  createConnection(connection: InsertConnection): Promise<Connection>;
  getConnectionById(id: number): Promise<Connection | undefined>;
  getConnectionsByUserId(userId: number): Promise<Connection[]>;
  getConnectionsByStatus(userId: number, status: string): Promise<Connection[]>;
  updateConnectionStatus(id: number, status: string): Promise<Connection | undefined>;
  getConnectionSuggestions(userId: number): Promise<User[]>;
  getMutualConnections(userId1: number, userId2: number): Promise<number>;
  areConnected(userId1: number, userId2: number): Promise<boolean>;
  
  // Jobs
  createJob(job: InsertJob): Promise<Job>;
  getJobs(): Promise<Job[]>;
  getJobById(id: number): Promise<Job | undefined>;
  searchJobs(query: string, filters?: Record<string, any>): Promise<Job[]>;
  
  // Messages
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]>;
  getConversationsForUser(userId: number): Promise<{user: User, lastMessage: Message}[]>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  
  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationById(id: number): Promise<Notification | undefined>;
  getNotificationsByUserId(userId: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  
  // Search
  searchUsers(query: string): Promise<User[]>;
  
  // Session store
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private reactions: Map<number, Reaction>;
  private comments: Map<number, Comment>;
  private connections: Map<number, Connection>;
  private jobs: Map<number, Job>;
  private messages: Map<number, Message>;
  private notifications: Map<number, Notification>;
  
  sessionStore: session.SessionStore;
  
  userId: number;
  postId: number;
  reactionId: number;
  commentId: number;
  connectionId: number;
  jobId: number;
  messageId: number;
  notificationId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.reactions = new Map();
    this.comments = new Map();
    this.connections = new Map();
    this.jobs = new Map();
    this.messages = new Map();
    this.notifications = new Map();
    
    this.userId = 1;
    this.postId = 1;
    this.reactionId = 1;
    this.commentId = 1;
    this.connectionId = 1;
    this.jobId = 1;
    this.messageId = 1;
    this.notificationId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Add some initial job data for demo
    this.seedJobs();
    // Add dummy user account
    this.seedUsers();
  }

  // Seed dummy user accounts
  private async seedUsers() {
    // Import needed functions for hashing the password
    const { scrypt, randomBytes } = await import("crypto");
    const { promisify } = await import("util");
    const scryptAsync = promisify(scrypt);
    
    // Hash the password
    const hashedPassword = async (password: string) => {
      const salt = randomBytes(16).toString("hex");
      const buf = (await scryptAsync(password, salt, 64)) as Buffer;
      return `${buf.toString("hex")}.${salt}`;
    };
    
    // Check if main user already exists to avoid duplicate seeding
    const existingUser = await this.getUserByUsername("dulal23");
    let mainUserId = 0;
    
    if (!existingUser) {
      // Create main user
      const mainUser: InsertUser = {
        username: "dulal23",
        password: await hashedPassword("dulal23"),
        email: "dulal23@example.com",
        fullName: "Dulal User",
        headline: "Software Developer at Xubly",
        profileImage: "/assets/profile1.svg",
        coverImage: "/assets/cover1.svg",
        about: "I'm a demo user account for testing purposes. Welcome to Xubly!"
      };
      
      const createdUser = await this.createUser(mainUser);
      mainUserId = createdUser.id;
    } else {
      mainUserId = existingUser.id;
    }
    
    // Create additional dummy users with their work experiences, education, and posts
    const dummyUsers = [
      {
        username: "sarahjones",
        password: await hashedPassword("password123"),
        email: "sarah@example.com",
        fullName: "Sarah Jones",
        headline: "UX Designer at Creative Studios",
        profileImage: null,
        coverImage: null,
        about: "Award-winning designer with 5+ years of experience in creating beautiful and user-friendly interfaces.",
        experiences: [
          {
            title: "Senior UX Designer",
            company: "Creative Studios",
            startDate: "2022-01",
            endDate: "",
            isCurrentPosition: true,
            location: "San Francisco, CA",
            description: "Leading the UX team in designing web and mobile applications for enterprise clients."
          },
          {
            title: "UX Designer",
            company: "DesignWorks",
            startDate: "2019-03",
            endDate: "2021-12",
            isCurrentPosition: false,
            location: "New York, NY",
            description: "Designed user interfaces for e-commerce and fintech applications."
          }
        ],
        education: [
          {
            school: "California Institute of Design",
            degree: "Master's",
            fieldOfStudy: "Interaction Design",
            startDate: "2017-09",
            endDate: "2019-05"
          }
        ],
        posts: [
          "Excited to share my latest UI design case study! I've been working on a financial app that makes complex data easy to understand. #UXDesign #FinTech",
          "Just wrapped up a workshop on designing for accessibility. Always inspired by how inclusive design benefits everyone, not just users with disabilities.",
          "Looking for recommendations on the best design systems? Currently evaluating options for our team at Creative Studios."
        ]
      },
      {
        username: "michaelwilson",
        password: await hashedPassword("password123"),
        email: "michael@example.com",
        fullName: "Michael Wilson",
        headline: "Software Engineer at TechGiant",
        profileImage: null,
        coverImage: null,
        about: "Full-stack developer with expertise in React, Node.js, and cloud infrastructure.",
        experiences: [
          {
            title: "Senior Software Engineer",
            company: "TechGiant",
            startDate: "2021-06",
            endDate: "",
            isCurrentPosition: true,
            location: "Seattle, WA",
            description: "Building scalable cloud applications with React, Node.js, and AWS."
          },
          {
            title: "Web Developer",
            company: "StartupInc",
            startDate: "2018-02",
            endDate: "2021-05",
            isCurrentPosition: false,
            location: "Portland, OR",
            description: "Developed and maintained e-commerce platform using React and Express."
          }
        ],
        education: [
          {
            school: "University of Washington",
            degree: "Bachelor's",
            fieldOfStudy: "Computer Science",
            startDate: "2014-09",
            endDate: "2018-05"
          }
        ],
        posts: [
          "Just published my first npm package for simplifying React state management! Check it out: github.com/michaelw/react-state-helper",
          "Interesting challenge today: optimizing database queries that were causing our app to slow down. Reduced load time by 40%!",
          "Anyone attending the JavaScript conference next month? Would love to connect with fellow developers. #WebDev #JavaScript"
        ]
      },
      {
        username: "emilynguyen",
        password: await hashedPassword("password123"),
        email: "emily@example.com",
        fullName: "Emily Nguyen",
        headline: "Product Manager at InnovateCo",
        profileImage: null,
        coverImage: null,
        about: "Strategic product leader focused on delivering value to users.",
        experiences: [
          {
            title: "Senior Product Manager",
            company: "InnovateCo",
            startDate: "2020-04",
            endDate: "",
            isCurrentPosition: true,
            location: "Austin, TX",
            description: "Leading product development for SaaS platform with 1M+ users."
          },
          {
            title: "Product Manager",
            company: "TechSolutions",
            startDate: "2017-06",
            endDate: "2020-03",
            isCurrentPosition: false,
            location: "Chicago, IL",
            description: "Managed development of mobile applications for enterprise clients."
          }
        ],
        education: [
          {
            school: "University of Michigan",
            degree: "MBA",
            fieldOfStudy: "Product Management",
            startDate: "2015-09",
            endDate: "2017-05"
          },
          {
            school: "University of California, Berkeley",
            degree: "Bachelor's",
            fieldOfStudy: "Business Administration",
            startDate: "2011-09",
            endDate: "2015-05"
          }
        ],
        posts: [
          "Thrilled to announce that our product has reached 1 million users today! So proud of our team's dedication and hard work.",
          "What product metrics do you track daily? I've found that focusing on a small set of actionable metrics is more effective than tracking everything.",
          "Just published an article on product-led growth strategies that worked for us at InnovateCo. Link in comments!"
        ]
      },
      {
        username: "alexsmith",
        password: await hashedPassword("password123"),
        email: "alex@example.com",
        fullName: "Alex Smith",
        headline: "Marketing Director at GrowthHackers",
        profileImage: null,
        coverImage: null,
        about: "Digital marketing expert specializing in growth strategies for startups.",
        experiences: [
          {
            title: "Marketing Director",
            company: "GrowthHackers",
            startDate: "2019-08",
            endDate: "",
            isCurrentPosition: true,
            location: "Boston, MA",
            description: "Leading marketing strategies that have achieved 3x growth for B2B clients."
          },
          {
            title: "Growth Marketing Manager",
            company: "MarketBoost",
            startDate: "2016-03",
            endDate: "2019-07",
            isCurrentPosition: false,
            location: "New York, NY",
            description: "Implemented data-driven marketing campaigns across multiple channels."
          }
        ],
        education: [
          {
            school: "Harvard University",
            degree: "Master's",
            fieldOfStudy: "Marketing Analytics",
            startDate: "2014-09",
            endDate: "2016-05"
          }
        ],
        posts: [
          "Our latest case study on content marketing ROI is now available. We achieved 300% increase in qualified leads for a SaaS client in just 3 months.",
          "Email marketing isn't dead! We've been experimenting with personalized sequences and seeing 45% open rates. What's working for you?",
          "Heading to the Digital Marketing Summit next week. Anyone else attending? Let's meet up! #MarketingTips #DigitalMarketing"
        ]
      },
      {
        username: "jessicapark",
        password: await hashedPassword("password123"),
        email: "jessica@example.com",
        fullName: "Jessica Park",
        headline: "Data Scientist at AnalyticsPro",
        profileImage: null,
        coverImage: null,
        about: "Data scientist with strong background in machine learning and statistical analysis.",
        experiences: [
          {
            title: "Lead Data Scientist",
            company: "AnalyticsPro",
            startDate: "2020-02",
            endDate: "",
            isCurrentPosition: true,
            location: "San Francisco, CA",
            description: "Developing machine learning models for predictive analytics in finance."
          },
          {
            title: "Data Analyst",
            company: "DataCorp",
            startDate: "2017-07",
            endDate: "2020-01",
            isCurrentPosition: false,
            location: "Los Angeles, CA",
            description: "Performed statistical analysis and built dashboards for business intelligence."
          }
        ],
        education: [
          {
            school: "Stanford University",
            degree: "PhD",
            fieldOfStudy: "Statistics",
            startDate: "2014-09",
            endDate: "2017-06"
          },
          {
            school: "MIT",
            degree: "Bachelor's",
            fieldOfStudy: "Computer Science",
            startDate: "2010-09",
            endDate: "2014-05"
          }
        ],
        posts: [
          "Just published research on applying reinforcement learning to portfolio optimization. Link to the paper in comments!",
          "Excited to be speaking at the AI Conference next month about practical applications of machine learning in business.",
          "Looking for recommendations on Python libraries for time series forecasting. Currently evaluating Prophet vs statsmodels."
        ]
      }
    ];
    
    for (const userData of dummyUsers) {
      const { experiences, education, posts, ...userDataWithoutExtras } = userData as any;
      const existingDummyUser = await this.getUserByUsername(userData.username);
      
      if (!existingDummyUser) {
        try {
          // Create the user
          const createdUser = await this.createUser(userDataWithoutExtras);
          
          // Create sample posts for each dummy user
          if (posts && Array.isArray(posts)) {
            for (const postContent of posts) {
              await this.createPost({
                content: postContent,
                mediaUrl: "",
                userId: createdUser.id
              });
            }
          }
          
          // Connect dummy users with main user (dulal23)
          if (mainUserId > 0) {
            const connection: InsertConnection = {
              userId1: mainUserId,
              userId2: createdUser.id,
              status: "accepted",
              initiatedBy: mainUserId
            };
            await this.createConnection(connection);
            
            // Create sample notification for the connection
            const notification: InsertNotification = {
              userId: createdUser.id,
              type: "connection_accepted",
              content: `Dulal User accepted your connection request`,
              relatedUserId: mainUserId,
              read: false
            };
            await this.createNotification(notification);
          }
        } catch (error) {
          console.error(`Error creating dummy user ${userData.username}:`, error);
        }
      }
    }
  }

  // Seed jobs for initial demo
  private seedJobs() {
    const sampleJobs: InsertJob[] = [
      {
        title: "Software Engineer",
        company: "TechStart Inc.",
        location: "San Francisco, CA (Remote)",
        description: "We're looking for a talented software engineer to join our team. You'll be working on cutting-edge web applications.",
        salary: "$120,000 - $150,000",
        type: "full-time",
        remote: true,
        userId: 1,
      },
      {
        title: "Product Designer",
        company: "DesignForward",
        location: "New York, NY",
        description: "Join our design team to create beautiful, intuitive user interfaces for our products.",
        salary: "$90,000 - $110,000",
        type: "full-time",
        remote: false,
        userId: 1,
      },
      {
        title: "Marketing Manager",
        company: "GrowthLabs",
        location: "Chicago, IL (Hybrid)",
        description: "We're seeking an experienced marketing manager to lead our campaigns and growth initiatives.",
        salary: "$85,000 - $100,000",
        type: "full-time",
        remote: false,
        userId: 1,
      }
    ];
    
    sampleJobs.forEach(job => this.createJob(job));
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, update: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...update };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Posts
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.postId++;
    const post: Post = { 
      ...insertPost, 
      id, 
      createdAt: new Date() 
    };
    this.posts.set(id, post);
    return post;
  }
  
  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
  
  async getPostById(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }
  
  async getPostsByUserId(userId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getFeedForUser(userId: number): Promise<Post[]> {
    // Get connected user IDs
    const connections = await this.getConnectionsByStatus(userId, "accepted");
    const connectedUserIds = connections.map(connection => 
      connection.requesterId === userId ? connection.requesteeId : connection.requesterId
    );
    
    // Include the user's own posts and posts from connections
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId || connectedUserIds.includes(post.userId))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  // Reactions
  async createReaction(insertReaction: InsertReaction): Promise<Reaction> {
    // Check if user already reacted to this post
    const existing = await this.getReactionByUserAndPost(
      insertReaction.userId, 
      insertReaction.postId
    );
    
    if (existing) {
      // Update reaction type if already exists
      const updated = { ...existing, type: insertReaction.type };
      this.reactions.set(existing.id, updated);
      return updated;
    }
    
    const id = this.reactionId++;
    const reaction: Reaction = { 
      ...insertReaction, 
      id, 
      createdAt: new Date() 
    };
    this.reactions.set(id, reaction);
    return reaction;
  }
  
  async getReactionsByPostId(postId: number): Promise<Reaction[]> {
    return Array.from(this.reactions.values())
      .filter(reaction => reaction.postId === postId);
  }
  
  async getReactionByUserAndPost(userId: number, postId: number): Promise<Reaction | undefined> {
    return Array.from(this.reactions.values())
      .find(reaction => reaction.userId === userId && reaction.postId === postId);
  }
  
  async removeReaction(userId: number, postId: number): Promise<boolean> {
    const reaction = await this.getReactionByUserAndPost(userId, postId);
    if (!reaction) return false;
    
    return this.reactions.delete(reaction.id);
  }
  
  // Comments
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.commentId++;
    const comment: Comment = { 
      ...insertComment, 
      id, 
      createdAt: new Date() 
    };
    this.comments.set(id, comment);
    return comment;
  }
  
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }
  
  // Connections
  async createConnection(insertConnection: InsertConnection): Promise<Connection> {
    // Check if connection already exists
    const existingConnection = Array.from(this.connections.values())
      .find(connection => 
        (connection.requesterId === insertConnection.requesterId && 
         connection.requesteeId === insertConnection.requesteeId) ||
        (connection.requesterId === insertConnection.requesteeId && 
         connection.requesteeId === insertConnection.requesterId)
      );
    
    if (existingConnection) {
      return existingConnection;
    }
    
    const id = this.connectionId++;
    const connection: Connection = { 
      ...insertConnection, 
      id, 
      status: "pending", 
      createdAt: new Date() 
    };
    this.connections.set(id, connection);
    return connection;
  }
  
  async getConnectionsByUserId(userId: number): Promise<Connection[]> {
    return Array.from(this.connections.values())
      .filter(connection => 
        connection.requesterId === userId || connection.requesteeId === userId
      );
  }
  
  async getConnectionsByStatus(userId: number, status: string): Promise<Connection[]> {
    return Array.from(this.connections.values())
      .filter(connection => 
        (connection.requesterId === userId || connection.requesteeId === userId) &&
        connection.status === status
      );
  }
  
  async updateConnectionStatus(id: number, status: string): Promise<Connection | undefined> {
    const connection = this.connections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { ...connection, status };
    this.connections.set(id, updatedConnection);
    return updatedConnection;
  }
  
  async getConnectionSuggestions(userId: number): Promise<User[]> {
    // Get IDs of already connected or pending users
    const connections = await this.getConnectionsByUserId(userId);
    const connectedUserIds = connections.map(connection => 
      connection.requesterId === userId ? connection.requesteeId : connection.requesterId
    );
    
    // Return users who are not connected yet
    return Array.from(this.users.values())
      .filter(user => user.id !== userId && !connectedUserIds.includes(user.id))
      .slice(0, 10); // Limit to 10 suggestions
  }
  
  async getMutualConnections(userId1: number, userId2: number): Promise<number> {
    const user1Connections = await this.getConnectionsByStatus(userId1, "accepted");
    const user2Connections = await this.getConnectionsByStatus(userId2, "accepted");
    
    const user1ConnectedIds = user1Connections.map(connection => 
      connection.requesterId === userId1 ? connection.requesteeId : connection.requesterId
    );
    
    const user2ConnectedIds = user2Connections.map(connection => 
      connection.requesterId === userId2 ? connection.requesteeId : connection.requesterId
    );
    
    // Find the intersection
    const mutualConnections = user1ConnectedIds.filter(id => user2ConnectedIds.includes(id));
    return mutualConnections.length;
  }
  
  async areConnected(userId1: number, userId2: number): Promise<boolean> {
    return Array.from(this.connections.values()).some(connection => 
      ((connection.requesterId === userId1 && connection.requesteeId === userId2) ||
       (connection.requesterId === userId2 && connection.requesteeId === userId1)) &&
      connection.status === "accepted"
    );
  }
  
  // Get connection by ID
  async getConnectionById(id: number): Promise<Connection | undefined> {
    return this.connections.get(id);
  }
  
  // Get notification by ID
  async getNotificationById(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  // Search users by query
  async searchUsers(query: string): Promise<User[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.users.values())
      .filter(user => 
        user.fullName.toLowerCase().includes(lowercaseQuery) ||
        user.username.toLowerCase().includes(lowercaseQuery) ||
        (user.headline && user.headline.toLowerCase().includes(lowercaseQuery))
      )
      .slice(0, 10);
  }
  
  // Jobs
  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.jobId++;
    const job: Job = { 
      ...insertJob, 
      id, 
      createdAt: new Date() 
    };
    this.jobs.set(id, job);
    return job;
  }
  
  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getJobById(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }
  
  async searchJobs(query: string, filters?: Record<string, any>): Promise<Job[]> {
    let filteredJobs = Array.from(this.jobs.values());
    
    if (query) {
      const lowercaseQuery = query.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.title.toLowerCase().includes(lowercaseQuery) ||
        job.company.toLowerCase().includes(lowercaseQuery) ||
        job.description.toLowerCase().includes(lowercaseQuery) ||
        job.location.toLowerCase().includes(lowercaseQuery)
      );
    }
    
    // Apply additional filters
    if (filters) {
      if (filters.location) {
        filteredJobs = filteredJobs.filter(job => 
          job.location.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      
      if (filters.remote) {
        filteredJobs = filteredJobs.filter(job => job.remote === true);
      }
      
      if (filters.type) {
        filteredJobs = filteredJobs.filter(job => job.type === filters.type);
      }
      
      if (filters.datePosted) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - filters.datePosted);
        
        filteredJobs = filteredJobs.filter(job => 
          new Date(job.createdAt) >= cutoffDate
        );
      }
    }
    
    return filteredJobs.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
  
  // Messages
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const message: Message = { 
      ...insertMessage, 
      id, 
      read: false, 
      createdAt: new Date() 
    };
    this.messages.set(id, message);
    return message;
  }
  
  async getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        (message.senderId === userId1 && message.receiverId === userId2) ||
        (message.senderId === userId2 && message.receiverId === userId1)
      )
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }
  
  async getConversationsForUser(userId: number): Promise<{user: User, lastMessage: Message}[]> {
    // Get all messages where user is sender or receiver
    const userMessages = Array.from(this.messages.values())
      .filter(message => message.senderId === userId || message.receiverId === userId);
    
    // Get unique conversation partners
    const conversationPartnerIds = new Set<number>();
    userMessages.forEach(message => {
      const partnerId = message.senderId === userId ? message.receiverId : message.senderId;
      conversationPartnerIds.add(partnerId);
    });
    
    // Get last message for each conversation
    const conversations = await Promise.all(
      Array.from(conversationPartnerIds).map(async (partnerId) => {
        const messages = await this.getMessagesBetweenUsers(userId, partnerId);
        const lastMessage = messages[messages.length - 1];
        const user = await this.getUser(partnerId);
        
        if (!user) {
          throw new Error(`User with id ${partnerId} not found`);
        }
        
        return { user, lastMessage };
      })
    );
    
    // Sort by last message date (most recent first)
    return conversations.sort((a, b) => 
      new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime()
    );
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, read: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  // Notifications
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationId++;
    const notification: Notification = { 
      ...insertNotification, 
      id, 
      read: false, 
      createdAt: new Date() 
    };
    this.notifications.set(id, notification);
    return notification;
  }
  
  async getNotificationsByUserId(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, read: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
}

// Database implementation
export class DatabaseStorage implements IStorage {
  sessionStore: any; // Fix TypeScript error with session.SessionStore
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
    
    // Seed initial data
    this.seedUsers();
    this.seedJobs();
  }

  // Seed dummy user accounts
  private async seedUsers() {
    try {
      // Import needed functions for hashing the password
      const { scrypt, randomBytes } = await import("crypto");
      const { promisify } = await import("util");
      const scryptAsync = promisify(scrypt);
      
      // Hash the password
      const hashedPassword = async (password: string) => {
        const salt = randomBytes(16).toString("hex");
        const buf = (await scryptAsync(password, salt, 64)) as Buffer;
        return `${buf.toString("hex")}.${salt}`;
      };
      
      // Check if main user already exists to avoid duplicate seeding
      const existingUser = await this.getUserByUsername("dulal23");
      let mainUserId = 0;
      
      if (!existingUser) {
        // Create main user
        const mainUser: InsertUser = {
          username: "dulal23",
          password: await hashedPassword("dulal23"),
          email: "dulal23@example.com",
          fullName: "Dulal User",
          headline: "Software Developer at Xubly",
          profileImage: "/assets/profile1.svg",
          coverImage: "/assets/cover1.svg",
          about: "I'm a demo user account for testing purposes. Welcome to Xubly!"
        };
        
        const createdUser = await this.createUser(mainUser);
        mainUserId = createdUser.id;
      } else {
        mainUserId = existingUser.id;
      }
      
      // Create additional dummy users
      const dummyUsers = [
        {
          username: "sarahjones",
          password: await hashedPassword("password123"),
          email: "sarah@example.com",
          fullName: "Sarah Jones",
          headline: "UX Designer at Creative Studios",
          profileImage: null,
          coverImage: null,
          about: "Award-winning designer with 5+ years of experience in creating beautiful and user-friendly interfaces."
        },
        {
          username: "michaelwilson",
          password: await hashedPassword("password123"),
          email: "michael@example.com",
          fullName: "Michael Wilson",
          headline: "Software Engineer at TechGiant",
          profileImage: null,
          coverImage: null,
          about: "Full-stack developer with expertise in React, Node.js, and cloud infrastructure."
        },
        {
          username: "emilynguyen",
          password: await hashedPassword("password123"),
          email: "emily@example.com",
          fullName: "Emily Nguyen",
          headline: "Product Manager at InnovateCo",
          profileImage: null,
          coverImage: null,
          about: "Strategic product leader focused on delivering value to users."
        },
        {
          username: "alexsmith",
          password: await hashedPassword("password123"),
          email: "alex@example.com",
          fullName: "Alex Smith",
          headline: "Marketing Director at GrowthHackers",
          profileImage: null,
          coverImage: null,
          about: "Digital marketing expert specializing in growth strategies for startups."
        },
        {
          username: "jessicapark",
          password: await hashedPassword("password123"),
          email: "jessica@example.com",
          fullName: "Jessica Park",
          headline: "Data Scientist at AnalyticsPro",
          profileImage: null,
          coverImage: null,
          about: "Data scientist with strong background in machine learning and statistical analysis."
        }
      ];
      
      for (const dummyUser of dummyUsers) {
        try {
          // Check if user already exists
          const existingDummyUser = await this.getUserByUsername(dummyUser.username);
          if (!existingDummyUser) {
            // Create the user
            const createdUser = await this.createUser(dummyUser);
            
            // Create sample posts for each dummy user
            const samplePosts = [
              {
                content: `Excited to share that I've joined the team at ${dummyUser.headline.split(' at ')[1]}! Looking forward to working with an amazing group of professionals.`,
                mediaUrl: "",
                userId: createdUser.id
              },
              {
                content: "Just finished an amazing project that really pushed my skills to the next level. It's incredible what a team can accomplish when everyone is aligned!",
                mediaUrl: "",
                userId: createdUser.id
              },
              {
                content: "What's your favorite productivity tool? I've been using a combination of Notion for documentation and Trello for task management.",
                mediaUrl: "",
                userId: createdUser.id
              }
            ];
            
            for (const post of samplePosts) {
              await this.createPost(post);
            }
            
            // Connect dummy users with main user (dulal23)
            if (mainUserId > 0) {
              const connection: InsertConnection = {
                requesterId: mainUserId,
                requesteeId: createdUser.id,
                status: "accepted",
                initiatedBy: mainUserId
              };
              await this.createConnection(connection);
              
              // Create sample notification for the connection
              const notification: InsertNotification = {
                userId: createdUser.id,
                type: "connection_accepted",
                content: `Dulal User accepted your connection request`,
                relatedUserId: mainUserId,
                read: false
              };
              await this.createNotification(notification);
            }
          }
        } catch (error) {
          console.error(`Error creating dummy user ${dummyUser.username}:`, error);
        }
      }
    } catch (error) {
      console.error("Error seeding users:", error);
    }
  }

  // Seed jobs for initial demo
  private async seedJobs() {
    try {
      // Check if we have any jobs
      const existingJobs = await db.select().from(jobs).limit(1);
      if (existingJobs.length === 0) {
        const sampleJobs: InsertJob[] = [
          {
            title: "Software Engineer",
            company: "TechStart Inc.",
            location: "San Francisco, CA (Remote)",
            description: "We're looking for a talented software engineer to join our team. You'll be working on cutting-edge web applications.",
            salary: "$120,000 - $150,000",
            type: "full-time",
            remote: true,
            userId: 1,
          },
          {
            title: "Product Designer",
            company: "DesignForward",
            location: "New York, NY",
            description: "Join our design team to create beautiful, intuitive user interfaces for our products.",
            salary: "$90,000 - $110,000",
            type: "full-time",
            remote: false,
            userId: 1,
          },
          {
            title: "Marketing Manager",
            company: "GrowthLabs",
            location: "Chicago, IL (Hybrid)",
            description: "We're seeking an experienced marketing manager to lead our campaigns and growth initiatives.",
            salary: "$85,000 - $100,000",
            type: "full-time",
            remote: false,
            userId: 1,
          }
        ];
        
        for (const job of sampleJobs) {
          await this.createJob(job);
        }
      }
    } catch (error) {
      console.error("Error seeding jobs:", error);
    }
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async updateUser(id: number, update: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(update)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  // Posts
  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db
      .insert(posts)
      .values({ ...insertPost })
      .returning();
    return post;
  }
  
  async getPosts(): Promise<Post[]> {
    return db
      .select()
      .from(posts)
      .orderBy(desc(posts.createdAt));
  }
  
  async getPostById(id: number): Promise<Post | undefined> {
    const [post] = await db
      .select()
      .from(posts)
      .where(eq(posts.id, id));
    return post;
  }
  
  async getPostsByUserId(userId: number): Promise<Post[]> {
    return db
      .select()
      .from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
  }
  
  async getFeedForUser(userId: number): Promise<Post[]> {
    // Get connected user IDs
    const connections = await this.getConnectionsByStatus(userId, "accepted");
    const connectedUserIds = connections.map(connection => 
      connection.requesterId === userId ? connection.requesteeId : connection.requesterId
    );
    
    // Include the user's own posts and posts from connections
    return db
      .select()
      .from(posts)
      .where(
        or(
          eq(posts.userId, userId),
          sql`${posts.userId} IN (${connectedUserIds.length > 0 ? connectedUserIds : [0]})`
        )
      )
      .orderBy(desc(posts.createdAt));
  }
  
  // Reactions
  async createReaction(insertReaction: InsertReaction): Promise<Reaction> {
    // Check if user already reacted to this post
    const existing = await this.getReactionByUserAndPost(
      insertReaction.userId, 
      insertReaction.postId
    );
    
    if (existing) {
      // Update reaction type if already exists
      const [updated] = await db
        .update(reactions)
        .set({ type: insertReaction.type })
        .where(eq(reactions.id, existing.id))
        .returning();
      return updated;
    }
    
    // Create new reaction
    const [reaction] = await db
      .insert(reactions)
      .values(insertReaction)
      .returning();
    return reaction;
  }
  
  async getReactionsByPostId(postId: number): Promise<Reaction[]> {
    return db
      .select()
      .from(reactions)
      .where(eq(reactions.postId, postId));
  }
  
  async getReactionByUserAndPost(userId: number, postId: number): Promise<Reaction | undefined> {
    const [reaction] = await db
      .select()
      .from(reactions)
      .where(
        and(
          eq(reactions.userId, userId),
          eq(reactions.postId, postId)
        )
      );
    return reaction;
  }
  
  async removeReaction(userId: number, postId: number): Promise<boolean> {
    const result = await db
      .delete(reactions)
      .where(
        and(
          eq(reactions.userId, userId),
          eq(reactions.postId, postId)
        )
      );
    return !!result;
  }
  
  // Comments
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values(insertComment)
      .returning();
    return comment;
  }
  
  async getCommentsByPostId(postId: number): Promise<Comment[]> {
    return db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(comments.createdAt);
  }
  
  // Connections
  async createConnection(insertConnection: InsertConnection): Promise<Connection> {
    // Check if connection already exists
    const [existingConnection] = await db
      .select()
      .from(connections)
      .where(
        or(
          and(
            eq(connections.requesterId, insertConnection.requesterId),
            eq(connections.requesteeId, insertConnection.requesteeId)
          ),
          and(
            eq(connections.requesterId, insertConnection.requesteeId),
            eq(connections.requesteeId, insertConnection.requesterId)
          )
        )
      );
    
    if (existingConnection) {
      return existingConnection;
    }
    
    // Create new connection
    const [connection] = await db
      .insert(connections)
      .values({ ...insertConnection, status: "pending" })
      .returning();
    return connection;
  }
  
  async getConnectionsByUserId(userId: number): Promise<Connection[]> {
    return db
      .select()
      .from(connections)
      .where(
        or(
          eq(connections.requesterId, userId),
          eq(connections.requesteeId, userId)
        )
      );
  }
  
  async getConnectionsByStatus(userId: number, status: string): Promise<Connection[]> {
    return db
      .select()
      .from(connections)
      .where(
        and(
          or(
            eq(connections.requesterId, userId),
            eq(connections.requesteeId, userId)
          ),
          eq(connections.status, status)
        )
      );
  }
  
  async updateConnectionStatus(id: number, status: string): Promise<Connection | undefined> {
    const [connection] = await db
      .update(connections)
      .set({ status })
      .where(eq(connections.id, id))
      .returning();
    return connection;
  }
  
  async getConnectionSuggestions(userId: number): Promise<User[]> {
    // Get IDs of already connected or pending users
    const userConnections = await this.getConnectionsByUserId(userId);
    const connectedUserIds = userConnections.map(connection => 
      connection.requesterId === userId ? connection.requesteeId : connection.requesterId
    );
    
    // Return users who are not connected yet
    return db
      .select()
      .from(users)
      .where(
        and(
          sql`${users.id} != ${userId}`,
          sql`${users.id} NOT IN (${connectedUserIds.length > 0 ? connectedUserIds : [0]})`
        )
      )
      .limit(10);
  }
  
  async getMutualConnections(userId1: number, userId2: number): Promise<number> {
    const user1Connections = await this.getConnectionsByStatus(userId1, "accepted");
    const user2Connections = await this.getConnectionsByStatus(userId2, "accepted");
    
    const user1ConnectedIds = user1Connections.map(connection => 
      connection.requesterId === userId1 ? connection.requesteeId : connection.requesterId
    );
    
    const user2ConnectedIds = user2Connections.map(connection => 
      connection.requesterId === userId2 ? connection.requesteeId : connection.requesterId
    );
    
    // Find the intersection
    const mutualConnections = user1ConnectedIds.filter(id => user2ConnectedIds.includes(id));
    return mutualConnections.length;
  }
  
  async areConnected(userId1: number, userId2: number): Promise<boolean> {
    const [connection] = await db
      .select()
      .from(connections)
      .where(
        and(
          or(
            and(
              eq(connections.requesterId, userId1),
              eq(connections.requesteeId, userId2)
            ),
            and(
              eq(connections.requesterId, userId2),
              eq(connections.requesteeId, userId1)
            )
          ),
          eq(connections.status, "accepted")
        )
      );
    return !!connection;
  }
  
  // Jobs
  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }
  
  async getJobs(): Promise<Job[]> {
    return db
      .select()
      .from(jobs)
      .orderBy(desc(jobs.createdAt));
  }
  
  async getJobById(id: number): Promise<Job | undefined> {
    const [job] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, id));
    return job;
  }
  
  async searchJobs(query: string, filters?: Record<string, any>): Promise<Job[]> {
    let jobsQuery = db
      .select()
      .from(jobs);
    
    // Base search query
    if (query) {
      const lowercaseQuery = query.toLowerCase();
      jobsQuery = jobsQuery.where(
        or(
          sql`lower(${jobs.title}) LIKE ${'%' + lowercaseQuery + '%'}`,
          sql`lower(${jobs.company}) LIKE ${'%' + lowercaseQuery + '%'}`,
          sql`lower(${jobs.description}) LIKE ${'%' + lowercaseQuery + '%'}`,
          sql`lower(${jobs.location}) LIKE ${'%' + lowercaseQuery + '%'}`
        )
      );
    }
    
    // Apply additional filters
    if (filters) {
      if (filters.location) {
        jobsQuery = jobsQuery.where(
          sql`lower(${jobs.location}) LIKE ${'%' + filters.location.toLowerCase() + '%'}`
        );
      }
      
      if (filters.remote) {
        jobsQuery = jobsQuery.where(eq(jobs.remote, true));
      }
      
      if (filters.type) {
        jobsQuery = jobsQuery.where(eq(jobs.type, filters.type));
      }
      
      if (filters.datePosted) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - filters.datePosted);
        
        jobsQuery = jobsQuery.where(
          sql`${jobs.createdAt} >= ${cutoffDate}`
        );
      }
    }
    
    return jobsQuery.orderBy(desc(jobs.createdAt));
  }
  
  // Messages
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values({ ...insertMessage, read: false })
      .returning();
    return message;
  }
  
  async getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(
        or(
          and(
            eq(messages.senderId, userId1),
            eq(messages.receiverId, userId2)
          ),
          and(
            eq(messages.senderId, userId2),
            eq(messages.receiverId, userId1)
          )
        )
      )
      .orderBy(messages.createdAt);
  }
  
  async getConversationsForUser(userId: number): Promise<{user: User, lastMessage: Message}[]> {
    // Get all messages for this user
    const userMessages = await db
      .select()
      .from(messages)
      .where(
        or(
          eq(messages.senderId, userId),
          eq(messages.receiverId, userId)
        )
      )
      .orderBy(desc(messages.createdAt));
    
    // Group by conversation partner
    const conversations: Map<number, {user: User, lastMessage: Message}> = new Map();
    
    for (const message of userMessages) {
      const partnerId = message.senderId === userId ? message.receiverId : message.senderId;
      
      if (!conversations.has(partnerId)) {
        const [partner] = await db
          .select()
          .from(users)
          .where(eq(users.id, partnerId));
        
        if (partner) {
          conversations.set(partnerId, {
            user: partner,
            lastMessage: message
          });
        }
      }
    }
    
    return Array.from(conversations.values());
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const [message] = await db
      .update(messages)
      .set({ read: true })
      .where(eq(messages.id, id))
      .returning();
    return message;
  }
  
  // Notifications
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values({ ...insertNotification, read: false })
      .returning();
    return notification;
  }
  
  async getNotificationsByUserId(userId: number): Promise<Notification[]> {
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const [notification] = await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return notification;
  }
  
  // Get connection by ID
  async getConnectionById(id: number): Promise<Connection | undefined> {
    const [connection] = await db
      .select()
      .from(connections)
      .where(eq(connections.id, id));
    return connection;
  }

  // Get notification by ID
  async getNotificationById(id: number): Promise<Notification | undefined> {
    const [notification] = await db
      .select()
      .from(notifications)
      .where(eq(notifications.id, id));
    return notification;
  }

  // Search users by query
  async searchUsers(query: string): Promise<User[]> {
    const lowercaseQuery = query.toLowerCase();
    return db
      .select()
      .from(users)
      .where(
        or(
          sql`LOWER(${users.fullName}) LIKE ${'%' + lowercaseQuery + '%'}`,
          sql`LOWER(${users.username}) LIKE ${'%' + lowercaseQuery + '%'}`,
          sql`LOWER(${users.headline}) LIKE ${'%' + lowercaseQuery + '%'}`
        )
      )
      .limit(10);
  }
}

// Use database storage
export const storage = new DatabaseStorage();
