import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle({ client: pool, schema });

const users = [
  { 
    id: 1, 
    username: "dulal23", 
    password: "c6b3af96",
    profileImage: "https://i.pravatar.cc/150?img=1"
  },
  { 
    id: 2, 
    username: "sarah_tech", 
    password: "hash123",
    profileImage: "https://i.pravatar.cc/150?img=2"
  },
  { 
    id: 3, 
    username: "mike_dev", 
    password: "hash456",
    profileImage: "https://i.pravatar.cc/150?img=3"
  }
];