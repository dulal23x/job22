import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";

interface JobItemProps {
  job: any;
  isLast?: boolean;
  showCompanyAvatar?: boolean;
}

export default function JobItem({ job, isLast = false, showCompanyAvatar = false }: JobItemProps) {
  const timePosted = job.createdAt 
    ? formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })
    : '';
  
  return (
    <Link href={`/jobs/view/${job.id}`}>
      <a className={`block px-4 py-3 hover:bg-neutral-50 ${!isLast ? 'border-b border-neutral-100' : ''}`}>
        <div className="flex">
          {showCompanyAvatar && (
            <div className="mr-3 flex-shrink-0">
              <div className="h-12 w-12 bg-neutral-200 rounded flex items-center justify-center text-neutral-500 font-semibold">
                {job.company?.charAt(0) || 'C'}
              </div>
            </div>
          )}
          
          <div className="flex-1">
            <h4 className="font-medium">{job.title}</h4>
            <div className="text-sm text-neutral-500">{job.company}</div>
            <div className="text-sm text-neutral-500">{job.location}</div>
            <div className="text-xs text-neutral-500 mt-1">
              <span>{timePosted}</span>
              {job.remote && (
                <span className="ml-2 text-secondary">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 inline mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                  </svg>
                  <span>Remote</span>
                </span>
              )}
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
