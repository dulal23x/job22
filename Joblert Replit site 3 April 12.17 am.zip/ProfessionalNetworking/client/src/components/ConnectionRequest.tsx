import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ConnectionRequestProps {
  user: any;
  mutualConnections: number;
  isLast?: boolean;
  isPending?: boolean;
  connectionId?: number;
}

export default function ConnectionRequest({ 
  user, 
  mutualConnections, 
  isLast = false,
  isPending = false,
  connectionId
}: ConnectionRequestProps) {
  const { toast } = useToast();
  const [status, setStatus] = useState<'pending' | 'accepted' | 'ignored' | null>(
    isPending ? 'pending' : null
  );
  
  // Connect mutation
  const connectMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest("POST", "/api/connections", { userId });
      return await res.json();
    },
    onSuccess: () => {
      setStatus('pending');
      toast({
        title: "Connection request sent",
        description: `Your connection request has been sent to ${user.fullName}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggestions"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to send connection request: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Respond to request mutation
  const respondMutation = useMutation({
    mutationFn: async ({ id, action }: { id: number, action: 'accept' | 'reject' }) => {
      const res = await apiRequest("PUT", `/api/connections/${id}`, { action });
      return await res.json();
    },
    onSuccess: (_, variables) => {
      setStatus(variables.action === 'accept' ? 'accepted' : 'ignored');
      toast({
        title: variables.action === 'accept' ? "Connection accepted" : "Connection ignored",
        description: variables.action === 'accept' 
          ? `You are now connected with ${user.fullName}` 
          : `Connection request from ${user.fullName} has been ignored`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to respond to connection request: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleConnect = () => {
    if (!user?.id) return;
    connectMutation.mutate(user.id);
  };
  
  const handleIgnore = () => {
    setStatus('ignored');
    
    // If it's a pending request that the user is ignoring
    if (isPending && connectionId) {
      respondMutation.mutate({ id: connectionId, action: 'reject' });
    } else {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggestions"] });
    }
  };
  
  const handleAccept = () => {
    if (!connectionId) return;
    respondMutation.mutate({ id: connectionId, action: 'accept' });
  };
  
  if (status === 'ignored') {
    return null;
  }
  
  return (
    <div className={`px-4 py-3 ${!isLast ? 'border-b border-neutral-100' : ''}`}>
      <div className="flex">
        <Link href={`/in/${user.username}`} className="flex-shrink-0">
          <Avatar className="h-14 w-14">
            {user.profileImage ? (
              <AvatarImage src={user.profileImage} alt={user.fullName} />
            ) : (
              <AvatarFallback>{user.fullName.charAt(0)}</AvatarFallback>
            )}
          </Avatar>
        </Link>
        
        <div className="ml-3 flex-1">
          <Link href={`/in/${user.username}`} className="font-medium hover:text-primary hover:underline">
            {user.fullName}
          </Link>
          <div className="text-neutral-500 text-sm">{user.headline || user.username}</div>
          <div className="text-xs text-neutral-500 mt-1">
            {mutualConnections > 0 ? (
              <span>{mutualConnections} mutual connection{mutualConnections !== 1 ? 's' : ''}</span>
            ) : (
              <span>No mutual connections</span>
            )}
          </div>
          
          {status === 'accepted' ? (
            <div className="mt-2 text-xs text-secondary font-medium">
              ✓ Connected
            </div>
          ) : status === 'pending' ? (
            <div className="mt-2 text-xs text-secondary font-medium">
              Pending
            </div>
          ) : isPending ? (
            <div className="mt-2 flex">
              <Button 
                variant="default" 
                size="sm" 
                className="flex-1 mr-1"
                onClick={handleAccept}
                disabled={respondMutation.isPending}
              >
                Accept
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 ml-1"
                onClick={handleIgnore}
                disabled={respondMutation.isPending}
              >
                Ignore
              </Button>
            </div>
          ) : (
            <div className="mt-2 flex">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 mr-1 border-primary text-primary hover:bg-primary-light"
                onClick={handleIgnore}
              >
                Ignore
              </Button>
              
              <Button 
                variant="default" 
                size="sm" 
                className="flex-1 ml-1"
                onClick={handleConnect}
                disabled={connectMutation.isPending}
              >
                Connect
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
