import { User } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ConversationItemProps {
  user: User;
  lastMessage?: {
    content: string;
    timestamp: string;
    isRead: boolean;
  };
  isActive: boolean;
  onClick: () => void;
}

function ConversationItem({ user, lastMessage, isActive, onClick }: ConversationItemProps) {
  return (
    <div 
      className={cn(
        "p-3 flex items-center gap-3 hover:bg-neutral-100 cursor-pointer transition-colors",
        isActive && "bg-neutral-100"
      )}
      onClick={onClick}
    >
      <Avatar>
        <AvatarImage src={user.profileImage || ""} alt={user.fullName} />
        <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center">
          <h3 className="font-medium truncate">{user.fullName}</h3>
          {lastMessage && (
            <span className="text-xs text-neutral-500">{formatTime(lastMessage.timestamp)}</span>
          )}
        </div>
        {lastMessage && (
          <p className={cn(
            "text-sm truncate", 
            !lastMessage.isRead ? "font-medium text-neutral-900" : "text-neutral-500"
          )}>
            {lastMessage.content}
          </p>
        )}
      </div>
    </div>
  );
}

interface ConversationListProps {
  conversations: Array<{
    user: User;
    lastMessage?: {
      content: string;
      timestamp: string;
      isRead: boolean;
    };
  }>;
  activeConversation: User | null;
  onSelectConversation: (user: User) => void;
}

export default function ConversationList({ 
  conversations, 
  activeConversation, 
  onSelectConversation 
}: ConversationListProps) {
  return (
    <ScrollArea className="h-[calc(100vh-240px)]">
      {conversations.map(({ user, lastMessage }) => (
        <ConversationItem
          key={user.id}
          user={user}
          lastMessage={lastMessage}
          isActive={activeConversation?.id === user.id}
          onClick={() => onSelectConversation(user)}
        />
      ))}
    </ScrollArea>
  );
}

// Helper functions
function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

function formatTime(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  // If less than a day, show time
  if (diff < 24 * 60 * 60 * 1000) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  
  // If within a week, show day name
  if (diff < 7 * 24 * 60 * 60 * 1000) {
    return date.toLocaleDateString([], { weekday: 'short' });
  }
  
  // Otherwise show date
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}