import { Link } from "wouter";

export default function Header() {
  return (
    <header className="sticky top-0 bg-white border-b border-neutral-200 shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14 md:h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <h1 className="text-primary font-bold text-2xl">xubly</h1>
            </Link>
          </div>
          <nav className="flex space-x-4">
            <Link href="/jobs" className="px-4 py-2 bg-blue-500 text-white rounded">Find Jobs</Link>
            <Link href="/post-job" className="px-4 py-2 bg-blue-500 text-white rounded">Post Jobs</Link>
            <Link href="/signin" className="px-4 py-2 bg-blue-500 text-white rounded">Sign In</Link>
            <Link href="/join" className="px-4 py-2 bg-blue-500 text-white rounded">Join Now</Link>
          </nav>
        </div>
      </div>
    </header>
  );
}