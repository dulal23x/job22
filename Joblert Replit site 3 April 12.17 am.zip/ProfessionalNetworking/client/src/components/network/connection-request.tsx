import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { BriefcaseIcon, UsersIcon } from "lucide-react";

interface ConnectionRequestProps {
  user: User;
  mutualConnections: number;
  isLast?: boolean;
  isPending?: boolean;
  connectionId?: number;
}

export default function ConnectionRequest({
  user,
  mutualConnections,
  isLast = false,
  isPending = false,
  connectionId
}: ConnectionRequestProps) {
  const { toast } = useToast();

  const acceptConnectionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/connections/${connectionId}`, {
        status: "accepted"
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/status/accepted"] });
      toast({
        title: "Connection accepted",
        description: `You are now connected with ${user.fullName}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to accept connection",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const ignoreConnectionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/connections/${connectionId}`, {
        status: "ignored"
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/pending"] });
      toast({
        title: "Connection ignored",
        description: `You ignored the connection request from ${user.fullName}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to ignore connection",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  return (
    <Card className={`shadow-sm ${isLast ? "" : "mb-4"}`}>
      <CardContent className="p-4">
        <div className="flex items-start">
          <Avatar className="h-14 w-14 border mr-3">
            <AvatarImage src={user.profileImage || undefined} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {user.fullName ? user.fullName.charAt(0) : "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex flex-col">
              <h3 className="font-semibold text-sm hover:text-primary hover:underline cursor-pointer">
                {user.fullName}
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2">{user.headline || ""}</p>
              
              <div className="flex items-center mt-1 text-xs text-neutral-500">
                {mutualConnections > 0 && (
                  <div className="flex items-center mr-3">
                    <UsersIcon className="h-3 w-3 mr-1" />
                    <span>{mutualConnections} mutual connection{mutualConnections > 1 ? 's' : ''}</span>
                  </div>
                )}
                {user.headline && user.headline.includes("at") && (
                  <div className="flex items-center">
                    <BriefcaseIcon className="h-3 w-3 mr-1" />
                    <span>{user.headline.split(" at ")[1]}</span>
                  </div>
                )}
              </div>
              
              {isPending ? (
                <div className="mt-3">
                  <div className="text-xs text-neutral-500 italic">Pending...</div>
                </div>
              ) : (
                <div className="mt-3 flex gap-2">
                  <Button 
                    variant="default"
                    size="sm"
                    className="flex-1 rounded-full"
                    onClick={() => acceptConnectionMutation.mutate()}
                    disabled={acceptConnectionMutation.isPending || ignoreConnectionMutation.isPending}
                  >
                    Accept
                  </Button>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="flex-1 rounded-full"
                    onClick={() => ignoreConnectionMutation.mutate()}
                    disabled={acceptConnectionMutation.isPending || ignoreConnectionMutation.isPending}
                  >
                    Ignore
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}