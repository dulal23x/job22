
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BriefcaseIcon, UsersIcon } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ConnectionSuggestionProps {
  user: any;
  mutualConnections: number;
  isLast?: boolean;
}

export default function ConnectionSuggestion({ user, mutualConnections, isLast = false }: ConnectionSuggestionProps) {
  const { toast } = useToast();
  const [isPending, setIsPending] = useState(false);

  const sendConnectionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/connections", { userId: user.id });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to send connection request");
      }
      return await res.json();
    },
    onSuccess: () => {
      setIsPending(true);
      toast({
        title: "Connection request sent",
        description: `Your connection request has been sent to ${user.fullName}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggested"] });
    },
    onError: (error: Error) => {
      setIsPending(false);
      toast({
        title: "Failed to send connection request",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  return (
    <Card className={`shadow-sm ${isLast ? "" : "mb-4"}`}>
      <CardContent className="p-4">
        <div className="flex items-start">
          <Avatar className="h-14 w-14 border mr-3">
            <AvatarImage src={user.profileImage || undefined} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {user.fullName ? user.fullName.charAt(0) : "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex flex-col">
              <h3 className="font-semibold text-sm hover:text-primary hover:underline cursor-pointer">
                {user.fullName}
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2">{user.headline || ""}</p>
              
              <div className="flex items-center mt-1 text-xs text-neutral-500">
                {mutualConnections > 0 && (
                  <div className="flex items-center mr-3">
                    <UsersIcon className="h-3 w-3 mr-1" />
                    <span>{mutualConnections} mutual connection{mutualConnections > 1 ? 's' : ''}</span>
                  </div>
                )}
                {user.headline && user.headline.includes("at") && (
                  <div className="flex items-center">
                    <BriefcaseIcon className="h-3 w-3 mr-1" />
                    <span>{user.headline.split(" at ")[1]}</span>
                  </div>
                )}
              </div>
              
              <div className="mt-3">
                <Button 
                  variant={isPending ? "outline" : "default"}
                  size="sm"
                  className="w-full rounded-full"
                  onClick={() => sendConnectionMutation.mutate()}
                  disabled={isPending || sendConnectionMutation.isPending}
                >
                  {isPending ? "Pending" : "Connect"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
