import { useState } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { 
  MoreHorizontal,
  ThumbsUp,
  MessageSquare,
  Share,
  Send,
  Globe,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";

interface PostItemProps {
  post: any;
}

export default function PostItem({ post }: PostItemProps) {
  const { user } = useAuth();
  const [comment, setComment] = useState("");
  const [showComments, setShowComments] = useState(false);
  
  // Parse hashtags in content
  const renderContent = (content: string) => {
    const hashtagRegex = /#(\w+)/g;
    const parts = content.split(hashtagRegex);
    
    return parts.map((part, index) => {
      // Every odd index will be the hashtag match
      if (index % 2 === 1) {
        return (
          <Link key={index} href={`/hashtag/${part}`} className="text-primary hover:underline">
            #{part}
          </Link>
        );
      }
      
      // Line breaks
      return part.split('\n').map((line, i) => (
        <span key={`${index}-${i}`}>
          {i > 0 && <br />}
          {line}
        </span>
      ));
    });
  };
  
  // Handle like/unlike
  const reactionMutation = useMutation({
    mutationFn: async ({ postId, action }: { postId: number, action: 'like' | 'unlike' }) => {
      if (action === 'like') {
        const res = await apiRequest("POST", `/api/posts/${postId}/react`, { type: "like" });
        return await res.json();
      } else {
        const res = await apiRequest("DELETE", `/api/posts/${postId}/react`);
        return null;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
    },
  });
  
  const handleLikeToggle = () => {
    if (!user) return;
    
    const userReaction = post.userReaction;
    reactionMutation.mutate({
      postId: post.id,
      action: userReaction ? 'unlike' : 'like'
    });
  };
  
  // Handle comment submission
  const commentMutation = useMutation({
    mutationFn: async ({ postId, content }: { postId: number, content: string }) => {
      const res = await apiRequest("POST", `/api/posts/${postId}/comment`, { content });
      return await res.json();
    },
    onSuccess: () => {
      setComment("");
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
    },
  });
  
  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim() || !user) return;
    
    commentMutation.mutate({
      postId: post.id,
      content: comment
    });
  };
  
  if (!post || !post.author) return null;
  
  const isLiked = post.userReaction?.type === "like";
  const likesCount = post.reactions?.length || 0;
  const commentsCount = post.comments?.length || 0;
  const timeAgo = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });
  
  return (
    <div className="bg-white rounded-lg border border-neutral-200 mb-4">
      {/* Post Header */}
      <div className="p-4">
        <div className="flex">
          <Link href={`/in/${post.author.username}`} className="flex-shrink-0">
            <Avatar className="h-12 w-12">
              {post.author.profileImage ? (
                <AvatarImage src={post.author.profileImage} alt={post.author.fullName} />
              ) : (
                <AvatarFallback>{post.author.fullName.charAt(0)}</AvatarFallback>
              )}
            </Avatar>
          </Link>
          
          <div className="ml-3 flex-1">
            <div className="flex items-center justify-between">
              <div>
                <Link href={`/in/${post.author.username}`} className="font-semibold hover:text-primary hover:underline">
                  {post.author.fullName}
                </Link>
                <div className="text-neutral-500 text-sm">
                  {post.author.headline || post.author.username}
                </div>
              </div>
              
              <div className="text-neutral-400">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                      <MoreHorizontal className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>Save post</DropdownMenuItem>
                    {user?.id === post.author.id && (
                      <DropdownMenuItem className="text-red-500">Delete post</DropdownMenuItem>
                    )}
                    <DropdownMenuItem>Report post</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
            
            <div className="text-neutral-500 text-xs mt-1 flex items-center">
              <span>{timeAgo}</span>
              <span className="mx-1">•</span>
              <Globe className="h-3 w-3" />
            </div>
          </div>
        </div>
        
        {/* Post Content */}
        <div className="mt-3">
          <p>{renderContent(post.content)}</p>
        </div>
      </div>
      
      {/* Post Image */}
      {post.mediaUrl && (
        <div className="border-t border-neutral-100">
          <img 
            src={post.mediaUrl} 
            alt="Post media" 
            className="w-full object-cover max-h-96"
          />
        </div>
      )}
      
      {/* Engagement Stats */}
      {(likesCount > 0 || commentsCount > 0) && (
        <div className="px-4 py-2 border-t border-neutral-100">
          <div className="flex items-center justify-between text-sm text-neutral-500">
            <div className="flex items-center">
              {likesCount > 0 && (
                <>
                  <span className="flex -space-x-1 mr-1">
                    <span className="bg-primary text-white rounded-full h-4 w-4 flex items-center justify-center text-xs">
                      <ThumbsUp className="h-2 w-2" />
                    </span>
                  </span>
                  <span>{likesCount}</span>
                </>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              {commentsCount > 0 && (
                <button 
                  className="hover:underline" 
                  onClick={() => setShowComments(prev => !prev)}
                >
                  {commentsCount} comment{commentsCount !== 1 ? 's' : ''}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      
      {/* Actions */}
      <div className="px-2 py-1 border-t border-neutral-100">
        <div className="flex justify-between">
          <Button 
            variant="ghost" 
            size="sm" 
            className={`flex-1 flex items-center justify-center py-2 text-sm font-medium ${isLiked ? 'text-primary' : 'text-neutral-500'}`}
            onClick={handleLikeToggle}
          >
            <ThumbsUp className={`h-4 w-4 mr-1 ${isLiked ? 'fill-current' : ''}`} />
            <span>Like</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex-1 flex items-center justify-center py-2 text-neutral-500 text-sm font-medium"
            onClick={() => setShowComments(prev => !prev)}
          >
            <MessageSquare className="h-4 w-4 mr-1" />
            <span>Comment</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex-1 flex items-center justify-center py-2 text-neutral-500 text-sm font-medium"
          >
            <Share className="h-4 w-4 mr-1" />
            <span>Share</span>
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="flex-1 flex items-center justify-center py-2 text-neutral-500 text-sm font-medium"
          >
            <Send className="h-4 w-4 mr-1" />
            <span>Send</span>
          </Button>
        </div>
      </div>
      
      {/* Comments Section */}
      {showComments && (
        <div className="px-4 py-3 border-t border-neutral-100">
          {/* Comment Form */}
          <form onSubmit={handleCommentSubmit} className="flex mb-4">
            <Avatar className="h-8 w-8 mr-2">
              {user?.profileImage ? (
                <AvatarImage src={user.profileImage} alt={user.fullName} />
              ) : (
                <AvatarFallback>{user?.fullName?.charAt(0) || "U"}</AvatarFallback>
              )}
            </Avatar>
            <div className="flex-1 relative">
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add a comment..."
                className="min-h-[40px] py-2 resize-none text-sm"
              />
              <Button 
                type="submit" 
                size="sm" 
                className="absolute bottom-2 right-2" 
                disabled={!comment.trim() || commentMutation.isPending}
              >
                Post
              </Button>
            </div>
          </form>
          
          {/* Comments List */}
          {post.comments && post.comments.length > 0 ? (
            <div className="space-y-3">
              {post.comments.map((comment: any) => (
                <div key={comment.id} className="flex">
                  <Avatar className="h-8 w-8 mr-2">
                    {comment.author?.profileImage ? (
                      <AvatarImage src={comment.author.profileImage} alt={comment.author.fullName} />
                    ) : (
                      <AvatarFallback>{comment.author?.fullName?.charAt(0) || "U"}</AvatarFallback>
                    )}
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-neutral-100 rounded-lg p-3">
                      <Link href={`/in/${comment.author?.username || ''}`} className="font-semibold text-sm hover:underline">
                        {comment.author?.fullName || 'Anonymous'}
                      </Link>
                      <p className="text-sm mt-1">{comment.content}</p>
                    </div>
                    <div className="flex items-center mt-1 space-x-4 text-xs text-neutral-500">
                      <span>{formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                      <button className="font-medium hover:text-neutral-700">Like</button>
                      <button className="font-medium hover:text-neutral-700">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-neutral-500 text-center py-2">No comments yet. Be the first to comment!</p>
          )}
        </div>
      )}
    </div>
  );
}
