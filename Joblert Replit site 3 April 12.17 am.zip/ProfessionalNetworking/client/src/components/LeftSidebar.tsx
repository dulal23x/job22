import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Users, 
  Calendar, 
  Hash, 
  ChevronRight 
} from "lucide-react";

export default function LeftSidebar() {
  const { user } = useAuth();
  
  if (!user) return null;
  
  return (
    <div className="w-full md:w-64 lg:w-80 flex-shrink-0">
      {/* Profile Card */}
      <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-4">
        {/* Cover Photo */}
        <div className="bg-primary-light h-14 relative"></div>
        
        {/* Profile Info */}
        <div className="px-4 pb-4 text-center">
          <Link href={`/in/${user.username}`}>
            <div className="h-16 w-16 rounded-full border-2 border-white bg-neutral-200 -mt-8 mx-auto overflow-hidden">
              {user.profileImage ? (
                <img 
                  src={user.profileImage} 
                  alt={user.fullName} 
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center bg-neutral-100 text-neutral-400">
                  {user.fullName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <h3 className="font-semibold mt-2">{user.fullName}</h3>
          </Link>
          <p className="text-sm text-neutral-500 mt-1">{user.headline || "Add a headline"}</p>
          
          <div className="border-t border-neutral-200 mt-3 pt-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-neutral-500">Profile views</span>
              <span className="font-medium text-primary">0</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span className="text-neutral-500">Post impressions</span>
              <span className="font-medium text-primary">0</span>
            </div>
          </div>
          
          <div className="border-t border-neutral-200 mt-3 pt-3">
            <Link href="/saved-items" className="text-sm text-neutral-500 flex items-center hover:text-neutral-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-accent mr-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z" />
              </svg>
              My items
            </Link>
          </div>
        </div>
      </div>
      
      {/* Recent */}
      <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-4">
        <div className="px-4 py-3">
          <h3 className="font-medium text-sm">Recent</h3>
          
          <div className="mt-2">
            <Link href="/groups/tech-professionals" className="flex items-center py-1 text-sm text-neutral-600 hover:text-primary group">
              <Users className="h-4 w-4 text-neutral-400 mr-2 group-hover:text-primary" />
              <span>Tech Professionals</span>
            </Link>
            
            <Link href="/events/web-summit" className="flex items-center py-1 text-sm text-neutral-600 hover:text-primary group">
              <Calendar className="h-4 w-4 text-neutral-400 mr-2 group-hover:text-primary" />
              <span>Web Summit 2023</span>
            </Link>
            
            <Link href="/hashtag/javascript" className="flex items-center py-1 text-sm text-neutral-600 hover:text-primary group">
              <Hash className="h-4 w-4 text-neutral-400 mr-2 group-hover:text-primary" />
              <span>javascript</span>
            </Link>
          </div>
          
          <div className="mt-2">
            <Link href="/groups" className="text-sm text-primary font-medium">
              Groups
            </Link>
          </div>
          
          <div className="mt-2 border-t border-neutral-200 pt-2">
            <Link href="/events" className="text-sm text-primary font-medium">
              Events
            </Link>
          </div>
          
          <div className="mt-2 border-t border-neutral-200 pt-2">
            <Link href="/hashtags" className="text-sm text-primary font-medium">
              Followed Hashtags
            </Link>
          </div>
          
          <div className="border-t border-neutral-200 mt-3 pt-3 text-center">
            <button className="text-sm text-neutral-500 font-medium flex items-center justify-center w-full">
              Discover more
              <ChevronRight className="h-4 w-4 ml-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
