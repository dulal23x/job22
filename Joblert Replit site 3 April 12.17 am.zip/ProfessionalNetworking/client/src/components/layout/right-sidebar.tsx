import { Link } from "wouter";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Job } from "@shared/schema";

// News item interface
interface NewsItem {
  id: number;
  title: string;
  timeAgo: string;
  readers: number;
  imageUrl: string;
}

interface ConnectionSuggestion {
  user: User;
  mutualConnections: number;
}

interface RightSidebarProps {
  newsList: NewsItem[];
  connectionSuggestions: ConnectionSuggestion[];
  jobRecommendations: Job[];
  onConnect: (userId: number) => void;
  onIgnoreConnection: (userId: number) => void;
}

export default function RightSidebar({
  newsList = [],
  connectionSuggestions = [],
  jobRecommendations = [],
  onConnect,
  onIgnoreConnection
}: Partial<RightSidebarProps>) {
  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    if (!name) return "U";
    return name.charAt(0).toUpperCase();
  };

  return (
    <div className="hidden lg:block w-80 flex-shrink-0">
      {/* News section */}
      <Card className="mb-4 overflow-hidden">
        <CardHeader className="px-4 py-3 flex items-center justify-between">
          <h3 className="font-medium text-base">Xubly News</h3>
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
            <i className="fas fa-info-circle text-neutral-500"></i>
          </Button>
        </CardHeader>
        
        <Separator />
        
        <CardContent className="p-0">
          {newsList && newsList.map((item, index) => (
            <div key={item.id} className="block px-4 py-2 hover:bg-neutral-50 border-b border-neutral-100">
              <Link href={`/news/${item.id}`} className="block">
                <div className="flex">
                  <div className="flex-1 pr-2">
                    <h4 className="text-sm font-medium">{item.title}</h4>
                    <div className="flex items-center mt-1 text-xs text-neutral-500">
                      <span>{item.timeAgo}</span>
                      <span className="mx-1">•</span>
                      <span>{item.readers.toLocaleString()} readers</span>
                    </div>
                  </div>
                  <div className="w-12 h-12 rounded bg-neutral-200 flex-shrink-0 overflow-hidden">
                    <img 
                      src={item.imageUrl} 
                      className="w-full h-full object-cover" 
                      alt={item.title} 
                    />
                  </div>
                </div>
              </Link>
            </div>
          ))}
          
          <div className="px-4 py-2">
            <Button variant="ghost" className="text-sm text-neutral-500 font-medium">
              Show more <i className="fas fa-arrow-right ml-1 text-xs"></i>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* People You May Know */}
      <Card className="mb-4 overflow-hidden">
        <CardHeader className="px-4 py-3">
          <h3 className="font-medium text-base">People you may know</h3>
        </CardHeader>
        
        <Separator />
        
        <CardContent className="p-0">
          {connectionSuggestions && connectionSuggestions.map((suggestion, index) => (
            <div key={suggestion.user.id} className="px-4 py-3 border-b border-neutral-100">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Link href={`/in/${suggestion.user.username}`}>
                    <Avatar className="h-14 w-14 cursor-pointer">
                      <AvatarImage src={suggestion.user.profileImage || undefined} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials(suggestion.user.fullName)}
                      </AvatarFallback>
                    </Avatar>
                  </Link>
                </div>
                
                <div className="ml-3 flex-1">
                  <Link href={`/in/${suggestion.user.username}`} className="font-medium hover:text-primary hover:underline">
                    {suggestion.user.fullName}
                  </Link>
                  <div className="text-neutral-500 text-sm">{suggestion.user.headline}</div>
                  <div className="text-xs text-neutral-500 mt-1">
                    <span>{suggestion.mutualConnections} mutual connections</span>
                  </div>
                  
                  <div className="mt-2 flex">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 mr-1 border-primary text-primary hover:bg-primary-light"
                      onClick={() => onIgnoreConnection?.(suggestion.user.id)}
                    >
                      Ignore
                    </Button>
                    
                    <Button
                      size="sm"
                      className="flex-1 ml-1 bg-primary text-white hover:bg-primary-dark"
                      onClick={() => onConnect?.(suggestion.user.id)}
                    >
                      Connect
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          <div className="px-4 py-3">
            <Button variant="link" className="text-sm text-primary font-medium w-full">
              View all recommendations
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Job Recommendations */}
      <Card className="mb-4 overflow-hidden">
        <CardHeader className="px-4 py-3 flex items-center justify-between">
          <h3 className="font-medium text-base">Recommended jobs</h3>
          <Button variant="ghost" size="icon" className="rounded-full h-8 w-8">
            <i className="fas fa-ellipsis-h text-neutral-500"></i>
          </Button>
        </CardHeader>
        
        <Separator />
        
        <CardContent className="p-0">
          {jobRecommendations && jobRecommendations.map((job, index) => (
            <div key={job.id} className="block px-4 py-3 hover:bg-neutral-50 border-b border-neutral-100">
              <Link href={`/jobs/view/${job.id}`} className="block">
                <h4 className="font-medium">{job.title}</h4>
                <div className="text-sm text-neutral-500">{job.company}</div>
                <div className="text-sm text-neutral-500">{job.location}</div>
                <div className="text-xs text-neutral-500 mt-1">
                  <span>Posted {formatJobDate(job.createdAt)}</span>
                  <span className="ml-2 text-secondary">
                    <i className="fas fa-user-check mr-1"></i>
                    <span>Skills match</span>
                  </span>
                </div>
              </Link>
            </div>
          ))}
          
          <div className="px-4 py-3">
            <Link href="/jobs/recommendations" className="text-sm text-primary font-medium hover:underline">
              See all recommended jobs
            </Link>
          </div>
        </CardContent>
      </Card>
      
      {/* Footer */}
      <div className="text-center text-xs text-neutral-500 mt-4">
        <div className="flex flex-wrap justify-center">
          <Link href="/about" className="px-2 py-1 hover:text-primary hover:underline">
            About
          </Link>
          <Link href="/accessibility" className="px-2 py-1 hover:text-primary hover:underline">
            Accessibility
          </Link>
          <Link href="/help" className="px-2 py-1 hover:text-primary hover:underline">
            Help Center
          </Link>
          <Link href="/privacy" className="px-2 py-1 hover:text-primary hover:underline">
            Privacy & Terms
          </Link>
          <Link href="/ads" className="px-2 py-1 hover:text-primary hover:underline">
            Ad Choices
          </Link>
          <Link href="/advertising" className="px-2 py-1 hover:text-primary hover:underline">
            Advertising
          </Link>
        </div>
        <div className="mt-2">
          <span>Xubly Corporation © {new Date().getFullYear()}</span>
        </div>
      </div>
    </div>
  );
}

// Helper function to format job date
function formatJobDate(date: Date | string | undefined): string {
  if (!date) return "Recently";
  
  const jobDate = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - jobDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "1 day ago";
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? 's' : ''} ago`;
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} month${Math.floor(diffDays / 30) > 1 ? 's' : ''} ago`;
  return `${Math.floor(diffDays / 365)} year${Math.floor(diffDays / 365) > 1 ? 's' : ''} ago`;
}
