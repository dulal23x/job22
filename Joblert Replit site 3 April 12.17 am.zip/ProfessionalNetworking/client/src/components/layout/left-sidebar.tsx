import { Link } from "wouter";
import { User } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Bookmark, Plus, UserPlus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface LeftSidebarProps {
  user: User;
}

export default function LeftSidebar({ user }: LeftSidebarProps) {
  // Get connection count
  const { data: connections = [] } = useQuery({
    queryKey: ["/api/connections", user.id, "accepted"],
    queryFn: async () => {
      const response = await fetch(`/api/connections/status/accepted`);
      if (!response.ok) throw new Error("Failed to fetch connections");
      return await response.json();
    },
    enabled: !!user,
  });
  return (
    <div className="space-y-4">
      {/* Profile Card */}
      <Card className="overflow-hidden border-none shadow-sm">
        <div className="h-20 bg-gradient-to-r from-blue-100 to-blue-50" />
        <CardContent className="pt-0 pb-4 -mt-10">
          <div className="flex flex-col items-center">
            <Link href="/profile">
              <Avatar className="h-16 w-16 border-4 border-white cursor-pointer">
                <AvatarImage src={user.profileImage || ""} alt={user.fullName} />
                <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
              </Avatar>
            </Link>
            <Link href="/profile">
              <h3 className="font-medium mt-2 text-center hover:underline cursor-pointer">
                {user.fullName}
              </h3>
            </Link>
            <p className="text-xs text-neutral-500 text-center line-clamp-2 mt-1">
              {user.headline || "Add a headline"}
            </p>
          </div>

          <div className="mt-4 pt-4 border-t">
            <Link href="/mynetwork">
              <div className="flex justify-between items-center py-1 text-sm hover:bg-neutral-50 px-2 rounded cursor-pointer">
                <span className="text-neutral-500">Connections</span>
                <span className="font-semibold text-blue-600">
                  {connections.length > 0 ? connections.length : 'Grow your network'}
                </span>
              </div>
            </Link>
            <Link href="/jobs/saved">
              <div className="flex justify-between items-center py-1 text-sm hover:bg-neutral-50 px-2 rounded cursor-pointer">
                <span className="text-neutral-500">Saved items</span>
                <Bookmark className="h-4 w-4 text-neutral-500" />
              </div>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Quick Access */}
      <Card className="border-none shadow-sm">
        <CardContent className="p-4">
          <h4 className="font-medium text-sm mb-3">Recent</h4>
          <div className="space-y-2">
            <Link href="/groups/recent-activity">
              <div className="flex items-center gap-2 text-sm text-neutral-600 hover:bg-neutral-50 p-1 rounded cursor-pointer">
                <UserPlus className="h-4 w-4 text-neutral-500" />
                <span>Recent Activity</span>
              </div>
            </Link>
            <Link href="/groups">
              <div className="flex items-center gap-2 text-sm text-neutral-600 hover:bg-neutral-50 p-1 rounded cursor-pointer">
                <Plus className="h-4 w-4 text-neutral-500" />
                <span>Groups</span>
              </div>
            </Link>
            <Link href="/events">
              <div className="flex items-center gap-2 text-sm text-neutral-600 hover:bg-neutral-50 p-1 rounded cursor-pointer">
                <Plus className="h-4 w-4 text-neutral-500" />
                <span>Events</span>
              </div>
            </Link>
            <Link href="/hashtags">
              <div className="flex items-center gap-2 text-sm text-neutral-600 hover:bg-neutral-50 p-1 rounded cursor-pointer">
                <Plus className="h-4 w-4 text-neutral-500" />
                <span>Followed Hashtags</span>
              </div>
            </Link>
          </div>
          
          <div className="mt-4 pt-2 border-t">
            <Link href="/discover" className="text-blue-600 text-sm font-medium">
              Discover more
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function to get initials
function getInitials(name: string | undefined): string {
  if (!name) return "UN";
  return name
    .split(" ")
    .map(part => part.charAt(0))
    .join("")
    .toUpperCase()
    .substring(0, 2);
}