import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Users, Briefcase, MessageSquare, Bell, User } from "lucide-react";

interface MobileNavProps {
  unreadNotifications?: number;
}

export default function MobileNav({ unreadNotifications = 0 }: MobileNavProps) {
  const [location] = useLocation();

  interface NavItem {
    href: string;
    icon: React.ElementType;
    label: string;
    count?: number;
  }
  
  const navItems: NavItem[] = [
    { href: "/feed", icon: Home, label: "Home" },
    { href: "/mynetwork", icon: Users, label: "Network" },
    { href: "/jobs", icon: Briefcase, label: "Jobs" },
    { href: "/messaging", icon: MessageSquare, label: "Messaging" },
    { href: "/notifications", icon: Bell, label: "Notifications", count: unreadNotifications },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-sm lg:hidden z-50">
      <div className="flex justify-around items-center px-1 py-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link 
              key={item.href} 
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center px-1 py-1",
                isActive ? "text-primary" : "text-neutral-500 hover:text-neutral-900"
              )}
            >
              <div className="relative">
                <Icon size={20} className={cn(isActive ? "text-primary" : "text-neutral-500")} />
                {item.count && item.count > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full h-3.5 w-3.5 flex items-center justify-center text-[10px]">
                    {item.count}
                  </span>
                )}
              </div>
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}