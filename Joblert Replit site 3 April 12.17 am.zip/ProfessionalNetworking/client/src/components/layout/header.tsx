import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { 
  Avatar, 
  AvatarFallback, 
  AvatarImage 
} from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuGroup,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { 
  HomeIcon, 
  BriefcaseIcon, 
  UsersIcon, 
  BellIcon, 
  MessageSquareIcon, 
  LogOut,
  Search as SearchIcon,
  UserCogIcon,
  PlusCircleIcon,
  Hash,
  CalendarIcon,
  CompassIcon,
  UserIcon,
  Settings,
  HelpCircle
} from "lucide-react";
import { Input } from "@/components/ui/input";

interface NavItem {
  href: string;
  icon: React.ElementType;
  label: string;
  count?: number;
}

interface HeaderProps {
  unreadNotifications?: number;
}

export default function Header({ unreadNotifications = 0 }: HeaderProps) {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  // Show back button when not on homepage
  const showBackButton = location !== "/" && location !== "/feed";
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Default tab is "people"
      const searchParams = new URLSearchParams({
        q: searchQuery,
        tab: "people"
      });
      setLocation(`/search?${searchParams.toString()}`);
    }
  };

  // Function to get user initials for avatar
  const getInitials = (name: string): string => {
    return name
      .split(" ")
      .map(part => part.charAt(0))
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const navItems: NavItem[] = [
    { href: "/feed", icon: HomeIcon, label: "Home" },
    { href: "/mynetwork", icon: UsersIcon, label: "My Network" },
    { href: "/jobs", icon: BriefcaseIcon, label: "Jobs" },
    { href: "/messaging", icon: MessageSquareIcon, label: "Messaging" },
    { href: "/notifications", icon: BellIcon, label: "Notifications", count: unreadNotifications },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-white/95 backdrop-blur border-b shadow-sm z-50 w-full">
      <div className="container h-full max-w-7xl mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Back Button */}
          {showBackButton && (
            <button 
              onClick={() => window.history.back()} 
              className="mr-2 text-neutral-600 hover:text-neutral-900"
            >
              ← Back
            </button>
          )}

          {/* Logo */}
          <Link href={user ? "/feed" : "/"} className="font-bold text-xl text-primary flex items-center">
            <div className="w-8 h-8 rounded-md bg-primary text-white flex items-center justify-center mr-1 shadow-sm">
              ⬡
            </div>
            <span className="hidden sm:inline">Xubly</span>
          </Link>
        </div>

        {user ? (
          <>
            {/* Authenticated Navigation */}
            <div className="flex items-center justify-between flex-1 max-w-4xl ml-6">
              {/* Search Bar */}
              <form onSubmit={handleSearch} className="hidden md:flex relative max-w-md flex-1 mx-6">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-600" strokeWidth={2.5} />
                <Input 
                  placeholder="Search people, jobs, companies..." 
                  className="pl-10 h-10 rounded-md bg-neutral-100 border-neutral-200 w-full shadow-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>

              {/* Main Navigation */}
              <nav className="hidden lg:flex items-center space-x-1">
                {navItems.map((item) => (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    className="flex flex-col items-center justify-center p-2 relative hover:bg-neutral-100 rounded-md transition-colors"
                  >
                    {item.count && item.count > 0 && (
                      <span className="absolute top-0 right-0 bg-red-500 text-white rounded-full h-4 w-4 flex items-center justify-center text-xs font-bold shadow-sm">
                        {item.count}
                      </span>
                    )}
                    <item.icon className="h-6 w-6 text-neutral-700" />
                    <span className="text-xs mt-1 text-neutral-700 font-medium">{item.label}</span>
                  </Link>
                ))}

                {/* User Profile */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="p-2 hover:bg-neutral-100 rounded-md">
                      <div className="flex flex-col items-center">
                        <Avatar className="h-6 w-6 border-2 border-primary/20">
                          <AvatarImage src={user?.profileImage || ""} alt={user?.fullName || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary font-bold">
                            {user?.fullName ? getInitials(user.fullName) : "US"}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs mt-1 text-neutral-700 font-medium">Me</span>
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="shadow-md w-60">
                    <DropdownMenuLabel>
                      <div className="flex items-start gap-3">
                        <Avatar className="h-10 w-10 border-2 border-primary/20">
                          <AvatarImage src={user?.profileImage || ""} alt={user?.fullName || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary font-bold">
                            {user?.fullName ? getInitials(user.fullName) : "US"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{user?.fullName || "User"}</h4>
                          <p className="text-xs text-neutral-500 line-clamp-1">{user?.headline || "Xubly member"}</p>
                        </div>
                      </div>
                    </DropdownMenuLabel>

                    <Link href={`/profile/${user?.username}`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <UserIcon className="h-4 w-4 mr-2" />
                        View Profile
                      </DropdownMenuItem>
                    </Link>

                    <DropdownMenuSeparator />

                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs font-semibold text-neutral-500">Account</DropdownMenuLabel>
                      <Link href="/profile/edit">
                        <DropdownMenuItem className="cursor-pointer">
                          <UserCogIcon className="h-4 w-4 mr-2" />
                          Edit Profile
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/profile/add-experience">
                        <DropdownMenuItem className="cursor-pointer">
                          <PlusCircleIcon className="h-4 w-4 mr-2" />
                          Add Experience
                        </DropdownMenuItem>
                      </Link>
                    </DropdownMenuGroup>

                    <DropdownMenuSeparator />

                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs font-semibold text-neutral-500">Discover</DropdownMenuLabel>
                      <Link href="/groups">
                        <DropdownMenuItem className="cursor-pointer">
                          <UsersIcon className="h-4 w-4 mr-2" />
                          Groups
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/events">
                        <DropdownMenuItem className="cursor-pointer">
                          <CalendarIcon className="h-4 w-4 mr-2" />
                          Events
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/hashtags">
                        <DropdownMenuItem className="cursor-pointer">
                          <Hash className="h-4 w-4 mr-2" />
                          Followed Hashtags
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/discover">
                        <DropdownMenuItem className="cursor-pointer">
                          <CompassIcon className="h-4 w-4 mr-2" />
                          Discover More
                        </DropdownMenuItem>
                      </Link>
                    </DropdownMenuGroup>

                    <DropdownMenuSeparator />

                    <DropdownMenuItem 
                      className="cursor-pointer text-red-600" 
                      onClick={() => logoutMutation.mutate()}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </nav>

              {/* Mobile Search Icon */}
              <div className="flex items-center md:hidden">
                <Link href="/search?tab=people">
                  <Button size="icon" variant="ghost" className="hover:bg-neutral-100">
                    <SearchIcon className="h-5 w-5 text-neutral-700" strokeWidth={2.5} />
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="ml-1 hover:bg-neutral-100">
                      <Avatar className="h-8 w-8 border-2 border-primary/20">
                        <AvatarImage src={user?.profileImage || ""} alt={user?.fullName || ""} />
                        <AvatarFallback className="bg-primary/10 text-primary font-bold">
                          {user?.fullName ? getInitials(user.fullName) : "US"}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="shadow-md w-60">
                    <DropdownMenuLabel>
                      <div className="flex items-start gap-3">
                        <Avatar className="h-10 w-10 border-2 border-primary/20">
                          <AvatarImage src={user?.profileImage || ""} alt={user?.fullName || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary font-bold">
                            {user?.fullName ? getInitials(user.fullName) : "US"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{user?.fullName || "User"}</h4>
                          <p className="text-xs text-neutral-500 line-clamp-1">{user?.headline || "Xubly member"}</p>
                        </div>
                      </div>
                    </DropdownMenuLabel>

                    <Link href={`/profile/${user?.username}`}>
                      <DropdownMenuItem className="cursor-pointer">
                        <UserIcon className="h-4 w-4 mr-2" />
                        View Profile
                      </DropdownMenuItem>
                    </Link>

                    <DropdownMenuSeparator />

                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs font-semibold text-neutral-500">Account</DropdownMenuLabel>
                      <Link href="/profile/edit">
                        <DropdownMenuItem className="cursor-pointer">
                          <UserCogIcon className="h-4 w-4 mr-2" />
                          Edit Profile
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/profile/add-experience">
                        <DropdownMenuItem className="cursor-pointer">
                          <PlusCircleIcon className="h-4 w-4 mr-2" />
                          Add Experience
                        </DropdownMenuItem>
                      </Link>
                    </DropdownMenuGroup>

                    <DropdownMenuSeparator />

                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs font-semibold text-neutral-500">Discover</DropdownMenuLabel>
                      <Link href="/groups">
                        <DropdownMenuItem className="cursor-pointer">
                          <UsersIcon className="h-4 w-4 mr-2" />
                          Groups
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/events">
                        <DropdownMenuItem className="cursor-pointer">
                          <CalendarIcon className="h-4 w-4 mr-2" />
                          Events
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/hashtags">
                        <DropdownMenuItem className="cursor-pointer">
                          <Hash className="h-4 w-4 mr-2" />
                          Followed Hashtags
                        </DropdownMenuItem>
                      </Link>
                      <Link href="/discover">
                        <DropdownMenuItem className="cursor-pointer">
                          <CompassIcon className="h-4 w-4 mr-2" />
                          Discover More
                        </DropdownMenuItem>
                      </Link>
                    </DropdownMenuGroup>

                    <DropdownMenuSeparator />

                    <DropdownMenuItem 
                      className="cursor-pointer text-red-600" 
                      onClick={() => logoutMutation.mutate()}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Unauthenticated Navigation */}
            <nav className="flex items-center space-x-2">
              <Link href="/jobs">
                <Button variant="ghost" className="text-neutral-600 hover:text-neutral-900">
                  Find Jobs
                </Button>
              </Link>
              <Link href="/post-job">
                <Button variant="ghost" className="text-neutral-600 hover:text-neutral-900">
                  Post Jobs
                </Button>
              </Link>
              <div className="h-6 border-l border-neutral-200 mx-2" />
              <Link href="/auth">
                <Button variant="ghost" className="text-neutral-600 hover:text-neutral-900">
                  Sign In
                </Button>
              </Link>
              <Link href="/auth">
                <Button variant="default" className="bg-primary hover:bg-primary/90">
                  Join Now
                </Button>
              </Link>
            </nav>
          </>
        )}
      </div>
    </header>
  );
}