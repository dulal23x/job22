import { Job } from "@shared/schema";
import { Link } from "wouter";
import { formatDistance } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, MapPin, Banknote, Clock, Building, ArrowRight } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface JobCardProps {
  job: Job;
  isLast?: boolean;
  showCompanyAvatar?: boolean;
}

export default function JobCard({ job, isLast = false, showCompanyAvatar = true }: JobCardProps) {
  // Function to get company initials for avatar
  const getCompanyInitials = (companyName: string): string => {
    return companyName
      .split(" ")
      .map(part => part.charAt(0))
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };
  
  // Calculate how long ago the job was posted
  const getTimeAgo = (date: Date): string => {
    try {
      return formatDistance(new Date(date), new Date(), { addSuffix: true });
    } catch (e) {
      return "recently";
    }
  };
  
  return (
    <div className={`p-6 ${!isLast ? "border-b border-neutral-200" : ""}`}>
      <div className="flex gap-4">
        {showCompanyAvatar && (
          <Avatar className="h-14 w-14 rounded-lg bg-neutral-100 border border-neutral-200">
            <AvatarFallback className="text-primary font-semibold text-xl">
              {getCompanyInitials(job.company)}
            </AvatarFallback>
          </Avatar>
        )}
        
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
            <div>
              <Link href={`/jobs/view/${job.id}`}>
                <h3 className="text-lg font-semibold hover:text-primary hover:underline cursor-pointer">
                  {job.title}
                </h3>
              </Link>
              <div className="flex items-center flex-wrap gap-x-3 gap-y-2 mt-1 text-sm text-neutral-600">
                <div className="flex items-center">
                  <Building className="h-4 w-4 mr-1" strokeWidth={2} />
                  {job.company}
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" strokeWidth={2} />
                  {job.location}
                  {job.remote && <Badge variant="outline" className="ml-2 text-xs py-0">Remote</Badge>}
                </div>
                {job.salary && (
                  <div className="flex items-center">
                    <Banknote className="h-4 w-4 mr-1" strokeWidth={2} />
                    {job.salary}
                  </div>
                )}
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" strokeWidth={2} />
                  {getTimeAgo(job.createdAt)}
                </div>
              </div>
            </div>
            
            <Link href={`/jobs/view/${job.id}`}>
              <Button variant="outline" size="sm" className="mt-3 sm:mt-0 whitespace-nowrap">
                View Job
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
          
          {job.description && (
            <p className="mt-3 text-neutral-700 line-clamp-2">
              {job.description}
            </p>
          )}
          
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="secondary">{job.type}</Badge>
            {job.remote && <Badge variant="secondary">Remote</Badge>}
          </div>
        </div>
      </div>
    </div>
  );
}