import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ThumbsUp, MessageSquare, Share2, Send } from "lucide-react";
import { PostWithAuthor, Comment } from "@shared/schema";

interface PostCardProps {
  post: PostWithAuthor;
  comments?: Comment[];
}

export default function PostCard({ post, comments = [] }: PostCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [liked, setLiked] = useState(post.hasReacted || false);
  const [likeCount, setLikeCount] = useState(post.reactionCount || 0);
  const [commentText, setCommentText] = useState("");
  const [showComments, setShowComments] = useState(false);
  const [postComments, setPostComments] = useState(comments);

  const toggleReactionMutation = useMutation({
    mutationFn: async () => {
      const method = liked ? "DELETE" : "POST";
      const res = await apiRequest(method, `/api/posts/${post.id}/react`, {
        type: "like"
      });

      if (method === "DELETE") {
        return true; // Reaction removed
      }

      return await res.json();
    },
    onSuccess: (data) => {
      const newLikedState = !liked;
      setLiked(newLikedState);
      setLikeCount(prev => newLikedState ? prev + 1 : prev - 1);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const addCommentMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/posts/${post.id}/comment`, {
        content: commentText
      });
      return await res.json();
    },
    onSuccess: (newComment) => {
      setCommentText("");
      setPostComments(prev => [...prev, newComment]);
      if (!showComments) {
        setShowComments(true);
      }
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error adding comment",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleToggleLike = () => {
    toggleReactionMutation.mutate();
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    addCommentMutation.mutate();
  };

  return (
    <Card className="mb-4 shadow-sm overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-12 w-12 border">
            <AvatarImage src={post.authorProfileImage || undefined} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {post.authorName ? post.authorName.charAt(0) : "U"}
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold">{post.authorName}</h3>
            <p className="text-xs text-neutral-500">{post.authorHeadline || ""}</p>
            <p className="text-xs text-neutral-500">
              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
            </p>
          </div>
        </div>

        <div className="mt-3 text-base">
          <p className="whitespace-pre-line">{post.content}</p>
        </div>

        {post.mediaUrl && (
          <div className="mt-3">
            <img
              src={post.mediaUrl}
              alt="Post media"
              className="w-full rounded-md max-h-[400px] object-contain bg-neutral-100"
            />
          </div>
        )}

        {/* Reaction counts */}
        {(likeCount > 0 || postComments.length > 0) && (
          <div className="mt-4 flex justify-between text-xs text-neutral-500">
            <div className="flex items-center gap-1">
              {likeCount > 0 && (
                <>
                  <span className="flex items-center">
                    <ThumbsUp className="h-3.5 w-3.5 mr-1 text-primary" />
                    {likeCount}
                  </span>
                </>
              )}
            </div>

            {postComments.length > 0 && (
              <button
                className="hover:underline"
                onClick={() => setShowComments(!showComments)}
              >
                {postComments.length} comment{postComments.length !== 1 ? "s" : ""}
              </button>
            )}
          </div>
        )}
      </CardContent>

      <Separator />

      {/* Actions */}
      <div className="px-4 py-1 flex justify-between">
        <Button
          variant="ghost"
          size="sm"
          className={`flex-1 flex items-center justify-center ${liked ? "text-primary" : ""}`}
          onClick={handleToggleLike}
        >
          <ThumbsUp className={`h-5 w-5 mr-2 ${liked ? "fill-current" : ""}`} />
          Like
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-1 flex items-center justify-center"
          onClick={() => setShowComments(!showComments)}
        >
          <MessageSquare className="h-5 w-5 mr-2" />
          Comment
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-1 flex items-center justify-center"
        >
          <Share2 className="h-5 w-5 mr-2" />
          Share
        </Button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="px-4 py-2 bg-neutral-50">
          {/* Existing comments */}
          {postComments.length > 0 && (
            <div className="mb-3 space-y-3">
              {postComments.map((comment) => (
                <div key={comment.id} className="flex gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      {comment.userId === user?.id ? (
                        user.fullName?.charAt(0) || "U"
                      ) : (
                        /* This should come from the API with user details */
                        "U"
                      )}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-neutral-100 rounded-lg p-2">
                      <div className="font-semibold text-sm">
                        {comment.userId === user?.id ? (
                          user.fullName
                        ) : (
                          /* This should come from the API with user details */
                          "User"
                        )}
                      </div>
                      <div className="text-sm">{comment.content}</div>
                    </div>
                    <div className="mt-1 flex gap-3 text-xs text-neutral-500">
                      <button className="font-medium hover:text-neutral-700">Like</button>
                      <button className="font-medium hover:text-neutral-700">Reply</button>
                      <span>{formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add comment form */}
          <form onSubmit={handleAddComment} className="flex gap-2 items-center">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user?.profileImage || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary text-xs">
                {user?.fullName?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 relative">
              <Input
                placeholder="Add a comment..."
                className="pr-10 bg-neutral-100 border-neutral-200"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
              />
              <Button
                type="submit"
                size="icon"
                variant="ghost"
                className="h-8 w-8 absolute right-1 top-1/2 -translate-y-1/2"
                disabled={!commentText.trim() || addCommentMutation.isPending}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>
      )}
    </Card>
  );
}