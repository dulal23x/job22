import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { User, insertPostSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Loader2, Image, Video, Calendar, FileText } from "lucide-react";

interface PostCreatorProps {
  user: User;
}

// Extend the post schema with a client-side validation
const createPostSchema = insertPostSchema.omit({ userId: true });

export default function PostCreator({ user }: PostCreatorProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [uploadedMedia, setUploadedMedia] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof createPostSchema>>({
    resolver: zodResolver(createPostSchema),
    defaultValues: {
      content: "",
      mediaUrl: ""
    }
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: z.infer<typeof createPostSchema>) => {
      const res = await apiRequest("POST", "/api/posts", data);
      return await res.json();
    },
    onSuccess: () => {
      // Clear form
      form.reset();
      setUploadedMedia(null);
      setIsDialogOpen(false);

      // Invalidate and refetch feed query to show the new post
      queryClient.invalidateQueries({ queryKey: ["/api/feed"] });

      toast({
        title: "Post created",
        description: "Your post has been shared with your network",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: z.infer<typeof createPostSchema>) => {
    // If we have uploaded media, add it to the form data
    if (uploadedMedia) {
      data.mediaUrl = uploadedMedia;
    }

    createPostMutation.mutate(data);
  };

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Create a file reader to read the image
      const reader = new FileReader();
      reader.onload = (event) => {
        // Set the uploaded media to the data URL of the image
        setUploadedMedia(event.target?.result as string);
      };
      // Read the file as a data URL (base64 encoded string)
      reader.readAsDataURL(file);
    }
  };

  return (
    <>
      <Card className="mb-4 shadow-sm">
        <CardContent className="p-5">
          <div className="flex items-center">
            <Avatar className="h-12 w-12 mr-3 border shadow-sm">
              <AvatarImage src={user.profileImage || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary font-bold">
                {user.fullName ? user.fullName.charAt(0) : "U"}
              </AvatarFallback>
            </Avatar>
            <Button 
              variant="outline" 
              className="bg-neutral-100 hover:bg-neutral-200 text-neutral-600 font-medium py-3 px-4 rounded-full flex-1 text-left justify-start border border-neutral-300"
              onClick={() => setIsDialogOpen(true)}
            >
              <span className="text-neutral-500">What do you want to talk about?</span>
            </Button>
          </div>
          
          <div className="mt-4 pt-3 border-t border-neutral-200">
            <div className="flex justify-between">
              <Button 
                variant="ghost" 
                className="flex items-center py-2 px-3 rounded hover:bg-neutral-100 text-neutral-600 text-sm font-medium"
                onClick={() => setIsDialogOpen(true)}
              >
                <Image className="h-5 w-5 text-blue-500 mr-2" />
                <span>Photo</span>
              </Button>

              <Button 
                variant="ghost" 
                className="flex items-center py-2 px-3 rounded hover:bg-neutral-100 text-neutral-600 text-sm font-medium"
                onClick={() => setIsDialogOpen(true)}
              >
                <Video className="h-5 w-5 text-green-500 mr-2" />
                <span>Video</span>
              </Button>

              <Button 
                variant="ghost" 
                className="flex items-center py-2 px-3 rounded hover:bg-neutral-100 text-neutral-600 text-sm font-medium"
                onClick={() => setIsDialogOpen(true)}
              >
                <Calendar className="h-5 w-5 text-orange-500 mr-2" />
                <span>Event</span>
              </Button>

              <Button 
                variant="ghost" 
                className="flex items-center py-2 px-3 rounded hover:bg-neutral-100 text-neutral-600 text-sm font-medium"
                onClick={() => setIsDialogOpen(true)}
              >
                <FileText className="h-5 w-5 text-primary mr-2" />
                <span>Article</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Post Editor Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-center text-lg font-semibold">Create a post</DialogTitle>
          </DialogHeader>

          <div className="flex items-center mb-5 pt-2">
            <Avatar className="h-12 w-12 mr-3 border shadow-sm">
              <AvatarImage src={user.profileImage || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary font-bold">
                {user.fullName ? user.fullName.charAt(0) : "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">{user.fullName}</p>
              <Button variant="outline" size="sm" className="mt-1 h-7 text-xs rounded-full px-3 flex items-center gap-1">
                <span>Anyone</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m6 9 6 6 6-6"/>
                </svg>
              </Button>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="What do you want to talk about?" 
                        className="min-h-[180px] resize-none border-none focus-visible:ring-0 text-lg"
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {uploadedMedia && (
                <div className="relative">
                  <img 
                    src={uploadedMedia} 
                    alt="Uploaded media" 
                    className="rounded-md max-h-[300px] w-full object-cover" 
                  />
                  <Button 
                    variant="outline" 
                    size="icon"
                    className="absolute top-2 right-2 bg-neutral-800 bg-opacity-50 text-white hover:bg-neutral-700 h-8 w-8 rounded-full"
                    onClick={() => setUploadedMedia(null)}
                  >
                    ×
                  </Button>
                </div>
              )}

              <div className="border-t border-neutral-200 pt-4">
                <p className="text-sm font-medium mb-3 text-neutral-600">Add to your post:</p>
                <div className="flex items-center gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="rounded-full border-neutral-300 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200"
                  >
                    <label htmlFor="media-upload" className="cursor-pointer flex items-center px-1">
                      <Image className="h-5 w-5 text-blue-500 mr-2" />
                      <span>Photo</span>
                    </label>
                    <Input 
                      id="media-upload" 
                      type="file" 
                      accept="image/*,video/*" 
                      className="hidden" 
                      onChange={handleMediaUpload}
                    />
                  </Button>

                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="rounded-full border-neutral-300 hover:bg-green-50 hover:text-green-600 hover:border-green-200"
                  >
                    <Video className="h-5 w-5 text-green-500 mr-2" />
                    <span>Video</span>
                  </Button>

                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="rounded-full border-neutral-300 hover:bg-orange-50 hover:text-orange-600 hover:border-orange-200"
                  >
                    <Calendar className="h-5 w-5 text-orange-500 mr-2" />
                    <span>Event</span>
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="rounded-full border-neutral-300 hover:bg-primary/5 hover:text-primary hover:border-primary/20"
                  >
                    <FileText className="h-5 w-5 text-primary mr-2" />
                    <span>Document</span>
                  </Button>
                </div>
              </div>

              <DialogFooter className="border-t border-neutral-200 pt-4 mt-4">
                <div className="w-full flex justify-between items-center">
                  <Button
                    type="button"
                    variant="outline"
                    className="rounded-full border-neutral-300"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  
                  <Button
                    type="submit"
                    className="rounded-full px-5"
                    disabled={form.formState.isSubmitting || createPostMutation.isPending || !form.formState.isValid}
                  >
                    {createPostMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Post
                  </Button>
                </div>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}