import React from 'react';

type IconProps = {
  className?: string;
  style?: React.CSSProperties;
};

// Modern icon set
export const ModernIcons = {
  Home: (props: IconProps) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
      <polyline points="9 22 9 12 15 12 15 22"></polyline>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
      <circle cx="9" cy="7" r="4"></circle>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
      <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8"></circle>
      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
  )
};

// Creative icon set
export const CreativeIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 3L4 9V21H9V14H15V21H20V9L12 3Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      <path d="M12 3L12 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 8.5V19C4 19.5523 4.44772 20 5 20H19C19.5523 20 20 19.5523 20 19V8.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 8V5C16 4.44772 15.5523 4 15 4H9C8.44772 4 8 4.44772 8 5V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M4 9.5H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 12V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="9" cy="6" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="16" cy="18" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="3" cy="16" r="2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 9L3 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M11.5 8.5L15.5 15.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 4C10 2.89543 10.8954 2 12 2C13.1046 2 14 2.89543 14 4C16.6667 4.66667 17.5 8 17.5 10.5V15L19 16.5V18H5V16.5L6.5 15V10.5C6.5 8 7.33333 4.66667 10 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 18C9 19.6569 10.3431 21 12 21C13.6569 21 15 19.6569 15 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 20L7.89561 16.5542C8.5624 16.0799 9.36753 15.8262 10.1893 15.8262H17.5C18.3284 15.8262 19 15.1547 19 14.3262V5.5C19 4.67157 18.3284 4 17.5 4H4.5C3.67157 4 3 4.67157 3 5.5V20Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8 9H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M15 15L20 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 8L9 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
};

// Minimal icon set
export const MinimalIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="10" width="16" height="11" rx="1" stroke="currentColor" strokeWidth="2"/>
      <path d="M12 3L19 9H5L12 3Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="8" width="16" height="12" rx="1" stroke="currentColor" strokeWidth="2"/>
      <path d="M9 8V6C9 5.44772 9.44772 5 10 5H14C14.5523 5 15 5.44772 15 6V8" stroke="currentColor" strokeWidth="2"/>
      <path d="M12 12V16" stroke="currentColor" strokeWidth="2" strokeLinecap="square"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="7" cy="8" r="3" stroke="currentColor" strokeWidth="2"/>
      <circle cx="17" cy="8" r="3" stroke="currentColor" strokeWidth="2"/>
      <circle cx="12" cy="17" r="3" stroke="currentColor" strokeWidth="2"/>
      <path d="M9.5 10L11 14.5" stroke="currentColor" strokeWidth="2"/>
      <path d="M14.5 10L13 14.5" stroke="currentColor" strokeWidth="2"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 4C15.3137 4 18 6.68629 18 10V15L20 17H4L6 15V10C6 6.68629 8.68629 4 12 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="square"/>
      <path d="M10 18C10 19.1046 10.8954 20 12 20C13.1046 20 14 19.1046 14 18" stroke="currentColor" strokeWidth="2"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="5" width="16" height="12" rx="1" stroke="currentColor" strokeWidth="2"/>
      <path d="M4 9L12 13L20 9" stroke="currentColor" strokeWidth="2"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="11" cy="11" r="6" stroke="currentColor" strokeWidth="2"/>
      <path d="M16 16L20 20" stroke="currentColor" strokeWidth="2" strokeLinecap="square"/>
    </svg>
  )
};

// Tech icon set
export const TechIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 12L5 10M5 10L12 3L19 10M5 10V20C5 20.5523 5.44772 21 6 21H9M19 10L21 12M19 10V20C19 20.5523 18.5523 21 18 21H15M9 21C9.55228 21 10 20.5523 10 20V16C10 15.4477 10.4477 15 11 15H13C13.5523 15 14 15.4477 14 16V20C14 20.5523 14.4477 21 15 21M9 21H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 7H4C3.44772 7 3 7.44772 3 8V19C3 19.5523 3.44772 20 4 20H20C20.5523 20 21 19.5523 21 19V8C21 7.44772 20.5523 7 20 7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 7V5C16 4.44772 15.5523 4 15 4H9C8.44772 4 8 4.44772 8 5V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 12V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8 12H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.5 19.794C18.8412 18.814 20.5 16.5726 20.5 14C20.5 10.4101 17.5899 7.5 14 7.5C13.6654 7.5 13.3369 7.52452 13.0161 7.57224" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M14.4697 11.4999C15.4021 12.4322 15.4021 13.9321 14.4697 14.8644C13.5374 15.7968 12.0376 15.7968 11.1052 14.8644C10.1729 13.9321 10.1729 12.4322 11.1052 11.4999C12.0376 10.5675 13.5374 10.5675 14.4697 11.4999Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M7.5 19.794C5.15883 18.814 3.5 16.5726 3.5 14C3.5 10.4101 6.41015 7.5 10 7.5C10.3346 7.5 10.6631 7.52452 10.9839 7.57224" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M17.029 5.50017C17.0097 5.28535 17 5.0683 17 4.85C17 2.72386 18.6667 1 20.7222 1C22.7778 1 24 2.72386 24 4.85C24 6.97614 22.7778 9 20.7222 9C19.8193 9 19.2183 8.66265 18.8183 8.2049" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M18.6298 13C18.744 12.6878 18.8 12.3508 18.8 12C18.8 10.5478 18.2257 9.26157 17.3542 8.34921M6.64579 8.34921C5.77432 9.26157 5.2 10.5478 5.2 12C5.2 12.3508 5.25602 12.6878 5.37018 13M17.3542 8.34921C16.4827 7.43685 15.3136 6.8 14 6.8C12.6864 6.8 11.5173 7.43685 10.6458 8.34921M17.3542 8.34921L19.4 6.2M6.64579 8.34921C7.51726 7.43685 8.68637 6.8 10 6.8C11.3136 6.8 12.4827 7.43685 13.3542 8.34921M6.64579 8.34921L4.60001 6.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M10.5 13H13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M5 17H19C19.5523 17 20 16.5523 20 16V13C20 12.4477 19.5523 12 19 12H5C4.44772 12 4 12.4477 4 13V16C4 16.5523 4.44772 17 5 17Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 10C8 9.44772 8.44772 9 9 9H15C15.5523 9 16 9.44772 16 10C16 10.5523 15.5523 11 15 11H9C8.44772 11 8 10.5523 8 10Z" fill="currentColor"/>
      <path d="M9 13C8.44772 13 8 13.4477 8 14C8 14.5523 8.44772 15 9 15H13C13.5523 15 14 14.5523 14 14C14 13.4477 13.5523 13 13 13H9Z" fill="currentColor"/>
      <path d="M10 22C8.75 22 7.63333 21.5667 6.65 20.7C5.7 19.8 5.19333 18.45 5.13 16.65C3.4 16.5 2.06667 15.9 1.13 14.85C0.376667 13.9833 0 12.983 0 11.85C0 10.7167 0.376667 9.7 1.13 8.8C1.88333 7.9 2.86667 7.33333 4.08 7.1C4.42667 5.03333 5.27667 3.4 6.63 2.2C8.01667 0.966666 9.68333 0.35 11.63 0.35C13.5767 0.35 15.1733 0.983333 16.42 2.25C17.6667 3.48333 18.4267 5.1 18.7 7.1C19.9667 7.3 20.95 7.85 21.65 8.75C22.3833 9.61667 22.75 10.6333 22.75 11.8C22.75 12.9667 22.3767 13.9833 21.63 14.85C20.9167 15.6833 19.95 16.2333 18.73 16.5C18.33 19.9667 16.88 21.7 14.38 21.7C13.7267 21.7 13.1567 21.58 12.67 21.34C12.1833 21.1 11.7633 20.7733 11.41 20.36C11.0567 20.7733 10.6367 21.1 10.15 21.34C9.66333 21.58 9.29666 21.7 10 22ZM11.5 19.65C11.9667 19.65 12.3333 19.55 12.6 19.35C12.8667 19.15 13.0333 18.8833 13.1 18.55L10 18C10.0667 18.3333 10.2367 18.6 10.51 18.8C10.7833 19 11.1 19.1 11.5 19.65ZM14.4 19.9C15.6667 19.9 16.45 19.3933 16.75 18.38C17.05 17.3667 16.9467 16.1333 16.44 14.68L9.89 14.28C9.49667 15.7467 9.42333 16.9833 9.67 17.99C9.95 19.0233 10.7267 19.54 12 19.54H14.4V19.9ZM9.18 12.48L17.03 12.73C17.1633 12.2367 17.23 11.7333 17.23 11.22C17.23 9.58 16.7933 8.25667 15.92 7.24C15.0467 6.22333 13.87 5.71 12.39 5.71C10.91 5.71 9.69 6.25 8.73 7.33C7.77 8.41 7.29 9.84333 7.29 11.63C7.29 11.9767 7.31333 12.2567 7.36 12.47H9.18V12.48ZM4.18 14.33H7.64C7.78 14.7033 7.95333 15.0633 8.16 15.41L8.66 16.36L15.54 16.86L16.05 15.92C16.2567 15.5733 16.4167 15.2033 16.53 14.81L19.89 14.73C20.49 14.5767 20.95 14.3033 21.27 13.91C21.59 13.5167 21.75 13.0867 21.75 12.62C21.75 11.7267 21.42 10.9967 20.76 10.43C20.1 9.86333 19.3333 9.58 18.46 9.58H17.96L17.89 9.08C17.7433 7.28 17.15 5.86 16.11 4.82C15.07 3.78 13.73 3.26 12.09 3.26C10.45 3.26 9.06333 3.78 7.92 4.82C6.84333 5.82667 6.21333 7.24667 6.03 9.08L5.96 9.58H5.46C4.58667 9.58 3.87667 9.86 3.33 10.42C2.81667 10.9467 2.56 11.6733 2.56 12.6C2.56 13.0667 2.71333 13.4733 3.02 13.82C3.32667 14.1667 3.68667 14.3767 4.18 14.33Z" fill="currentColor"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 4C6.68629 4 4 6.68629 4 10C4 13.3137 6.68629 16 10 16C13.3137 16 16 13.3137 16 10C16 6.68629 13.3137 4 10 4ZM2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10Z" fill="currentColor"/>
      <path d="M15.2929 15.2929C15.6834 14.9024 16.3166 14.9024 16.7071 15.2929L21.7071 20.2929C22.0976 20.6834 22.0976 21.3166 21.7071 21.7071C21.3166 22.0976 20.6834 22.0976 20.2929 21.7071L15.2929 16.7071C14.9024 16.3166 14.9024 15.6834 15.2929 15.2929Z" fill="currentColor"/>
    </svg>
  )
};

// Glass icon set
export const GlassIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" clipRule="evenodd" d="M5 22C3.89543 22 3 21.1046 3 20V10.4142C3 9.88371 3.21071 9.37493 3.58579 8.99986L11.5858 1.00008C11.9467 0.639152 12.5533 0.639152 12.9142 1.00008L20.9142 8.99986C21.2893 9.37493 21.5 9.88371 21.5 10.4142V20C21.5 21.1046 20.6046 22 19.5 22H5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 16C9 14.8954 9.89543 14 11 14H13C14.1046 14 15 14.8954 15 16V22H9V16Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path opacity="0.2" d="M10 21H5C3.89543 21 3 20.1046 3 19V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V19C21 20.1046 20.1046 21 19 21H14" fill="currentColor"/>
      <path d="M10 21H5C3.89543 21 3 20.1046 3 19V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V19C21 20.1046 20.1046 21 19 21H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 8V12.5L14 14.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle opacity="0.2" cx="9" cy="8" r="4" fill="currentColor"/>
      <circle cx="9" cy="8" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <circle opacity="0.2" cx="16" cy="19" r="4" fill="currentColor"/>
      <circle cx="16" cy="19" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12.1667 10.6667L10.8333 12L13.5 16.3333" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M4.1333 18C4.04687 17.6584 4 17.3042 4 16.9403C4 14.7638 5.79086 13 8 13H10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path opacity="0.2" d="M10 5C10 3.89543 10.8954 3 12 3C13.1046 3 14 3.89543 14 5C16.3402 5.2384 18.5556 6.43346 19.0871 8.39227C19.5568 10.1372 20 13.0301 20 15V18C20 18.5523 19.5523 19 19 19H5C4.44772 19 4 18.5523 4 18V15C4 13.0301 4.44316 10.1372 4.91285 8.39227C5.44437 6.43346 7.65983 5.2384 10 5Z" fill="currentColor"/>
      <path d="M10 5C10 3.89543 10.8954 3 12 3C13.1046 3 14 3.89543 14 5C16.3402 5.2384 18.5556 6.43346 19.0871 8.39227C19.5568 10.1372 20 13.0301 20 15V18C20 18.5523 19.5523 19 19 19H5C4.44772 19 4 18.5523 4 18V15C4 13.0301 4.44316 10.1372 4.91285 8.39227C5.44437 6.43346 7.65983 5.2384 10 5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8.5 19C8.5 20.6569 10.0147 22 12 22C13.9853 22 15.5 20.6569 15.5 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path opacity="0.2" d="M20 11.5C20 13.985 17.9628 16 14.5 16C14.1686 16 13.8448 15.9783 13.53 15.9378C12.9453 16.6147 11.7851 18 10.125 18C9.83691 18 9.55266 17.88 9.3409 17.6812C9.12914 17.4824 9 17.2157 9 16.9452C9 16.6746 9.12914 16.408 9.3409 16.2092C9.55266 16.0103 9.83691 15.8904 10.125 15.8904L10.1275 15.8916C10.1353 15.8998 10.1457 15.9067 10.1582 15.9122C10.1708 15.9178 10.1849 15.9218 10.1992 15.9242C10.2135 15.9267 10.2282 15.9276 10.2426 15.9268C10.257 15.9261 10.2705 15.9237 10.2824 15.9197L10.285 15.9184C10.7963 15.6766 11.1912 15.266 11.4 14.75C11.8216 13.615 11.7694 11.6538 11.4469 8.87152C11.3 7.6 11.8 5.80001 14.5 5.00001C17.9628 4.00001 20 9.01503 20 11.5Z" fill="currentColor"/>
      <path d="M10.125 16.5C9.90493 16.5 9.69375 16.579 9.53438 16.7197C9.375 16.8603 9.28125 17.0464 9.28125 17.2403C9.28125 17.4342 9.375 17.6203 9.53438 17.7609C9.69375 17.9016 9.90493 17.9806 10.125 17.9806C10.3451 17.9806 10.5563 17.9016 10.7156 17.7609C10.875 17.6203 10.9688 17.4342 10.9688 17.2403C10.9688 17.0464 10.875 16.8603 10.7156 16.7197C10.5563 16.579 10.3451 16.5 10.125 16.5ZM10.125 18C9.83691 18 9.55266 17.88 9.3409 17.6812C9.12914 17.4824 9 17.2157 9 16.9452C9 16.6746 9.12914 16.408 9.3409 16.2092C9.55266 16.0103 9.83691 15.8904 10.125 15.8904C10.4131 15.8904 10.6973 16.0103 10.9091 16.2092C11.1209 16.408 11.25 16.6746 11.25 16.9452C11.25 17.2157 11.1209 17.4824 10.9091 17.6812C10.6973 17.88 10.4131 18 10.125 18Z" fill="currentColor"/>
      <path d="M9.42038 15.3644C10.1255 13.8606 10.2577 11.3203 9.87982 8.13C9.69907 6.55944 10.3345 4.65494 13.3345 3.75002C17.1866 2.5798 19.5 8.01501 19.5 11.5C19.5 14.5443 16.9959 17 13 17C12.6055 17 12.2256 16.9707 11.8648 16.9157C10.9071 17.9106 9.29936 19.5 7.12499 19.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M10.125 16.5C9.90493 16.5 9.69375 16.579 9.53438 16.7197C9.375 16.8603 9.28125 17.0464 9.28125 17.2403C9.28125 17.4342 9.375 17.6203 9.53438 17.7609C9.69375 17.9016 9.90493 17.9806 10.125 17.9806" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M4.5 11.5C4.5 8.45572 7.00411 6 11 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path opacity="0.2" d="M19.4277 19.4268L15.2954 15.3355V15.3355C16.6996 13.9414 17.5 12.0144 17.5 10C17.5 6.41015 14.5899 3.5 11 3.5C7.41015 3.5 4.5 6.41015 4.5 10C4.5 13.5899 7.41015 16.5 11 16.5C13.0045 16.5 14.8216 15.7169 16.147 14.4305L16.1471 14.4305L20.2695 18.5555C20.6602 18.9465 21.2929 18.9467 21.6839 18.556C22.0752 18.165 22.0747 17.5318 21.6834 17.1411L19.4277 19.4268Z" fill="currentColor"/>
      <circle cx="11" cy="10" r="7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16.6539 16.6523L20.7072 20.7057" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
};

// Glassdoor inspired icon set
export const GlassdoorIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 22V12H15V22" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 7H4C3.44772 7 3 7.44772 3 8V19C3 19.5523 3.44772 20 4 20H20C20.5523 20 21 19.5523 21 19V8C21 7.44772 20.5523 7 20 7Z" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 7V5C16 4.44772 15.5523 4 15 4H9C8.44772 4 8 4.44772 8 5V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8 11H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M8 15H12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="7" r="4" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M5 21V19C5 17.9391 5.42143 16.9217 6.17157 16.1716C6.92172 15.4214 7.93913 15 9 15H15C16.0609 15 17.0783 15.4214 17.8284 16.1716C18.5786 16.9217 19 17.9391 19 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 15H15C16.0609 15 17.0783 15.4214 17.8284 16.1716C18.5786 16.9217 19 17.9391 19 19V21H5V19C5 17.9391 5.42143 16.9217 6.17157 16.1716C6.92172 15.4214 7.93913 15 9 15Z" fill="currentColor" fillOpacity="0.2"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 22C13.1 22 14 21.1 14 20H10C10 21.1 10.9 22 12 22Z" fill="currentColor"/>
      <path d="M18 16V11C18 7.93 16.37 5.36 13.5 4.68V4C13.5 3.17 12.83 2.5 12 2.5C11.17 2.5 10.5 3.17 10.5 4V4.68C7.64 5.36 6 7.92 6 11V16L4 18V19H20V18L18 16ZM16 17H8V11C8 8.52 9.51 6.5 12 6.5C14.49 6.5 16 8.52 16 11V17Z" fill="currentColor"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z" fill="currentColor" fillOpacity="0.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M22 6L12 13L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M11 19C15.4183 19 19 15.4183 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11C3 15.4183 6.58172 19 11 19Z" fill="currentColor" fillOpacity="0.1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M21 21L16.65 16.65" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  )
};

// ZipRecruiter/Facebook hybrid icon set
export const SocialJobIcons = {
  Home: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2.09961L1 12H4V21H10V15H14V21H20V12H23L12 2.09961Z" fill="currentColor" />
    </svg>
  ),
  Jobs: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 3H14V5H20C20.5523 5 21 5.44772 21 6V19C21 19.5523 20.5523 20 20 20H4C3.44772 20 3 19.5523 3 19V6C3 5.44772 3.44772 5 4 5H10V3Z" fill="currentColor"/>
      <rect x="7" y="9" width="10" height="2" rx="1" fill="white"/>
      <rect x="7" y="13" width="6" height="2" rx="1" fill="white"/>
    </svg>
  ),
  Network: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.5 13C18.9853 13 21 10.9853 21 8.5C21 6.01472 18.9853 4 16.5 4C14.0147 4 12 6.01472 12 8.5C12 10.9853 14.0147 13 16.5 13Z" fill="currentColor"/>
      <path d="M7.5 13C9.98528 13 12 10.9853 12 8.5C12 6.01472 9.98528 4 7.5 4C5.01472 4 3 6.01472 3 8.5C3 10.9853 5.01472 13 7.5 13Z" fill="currentColor"/>
      <path d="M7.5 13C4.5 13 3 14.5 3 17.5V20H12V17.5C12 14.5 10.5 13 7.5 13Z" fill="currentColor"/>
      <path d="M16.5 13C13.5 13 12 14.5 12 17.5V20H21V17.5C21 14.5 19.5 13 16.5 13Z" fill="currentColor"/>
    </svg>
  ),
  Notifications: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" clipRule="evenodd" d="M14 3V3.28988C16.8915 4.15043 19 6.82898 19 10V17H20V19H4V17H5V10C5 6.82898 7.10851 4.15043 10 3.28988V3C10 1.89543 10.8954 1 12 1C13.1046 1 14 1.89543 14 3ZM7 17H17V10C17 7.23858 14.7614 5 12 5C9.23858 5 7 7.23858 7 10V17ZM14 21V20H10V21C10 22.1046 10.8954 23 12 23C13.1046 23 14 22.1046 14 21Z" fill="currentColor"/>
    </svg>
  ),
  Messages: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2C6.477 2 2 5.954 2 10.9C2 13.363 3.095 15.553 4.968 17.117C4.731 18.036 4.001 20.05 3.553 21.004C3.371 21.409 3.734 21.873 4.172 21.761C5.607 21.408 8.383 20.613 9.523 20.124C10.301 20.303 11.116 20.4 11.955 20.4C17.478 20.4 21.955 16.446 21.955 11.5C21.955 6.554 17.523 2 12 2Z" fill="currentColor"/>
      <path d="M8.5 13.5C9.32843 13.5 10 12.8284 10 12C10 11.1716 9.32843 10.5 8.5 10.5C7.67157 10.5 7 11.1716 7 12C7 12.8284 7.67157 13.5 8.5 13.5Z" fill="white"/>
      <path d="M12 13.5C12.8284 13.5 13.5 12.8284 13.5 12C13.5 11.1716 12.8284 10.5 12 10.5C11.1716 10.5 10.5 11.1716 10.5 12C10.5 12.8284 11.1716 13.5 12 13.5Z" fill="white"/>
      <path d="M15.5 13.5C16.3284 13.5 17 12.8284 17 12C17 11.1716 16.3284 10.5 15.5 10.5C14.6716 10.5 14 11.1716 14 12C14 12.8284 14.6716 13.5 15.5 13.5Z" fill="white"/>
    </svg>
  ),
  Search: (props: IconProps) => (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" clipRule="evenodd" d="M10.5 18C14.6421 18 18 14.6421 18 10.5C18 6.35786 14.6421 3 10.5 3C6.35786 3 3 6.35786 3 10.5C3 14.6421 6.35786 18 10.5 18ZM10.5 20C15.7467 20 20 15.7467 20 10.5C20 5.25329 15.7467 1 10.5 1C5.25329 1 1 5.25329 1 10.5C1 15.7467 5.25329 20 10.5 20Z" fill="currentColor"/>
      <path d="M20 20L16 16" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
    </svg>
  )
};

export const IconSets = {
  modern: ModernIcons,
  creative: CreativeIcons,
  minimal: MinimalIcons,
  tech: TechIcons,
  glass: GlassIcons,
  glassdoor: GlassdoorIcons,
  socialJob: SocialJobIcons
};

export default IconSets;