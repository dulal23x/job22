import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Info, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import ConnectionRequest from "@/components/ConnectionRequest";
import JobItem from "@/components/JobItem";
import NewsItem from "@/components/NewsItem";

export default function RightSidebar() {
  // Fetch connection suggestions
  const { 
    data: suggestions = [],
    isLoading: suggestionsLoading
  } = useQuery({
    queryKey: ["/api/connections/suggestions"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Fetch job recommendations
  const { 
    data: jobs = [],
    isLoading: jobsLoading
  } = useQuery({
    queryKey: ["/api/jobs?limit=3"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Mock news data (in a real app, this would be fetched from the API)
  const newsItems = [
    {
      id: 1,
      title: "Tech layoffs continue as industry giants restructure",
      timeAgo: "4h ago",
      readers: 6234,
      imageUrl: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    },
    {
      id: 2,
      title: "Remote work trends in 2023: What employers need to know",
      timeAgo: "6h ago",
      readers: 3842,
      imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    },
    {
      id: 3,
      title: "AI adoption accelerates among small businesses",
      timeAgo: "9h ago",
      readers: 2518,
      imageUrl: "https://images.unsplash.com/photo-1535378917042-10a22c95931a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80"
    }
  ];
  
  return (
    <div className="w-80 flex-shrink-0">
      {/* News section */}
      <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-4">
        <div className="px-4 py-3 flex items-center justify-between">
          <h3 className="font-medium">Xubly News</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full">
            <Info className="h-4 w-4 text-neutral-500" />
          </Button>
        </div>
        
        <div className="border-t border-neutral-100">
          {newsItems.map((item, index) => (
            <NewsItem 
              key={item.id}
              item={item}
              isLast={index === newsItems.length - 1}
            />
          ))}
          
          <div className="px-4 py-2 border-t border-neutral-100">
            <Button variant="ghost" className="text-sm text-neutral-500 font-medium w-full justify-start">
              Show more <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* People You May Know */}
      {suggestions.length > 0 && (
        <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-4">
          <div className="px-4 py-3">
            <h3 className="font-medium">People you may know</h3>
          </div>
          
          <div className="border-t border-neutral-100">
            {suggestions.map((suggestion: any, index: number) => (
              <ConnectionRequest 
                key={suggestion.user.id}
                user={suggestion.user}
                mutualConnections={suggestion.mutualConnections}
                isLast={index === suggestions.length - 1}
              />
            ))}
            
            <div className="px-4 py-3">
              <Link href="/mynetwork">
                <Button variant="link" className="text-sm text-primary font-medium w-full">
                  View all recommendations
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
      
      {/* Job Recommendations */}
      {jobs.length > 0 && (
        <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-4">
          <div className="px-4 py-3 flex items-center justify-between">
            <h3 className="font-medium">Recommended jobs</h3>
            <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-neutral-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />
              </svg>
            </Button>
          </div>
          
          <div className="border-t border-neutral-100">
            {jobs.map((job: any, index: number) => (
              <JobItem 
                key={job.id}
                job={job}
                isLast={index === jobs.length - 1}
              />
            ))}
            
            <div className="px-4 py-3">
              <Link href="/jobs">
                <Button variant="link" className="text-sm text-primary font-medium hover:underline">
                  See all recommended jobs
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
      
      {/* Footer */}
      <div className="text-center text-xs text-neutral-500 mt-4">
        <div className="flex flex-wrap justify-center">
          <Link href="/about" className="px-2 py-1 hover:text-primary hover:underline">About</Link>
          <Link href="/accessibility" className="px-2 py-1 hover:text-primary hover:underline">Accessibility</Link>
          <Link href="/help" className="px-2 py-1 hover:text-primary hover:underline">Help Center</Link>
          <Link href="/privacy" className="px-2 py-1 hover:text-primary hover:underline">Privacy & Terms</Link>
          <Link href="/ads" className="px-2 py-1 hover:text-primary hover:underline">Ad Choices</Link>
          <Link href="/advertising" className="px-2 py-1 hover:text-primary hover:underline">Advertising</Link>
        </div>
        <div className="mt-2">
          <span>Xubly Corporation © {new Date().getFullYear()}</span>
        </div>
      </div>
    </div>
  );
}
