import { Notification } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

interface NotificationCardProps {
  notification: Notification;
  className?: string;
  isLast?: boolean;
}

export default function NotificationCard({ 
  notification, 
  className,
  isLast = false 
}: NotificationCardProps) {
  // Format the date to "X days/hours ago" format
  const timeAgo = formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true });
  
  return (
    <Card className={cn(
      "border-0 shadow-none hover:bg-neutral-50 transition-colors duration-200",
      !notification.read && "bg-primary/5",
      !isLast && "border-b rounded-none",
      className
    )}>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={notification.senderImage || ""} alt={notification.senderName || ""} />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
              {getInitials(notification.senderName || "")}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <Link href={notification.link || "#"} className="hover:underline">
                  <p className={cn(
                    "text-sm", 
                    !notification.read && "font-semibold"
                  )}>
                    <span className="font-semibold">{notification.senderName}</span>
                    {" "}{notification.content}
                  </p>
                </Link>
                
                <p className="text-xs text-neutral-500 mt-1">
                  {timeAgo}
                </p>
              </div>
              
              {!notification.read && (
                <div className="h-2.5 w-2.5 rounded-full bg-primary flex-shrink-0 mt-1.5"></div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Helper function to get user initials
function getInitials(name: string): string {
  if (!name) return "U";
  
  return name
    .split(" ")
    .slice(0, 2)
    .map(part => part.charAt(0))
    .join("")
    .toUpperCase();
}