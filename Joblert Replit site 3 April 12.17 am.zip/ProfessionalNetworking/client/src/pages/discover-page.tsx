import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/header";
import { Loader2, TrendingUp, Briefcase, UserPlus, UserCheck, Users, Hash, Calendar, Building, Newspaper, Lightbulb, BookOpen } from "lucide-react";
import { Link } from "wouter";

// Helper functions
const getItemIcon = (type: DiscoveryItem["type"]) => {
  switch (type) {
    case "person":
      return UserPlus;
    case "company":
      return Building;
    case "group":
      return Users;
    case "newsletter":
      return Newspaper;
    case "event":
      return Calendar;
    case "page":
      return Lightbulb;
    default:
      return Lightbulb;
  }
};

const getItemFallback = (title: string): string => {
  return title
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2);
};

interface DiscoveryCategory {
  id: number;
  name: string;
  icon: React.ElementType;
  count: number;
}

interface DiscoveryItem {
  id: number;
  title: string;
  subtitle: string;
  description?: string;
  image?: string;
  type: "person" | "company" | "group" | "newsletter" | "event" | "page";
  stats: {
    label: string;
    value: string;
  };
  isFollowing?: boolean;
}

export default function DiscoverPage() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  
  // Mock discovery categories
  const categories: DiscoveryCategory[] = [
    { id: 1, name: "People", icon: Users, count: 48 },
    { id: 2, name: "Companies", icon: Building, count: 35 },
    { id: 3, name: "Groups", icon: Users, count: 27 },
    { id: 4, name: "Events", icon: Calendar, count: 19 },
    { id: 5, name: "Newsletters", icon: Newspaper, count: 12 },
    { id: 6, name: "Hashtags", icon: Hash, count: 54 },
    { id: 7, name: "Learning", icon: BookOpen, count: 31 }
  ];
  
  // Mock trending discovery items
  const trendingItems: DiscoveryItem[] = [
    {
      id: 1,
      title: "Tech Innovations Daily",
      subtitle: "Tech News & Updates",
      description: "Get the latest tech news and updates delivered to your inbox every day.",
      type: "newsletter",
      stats: {
        label: "subscribers",
        value: "258K"
      }
    },
    {
      id: 2,
      title: "Global AI Conference",
      subtitle: "Virtual Event • May 15-17, 2025",
      description: "Join the world's leading AI experts for three days of insightful talks and workshops.",
      type: "event",
      stats: {
        label: "attendees",
        value: "12K"
      }
    },
    {
      id: 3,
      title: "Product Managers Network",
      subtitle: "Professional Group",
      description: "A community of product managers sharing insights and best practices.",
      type: "group",
      stats: {
        label: "members",
        value: "85K"
      }
    }
  ];
  
  // Mock for you discovery items
  const forYouItems: DiscoveryItem[] = [
    {
      id: 4,
      title: "Sarah Johnson",
      subtitle: "Senior UX Designer at Design Studios",
      type: "person",
      stats: {
        label: "connections",
        value: "2nd"
      }
    },
    {
      id: 5,
      title: "Innovate Tech Co.",
      subtitle: "Technology Company • 5,000+ employees",
      type: "company",
      stats: {
        label: "followers",
        value: "1.2M"
      },
      isFollowing: false
    },
    {
      id: 6,
      title: "Web Development Experts",
      subtitle: "Professional Group",
      type: "group",
      stats: {
        label: "members",
        value: "124K"
      }
    }
  ];
  
  // Mock industry specific items
  const industryItems: DiscoveryItem[] = [
    {
      id: 7,
      title: "Software Development Trends",
      subtitle: "Tech Industry Newsletter",
      type: "newsletter",
      stats: {
        label: "subscribers",
        value: "175K"
      }
    },
    {
      id: 8,
      title: "TechCorp",
      subtitle: "Software Company • 10,000+ employees",
      type: "company",
      stats: {
        label: "followers",
        value: "2.8M"
      },
      isFollowing: true
    },
    {
      id: 9,
      title: "Frontend Developers Community",
      subtitle: "Professional Group",
      type: "group",
      stats: {
        label: "members",
        value: "97K"
      }
    }
  ];
  
  // Helper functions are declared at the top of the file

  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 mt-16">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Discover what's new</h1>
          <p className="text-neutral-600">Explore people, companies, groups, and more based on your interests</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-1">
            <Card className="shadow-sm sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg">Browse categories</CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                <nav className="space-y-1.5">
                  {categories.map(category => (
                    <Button
                      key={category.id}
                      variant="ghost"
                      className="w-full justify-start h-auto py-2.5 px-3 font-medium text-base"
                    >
                      <category.icon className="h-5 w-5 mr-3 text-neutral-500" />
                      <span className="flex-1 text-left">{category.name}</span>
                      <span className="text-neutral-500 text-sm">{category.count}</span>
                    </Button>
                  ))}
                  <Button
                    variant="ghost"
                    className="w-full justify-start h-auto py-2.5 px-3 font-medium text-base"
                  >
                    <TrendingUp className="h-5 w-5 mr-3 text-neutral-500" />
                    <span className="flex-1 text-left">Trending</span>
                  </Button>
                </nav>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-3">
            <Card className="shadow-sm mb-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">Discover more on Xubly</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="for-you" className="w-full">
                  <TabsList className="w-full mb-6">
                    <TabsTrigger value="for-you" className="flex-1">For You</TabsTrigger>
                    <TabsTrigger value="trending" className="flex-1">Trending</TabsTrigger>
                    <TabsTrigger value="industry" className="flex-1">Industry Specific</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="for-you">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {forYouItems.map(item => (
                          <DiscoveryCard key={item.id} item={item} />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="trending">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {trendingItems.map(item => (
                          <DiscoveryCard key={item.id} item={item} />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="industry">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {industryItems.map(item => (
                          <DiscoveryCard key={item.id} item={item} />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm mb-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">People you may know</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="overflow-hidden shadow-sm">
                      <div className="h-20 bg-gradient-to-r from-primary/30 to-primary/10"></div>
                      <CardContent className="pt-0">
                        <div className="-mt-10 mb-3">
                          <Avatar className="h-16 w-16 border-4 border-white">
                            <AvatarFallback>JS</AvatarFallback>
                          </Avatar>
                        </div>
                        <h3 className="font-semibold">John Smith</h3>
                        <p className="text-sm text-neutral-600 line-clamp-2">Software Engineer at Tech Company</p>
                        <div className="flex items-center text-xs text-neutral-500 mt-2 mb-4">
                          <Users className="h-3.5 w-3.5 mr-1" />
                          <span>12 mutual connections</span>
                        </div>
                        <Button className="w-full" variant="outline">Connect</Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="text-center mt-4">
                  <Button variant="link">Show more</Button>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl">Jobs for you</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[...Array(3)].map((_, i) => (
                    <Card key={i} className="border shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3 mb-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>TC</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold">Senior Developer</h3>
                            <p className="text-sm text-neutral-600">Tech Company</p>
                            <p className="text-sm text-neutral-500">San Francisco, CA (Remote)</p>
                          </div>
                        </div>
                        <div className="text-sm text-neutral-600 mb-3">
                          <p className="line-clamp-3">
                            We're looking for an experienced developer to join our team and help build innovative solutions.
                          </p>
                        </div>
                        <div className="flex justify-between items-center text-xs text-neutral-500">
                          <span>3 days ago</span>
                          <span>128 applicants</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="text-center mt-4">
                  <Link href="/jobs">
                    <Button>View all jobs</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

interface DiscoveryCardProps {
  item: DiscoveryItem;
}

function DiscoveryCard({ item }: DiscoveryCardProps) {
  const Icon = getItemIcon(item.type);
  
  return (
    <Card className="shadow-sm h-full flex flex-col">
      <CardContent className="p-4 flex-1 flex flex-col">
        <div className="flex items-start gap-3 mb-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={item.image} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {getItemFallback(item.title)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="font-semibold">{item.title}</h3>
            <p className="text-sm text-neutral-600">{item.subtitle}</p>
            <div className="flex items-center text-xs text-neutral-500 mt-1">
              <span>{item.stats.value} {item.stats.label}</span>
            </div>
          </div>
        </div>
        
        {item.description && (
          <p className="text-sm text-neutral-600 mb-3 flex-1">
            {item.description}
          </p>
        )}
        
        <div className="mt-auto pt-3">
          {item.isFollowing ? (
            <Button variant="outline" className="w-full gap-1">
              <UserCheck className="h-4 w-4" />
              <span>Following</span>
            </Button>
          ) : (
            <Button className="w-full gap-1">
              {item.type === "person" ? (
                <>
                  <UserPlus className="h-4 w-4" />
                  <span>Connect</span>
                </>
              ) : (
                <>
                  <Icon className="h-4 w-4" />
                  <span>Follow</span>
                </>
              )}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}