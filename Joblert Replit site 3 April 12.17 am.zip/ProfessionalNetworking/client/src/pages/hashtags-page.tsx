import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/header";
import { Loader2, Search, Hash, Trash2, Plus, TrendingUp, ChevronRight, Users } from "lucide-react";

interface Hashtag {
  id: number;
  name: string;
  followers: number;
  posts: number;
  isFollowing: boolean;
}

interface HashtagGroup {
  id: number;
  name: string;
  hashtags: Hashtag[];
}

export default function HashtagsPage() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock followed hashtags data
  const followedHashtags: Hashtag[] = [
    {
      id: 1,
      name: "technology",
      followers: 18463258,
      posts: 3428,
      isFollowing: true
    },
    {
      id: 2,
      name: "webdevelopment",
      followers: 5287493,
      posts: 836,
      isFollowing: true
    },
    {
      id: 3,
      name: "productivity",
      followers: 9274583,
      posts: 1247,
      isFollowing: true
    }
  ];
  
  // Mock hashtag groups by topics
  const hashtagGroups: HashtagGroup[] = [
    {
      id: 1,
      name: "Technology",
      hashtags: [
        {
          id: 4,
          name: "ai",
          followers: 15742638,
          posts: 2734,
          isFollowing: false
        },
        {
          id: 5,
          name: "machinelearning",
          followers: 8452713,
          posts: 1526,
          isFollowing: false
        },
        {
          id: 6,
          name: "programming",
          followers: 12583945,
          posts: 2837,
          isFollowing: false
        }
      ]
    },
    {
      id: 2,
      name: "Business",
      hashtags: [
        {
          id: 7,
          name: "leadership",
          followers: 11582638,
          posts: 1984,
          isFollowing: false
        },
        {
          id: 8,
          name: "startup",
          followers: 6285913,
          posts: 1147,
          isFollowing: false
        },
        {
          id: 9,
          name: "management",
          followers: 9458372,
          posts: 1634,
          isFollowing: false
        }
      ]
    }
  ];
  
  // Trending hashtags
  const trendingHashtags: Hashtag[] = [
    {
      id: 10,
      name: "sustainability",
      followers: 7583913,
      posts: 842,
      isFollowing: false
    },
    {
      id: 11,
      name: "remotework",
      followers: 5893284,
      posts: 743,
      isFollowing: false
    },
    {
      id: 12,
      name: "futureofwork",
      followers: 8457293,
      posts: 1243,
      isFollowing: false
    }
  ];
  
  const filteredHashtags = (hashtags: Hashtag[]) => {
    if (!searchQuery) return hashtags;
    return hashtags.filter(hashtag => 
      hashtag.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 mt-16">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-2/3">
            <Card className="shadow-sm mb-4">
              <CardHeader>
                <div className="flex justify-between items-center mb-4">
                  <h1 className="text-2xl font-bold">Followed Hashtags</h1>
                </div>
                
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <Input 
                    placeholder="Search hashtags" 
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </CardHeader>
              
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : followedHashtags.length > 0 ? (
                  <div className="space-y-4">
                    {filteredHashtags(followedHashtags).map(hashtag => (
                      <HashtagItem key={hashtag.id} hashtag={hashtag} isFollowing />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 px-6 bg-neutral-50 rounded-lg border border-dashed border-neutral-200">
                    <Hash className="h-10 w-10 text-neutral-300 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold mb-2">No followed hashtags yet</h3>
                    <p className="text-neutral-600 mb-6">
                      Follow hashtags to see content that interests you
                    </p>
                    <Button className="bg-primary hover:bg-primary/90">
                      Discover hashtags
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card className="shadow-sm mb-4">
              <CardHeader>
                <CardTitle className="text-xl">Discover hashtags by topic</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {hashtagGroups.map(group => (
                    <div key={group.id}>
                      <h3 className="font-semibold text-lg mb-3">{group.name}</h3>
                      <div className="space-y-3">
                        {group.hashtags.map(hashtag => (
                          <HashtagItem key={hashtag.id} hashtag={hashtag} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="w-full md:w-1/3">
            <Card className="shadow-sm mb-4">
              <CardHeader>
                <CardTitle className="text-lg">Trending hashtags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {trendingHashtags.map(hashtag => (
                    <div key={hashtag.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                          <Hash className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">#{hashtag.name}</p>
                          <p className="text-xs text-neutral-500">{hashtag.followers.toLocaleString()} followers</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="h-8">
                        Follow
                      </Button>
                    </div>
                  ))}
                </div>
                <Button variant="link" className="w-full mt-4 pl-0">
                  View all trending
                </Button>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Hashtags your network follows</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {hashtagGroups[0].hashtags.slice(0, 3).map(hashtag => (
                    <div key={hashtag.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                          <Hash className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">#{hashtag.name}</p>
                          <div className="flex items-center">
                            <Users className="h-3 w-3 text-neutral-500 mr-1" />
                            <p className="text-xs text-neutral-500">25 connections follow</p>
                          </div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="h-8">
                        Follow
                      </Button>
                    </div>
                  ))}
                </div>
                <Button variant="link" className="w-full mt-4 pl-0">
                  View all
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

interface HashtagItemProps {
  hashtag: Hashtag;
  isFollowing?: boolean;
}

function HashtagItem({ hashtag, isFollowing }: HashtagItemProps) {
  return (
    <div className="flex items-center justify-between p-3 hover:bg-neutral-50 rounded-md transition-colors">
      <div className="flex items-center">
        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-4">
          <Hash className="h-5 w-5 text-primary" />
        </div>
        <div>
          <p className="font-medium">#{hashtag.name}</p>
          <div className="flex items-center text-sm text-neutral-500">
            <span>{hashtag.followers.toLocaleString()} followers</span>
            <span className="mx-2">•</span>
            <span>{hashtag.posts.toLocaleString()} posts this week</span>
          </div>
        </div>
      </div>
      {isFollowing ? (
        <Button variant="outline" size="sm" className="gap-1">
          <Trash2 className="h-4 w-4" />
          <span className="hidden sm:inline">Unfollow</span>
        </Button>
      ) : (
        <Button size="sm" className="gap-1">
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Follow</span>
        </Button>
      )}
    </div>
  );
}