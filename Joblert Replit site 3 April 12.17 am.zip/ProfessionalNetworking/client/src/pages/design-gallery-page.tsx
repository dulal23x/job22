import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  ArrowRight, 
  Heart, 
  Bookmark, 
  Settings,
  LogOut,
  User,
  MessageSquare,
  Briefcase,
  Users,
  Bell,
  Search
} from "lucide-react";
import IconSets, { 
  ModernIcons, 
  CreativeIcons, 
  MinimalIcons, 
  TechIcons, 
  GlassIcons,
  GlassdoorIcons,
  SocialJobIcons
} from "@/components/design-gallery/custom-icons";

// Design themes
const designThemes = [
  {
    id: 1,
    name: "Modern Professional",
    description: "Clean and professional design inspired by LinkedIn with blue color palette",
    primaryColor: "#0a66c2",
    secondaryColor: "#e7f3ff",
    tertiaryColor: "#003e82",
    backgroundImage: "linear-gradient(135deg, #f5f7fa 0%, #e4ecfb 100%)",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.375rem",
    cardShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
    icons: {
      home: ModernIcons.Home,
      jobs: ModernIcons.Jobs,
      network: ModernIcons.Network,
      notifications: ModernIcons.Notifications,
      messages: ModernIcons.Messages,
      search: ModernIcons.Search
    }
  },
  {
    id: 2,
    name: "Vibrant Creative",
    description: "Bold and vibrant design for creative professionals with purple accents",
    primaryColor: "#7928ca",
    secondaryColor: "#ffd8fc",
    tertiaryColor: "#4a1d96",
    backgroundImage: "linear-gradient(120deg, #f6d365 0%, #fda085 100%)",
    fontFamily: "'Poppins', sans-serif",
    borderRadius: "1rem",
    cardShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
    icons: {
      home: CreativeIcons.Home,
      jobs: CreativeIcons.Jobs,
      network: CreativeIcons.Network,
      notifications: CreativeIcons.Notifications,
      messages: CreativeIcons.Messages,
      search: CreativeIcons.Search
    }
  },
  {
    id: 3,
    name: "Corporate Clean",
    description: "Minimalist design inspired by Indeed with green accents",
    primaryColor: "#2e7d32",
    secondaryColor: "#e8f5e9",
    tertiaryColor: "#1b5e20",
    backgroundImage: "linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%)",
    fontFamily: "'Roboto', sans-serif",
    borderRadius: "0.25rem",
    cardShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",
    icons: {
      home: MinimalIcons.Home,
      jobs: MinimalIcons.Jobs,
      network: MinimalIcons.Network,
      notifications: MinimalIcons.Notifications,
      messages: MinimalIcons.Messages,
      search: MinimalIcons.Search
    }
  },
  {
    id: 4,
    name: "Dark Mode Tech",
    description: "Modern dark mode interface inspired by tech companies",
    primaryColor: "#ff4081",
    secondaryColor: "#424242",
    tertiaryColor: "#303030",
    backgroundImage: "linear-gradient(60deg, #29323c 0%, #485563 100%)",
    fontFamily: "'SF Pro Display', system-ui, sans-serif",
    borderRadius: "0.5rem",
    cardShadow: "0 4px 20px 0 rgba(0, 0, 0, 0.2)",
    icons: {
      home: TechIcons.Home,
      jobs: TechIcons.Jobs,
      network: TechIcons.Network,
      notifications: TechIcons.Notifications,
      messages: TechIcons.Messages,
      search: TechIcons.Search
    }
  },
  {
    id: 5,
    name: "Glassmorphism Future",
    description: "Modern glassmorphism design with blurred elements and teal accents",
    primaryColor: "#06b6d4",
    secondaryColor: "#ecfeff",
    tertiaryColor: "#0e7490",
    backgroundImage: "linear-gradient(45deg, #93a5cf 0%, #e4efe9 100%)",
    fontFamily: "'Montserrat', sans-serif",
    borderRadius: "0.75rem",
    cardShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.15)",
    icons: {
      home: GlassIcons.Home,
      jobs: GlassIcons.Jobs,
      network: GlassIcons.Network,
      notifications: GlassIcons.Notifications,
      messages: GlassIcons.Messages,
      search: GlassIcons.Search
    }
  },
  {
    id: 6,
    name: "Glassdoor Inspired",
    description: "Professional job search interface inspired by Glassdoor with teal accents",
    primaryColor: "#0caa41",
    secondaryColor: "#e0f7ea",
    tertiaryColor: "#0a855c",
    backgroundImage: "linear-gradient(to right, #f5f7fa 0%, #e8f4f8 100%)",
    fontFamily: "'Nunito Sans', sans-serif",
    borderRadius: "0.375rem",
    cardShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
    icons: {
      home: GlassdoorIcons.Home,
      jobs: GlassdoorIcons.Jobs,
      network: GlassdoorIcons.Network,
      notifications: GlassdoorIcons.Notifications,
      messages: GlassdoorIcons.Messages,
      search: GlassdoorIcons.Search
    }
  },
  {
    id: 7,
    name: "Social Job Connect",
    description: "A hybrid design inspired by Facebook and ZipRecruiter for networking and job search",
    primaryColor: "#1877f2",
    secondaryColor: "#e7f3ff",
    tertiaryColor: "#166fe5",
    backgroundImage: "linear-gradient(to bottom, #ffffff 0%, #f0f2f5 100%)",
    fontFamily: "'Segoe UI', 'Helvetica Neue', sans-serif",
    borderRadius: "0.5rem",
    cardShadow: "0 1px 2px rgba(0, 0, 0, 0.2)",
    icons: {
      home: SocialJobIcons.Home,
      jobs: SocialJobIcons.Jobs,
      network: SocialJobIcons.Network,
      notifications: SocialJobIcons.Notifications,
      messages: SocialJobIcons.Messages,
      search: SocialJobIcons.Search
    }
  }
];

export default function DesignGalleryPage() {
  const { user } = useAuth();
  const [currentDesign, setCurrentDesign] = useState(0);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const theme = designThemes[currentDesign];
  
  const nextDesign = () => {
    setCurrentDesign((prev) => (prev + 1) % designThemes.length);
  };
  
  const prevDesign = () => {
    setCurrentDesign((prev) => (prev - 1 + designThemes.length) % designThemes.length);
  };
  
  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold mb-4">JobAlert Design Gallery</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore 5 different design concepts for JobAlert. Toggle between logged-in and public views to see the difference.
          </p>
          
          <div className="mt-6 flex items-center justify-center gap-4">
            <Label htmlFor="user-view">Logged-in View</Label>
            <Switch 
              id="user-view" 
              checked={isLoggedIn} 
              onCheckedChange={setIsLoggedIn} 
            />
          </div>
        </div>
        
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{theme.name}</h2>
            <p className="text-gray-600">{theme.description}</p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={prevDesign}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            <Button onClick={nextDesign}>
              Next
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>
        
        <Card className="overflow-hidden border-0" style={{ 
          boxShadow: theme.cardShadow,
          borderRadius: theme.borderRadius,
        }}>
          <CardHeader className="p-0">
            {/* Header section */}
            <div 
              style={{ 
                backgroundColor: theme.primaryColor,
                color: "white",
                fontFamily: theme.fontFamily
              }}
              className="p-4 flex items-center justify-between"
            >
              <div className="flex items-center">
                <span className="text-xl font-bold">JobAlert</span>
              </div>
              
              <div className="flex items-center gap-4">
                {isLoggedIn ? (
                  <>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <theme.icons.home className="h-5 w-5" />
                      Home
                    </Button>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <theme.icons.jobs className="h-5 w-5" />
                      Jobs
                    </Button>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <theme.icons.network className="h-5 w-5" />
                      Network
                    </Button>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <theme.icons.messages className="h-5 w-5" />
                      Messages
                    </Button>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <theme.icons.notifications className="h-5 w-5" />
                      Notifications
                    </Button>
                    <Button 
                      variant="ghost"
                      style={{ color: "white" }}
                      className="flex flex-col items-center gap-1 text-xs"
                    >
                      <User className="h-5 w-5" />
                      Profile
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="ghost" style={{ color: "white" }}>
                      Login
                    </Button>
                    <Button 
                      style={{ 
                        backgroundColor: "white", 
                        color: theme.primaryColor
                      }}
                    >
                      Sign Up
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            {isLoggedIn ? (
              <div className="p-6 grid grid-cols-12 gap-6">
                {/* Logged in view */}
                <div className="col-span-3">
                  <Card style={{ borderRadius: theme.borderRadius }}>
                    <CardContent className="p-4">
                      <div className="flex flex-col items-center text-center mb-4">
                        <div 
                          className="w-20 h-20 rounded-full mb-3 flex items-center justify-center text-white text-xl font-bold"
                          style={{ backgroundColor: theme.primaryColor }}
                        >
                          {user?.fullName?.charAt(0) || "U"}
                        </div>
                        <h3 className="font-semibold text-lg">{user?.fullName || "User Name"}</h3>
                        <p className="text-sm text-gray-500">Software Developer</p>
                      </div>
                      
                      <div className="border-t border-gray-200 pt-3 mt-2">
                        <div className="text-sm">
                          <div className="flex justify-between mb-2">
                            <span>Profile Views</span>
                            <span className="font-medium">128</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Connections</span>
                            <span className="font-medium">43</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card style={{ borderRadius: theme.borderRadius }} className="mt-4">
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-3">Suggested Jobs</h3>
                      {[1, 2, 3].map((i) => (
                        <div key={i} className={`${i < 3 ? 'border-b border-gray-200 pb-3 mb-3' : ''}`}>
                          <h4 className="font-medium">Senior Developer</h4>
                          <div className="text-sm text-gray-500">TechCorp Inc.</div>
                          <div className="text-sm text-gray-500">San Francisco, CA</div>
                          <div className="mt-1 text-xs" style={{ color: theme.primaryColor }}>
                            $120K - $150K • Remote
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
                
                <div className="col-span-6">
                  <Card style={{ borderRadius: theme.borderRadius }}>
                    <CardContent className="p-4">
                      <div 
                        className="mb-4 p-3 rounded-lg"
                        style={{ backgroundColor: theme.secondaryColor }}
                      >
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold"
                            style={{ backgroundColor: theme.primaryColor }}
                          >
                            {user?.fullName?.charAt(0) || "U"}
                          </div>
                          <div className="flex-1">
                            <input 
                              type="text" 
                              placeholder="Share what's on your mind..." 
                              className="w-full p-2 border border-gray-200 rounded-md focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>
                      
                      {[1, 2].map((i) => (
                        <div key={i} className={`${i < 2 ? 'border-b border-gray-200 pb-4 mb-4' : ''}`}>
                          <div className="flex items-start gap-3">
                            <div 
                              className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center text-white text-sm font-bold"
                              style={{ backgroundColor: theme.tertiaryColor }}
                            >
                              A
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-semibold">Alex Johnson</span>
                                <span className="text-xs text-gray-500">• Software Engineer at Google</span>
                              </div>
                              <p className="mt-1 text-sm">
                                Just finished a great project using React and TypeScript. 
                                The new hooks API is really making front-end development more enjoyable!
                              </p>
                              
                              <div className="mt-3 flex gap-4">
                                <button className="text-xs flex items-center gap-1 text-gray-500">
                                  <Heart className="h-4 w-4" />
                                  <span>42</span>
                                </button>
                                <button className="text-xs flex items-center gap-1 text-gray-500">
                                  <MessageSquare className="h-4 w-4" />
                                  <span>8 comments</span>
                                </button>
                                <button className="text-xs flex items-center gap-1 text-gray-500">
                                  <Bookmark className="h-4 w-4" />
                                  <span>Save</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </div>
                
                <div className="col-span-3">
                  <Card style={{ borderRadius: theme.borderRadius }}>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-3">Connection Requests</h3>
                      {[1, 2].map((i) => (
                        <div key={i} className={`flex items-center gap-3 ${i < 2 ? 'border-b border-gray-200 pb-3 mb-3' : ''}`}>
                          <div 
                            className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold"
                            style={{ backgroundColor: theme.tertiaryColor }}
                          >
                            {i === 1 ? 'S' : 'M'}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{i === 1 ? 'Sarah Miller' : 'Mark Wilson'}</div>
                            <div className="text-xs text-gray-500">Product Designer</div>
                            <div className="mt-2 flex gap-2">
                              <Button 
                                size="sm" 
                                style={{ 
                                  backgroundColor: theme.primaryColor,
                                  fontSize: '0.7rem',
                                  padding: '0 0.5rem',
                                  height: '1.5rem'
                                }}
                              >
                                Accept
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                style={{ 
                                  fontSize: '0.7rem',
                                  padding: '0 0.5rem',
                                  height: '1.5rem'
                                }}
                              >
                                Ignore
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                  
                  <Card style={{ borderRadius: theme.borderRadius }} className="mt-4">
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-3">Industry News</h3>
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-sm">Tech Industry Growth Surges</h4>
                          <p className="text-xs text-gray-500">New report shows 15% growth in tech hiring...</p>
                        </div>
                        <div>
                          <h4 className="font-medium text-sm">Remote Work Trends for 2025</h4>
                          <p className="text-xs text-gray-500">Companies adapting to hybrid models...</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <div>
                {/* Public landing page */}
                <div
                  className="p-10 flex flex-col items-center text-center"
                  style={{ 
                    backgroundImage: theme.backgroundImage,
                    minHeight: "400px"
                  }}
                >
                  <h1 
                    className="text-4xl md:text-5xl font-bold mb-4" 
                    style={{ 
                      color: theme.primaryColor,
                      fontFamily: theme.fontFamily
                    }}
                  >
                    Find Your Dream Job with JobAlert
                  </h1>
                  
                  <p className="text-xl mb-8 max-w-2xl" style={{ fontFamily: theme.fontFamily }}>
                    Connect with top employers, build your professional network, 
                    and discover opportunities that match your skills and aspirations.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
                    <div className="relative flex-1">
                      <theme.icons.search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input 
                        type="text" 
                        placeholder="Job title, keyword, or company" 
                        className="w-full pl-10 p-3 rounded-md focus:outline-none border border-gray-300"
                        style={{ borderRadius: theme.borderRadius }}
                      />
                    </div>
                    <Button 
                      style={{ 
                        backgroundColor: theme.primaryColor,
                        borderRadius: theme.borderRadius,
                        fontFamily: theme.fontFamily
                      }}
                      className="px-6"
                    >
                      Search Jobs
                    </Button>
                  </div>
                  
                  <div className="mt-8 flex flex-wrap justify-center gap-3">
                    <Button variant="outline" size="sm">Software Developer</Button>
                    <Button variant="outline" size="sm">Data Scientist</Button>
                    <Button variant="outline" size="sm">Product Manager</Button>
                    <Button variant="outline" size="sm">UX Designer</Button>
                    <Button variant="outline" size="sm">Marketing</Button>
                  </div>
                </div>
                
                <div className="p-10">
                  <h2 
                    className="text-2xl font-bold mb-6 text-center"
                    style={{ 
                      color: theme.primaryColor,
                      fontFamily: theme.fontFamily
                    }}
                  >
                    Why Job Seekers Love JobAlert
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card 
                      style={{ 
                        borderRadius: theme.borderRadius,
                        boxShadow: theme.cardShadow
                      }}
                    >
                      <CardContent className="pt-6">
                        <div 
                          className="w-12 h-12 rounded-full mb-4 flex items-center justify-center"
                          style={{ backgroundColor: theme.secondaryColor }}
                        >
                          <Briefcase 
                            className="h-6 w-6"
                            style={{ color: theme.primaryColor }}
                          />
                        </div>
                        <h3 
                          className="text-lg font-semibold mb-2"
                          style={{ fontFamily: theme.fontFamily }}
                        >
                          Thousands of Jobs
                        </h3>
                        <p className="text-gray-600">
                          Access thousands of job listings across all industries and career levels.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card 
                      style={{ 
                        borderRadius: theme.borderRadius,
                        boxShadow: theme.cardShadow
                      }}
                    >
                      <CardContent className="pt-6">
                        <div 
                          className="w-12 h-12 rounded-full mb-4 flex items-center justify-center"
                          style={{ backgroundColor: theme.secondaryColor }}
                        >
                          <Users 
                            className="h-6 w-6"
                            style={{ color: theme.primaryColor }}
                          />
                        </div>
                        <h3 
                          className="text-lg font-semibold mb-2"
                          style={{ fontFamily: theme.fontFamily }}
                        >
                          Career Network
                        </h3>
                        <p className="text-gray-600">
                          Build your professional network and connect with industry peers.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card 
                      style={{ 
                        borderRadius: theme.borderRadius,
                        boxShadow: theme.cardShadow
                      }}
                    >
                      <CardContent className="pt-6">
                        <div 
                          className="w-12 h-12 rounded-full mb-4 flex items-center justify-center"
                          style={{ backgroundColor: theme.secondaryColor }}
                        >
                          <Settings 
                            className="h-6 w-6"
                            style={{ color: theme.primaryColor }}
                          />
                        </div>
                        <h3 
                          className="text-lg font-semibold mb-2"
                          style={{ fontFamily: theme.fontFamily }}
                        >
                          Smart Tools
                        </h3>
                        <p className="text-gray-600">
                          Use AI-powered tools to improve your resume and application success rate.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="mt-8 grid grid-cols-5 gap-4">
          {designThemes.map((design, index) => (
            <Button
              key={design.id}
              variant={currentDesign === index ? "default" : "outline"}
              onClick={() => setCurrentDesign(index)}
              style={currentDesign === index ? { backgroundColor: design.primaryColor } : {}}
              className="h-auto py-3"
            >
              <div className="text-center">
                <div className="font-semibold">{design.name}</div>
                <div 
                  className="mt-2 mx-auto w-full h-2 rounded"
                  style={{ backgroundColor: design.primaryColor }}
                />
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}