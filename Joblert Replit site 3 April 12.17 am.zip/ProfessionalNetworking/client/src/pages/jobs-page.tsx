import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { Job } from "@shared/schema";

import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import JobCard from "@/components/jobs/job-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, MapPin } from "lucide-react";

export default function JobsPage() {
  const { user } = useAuth();
  const [unreadNotifications, setUnreadNotifications] = useState(3);
  const [searchQuery, setSearchQuery] = useState("");
  const [location, setLocation] = useState("");
  const [timeframe, setTimeframe] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  
  // Build the query URL with search parameters
  const buildQueryUrl = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.append("search", searchQuery);
    if (location) params.append("location", location);
    if (timeframe) params.append("timeframe", timeframe);
    
    return `/api/jobs${params.toString() ? `?${params.toString()}` : ''}`;
  };
  
  // Fetch jobs based on search criteria
  const {
    data: jobs,
    isLoading,
    error,
    refetch
  } = useQuery<Job[]>({
    queryKey: ["/api/jobs", { search: searchQuery, location, timeframe }],
    // Enable the query regardless of authentication status
  });
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    refetch().finally(() => setIsSearching(false));
  };
  
  const handleJobApplication = () => {
    if (!user) {
      // Redirect to login page with return URL
      window.location.href = `/auth?returnTo=${encodeURIComponent(window.location.pathname)}`;
      return;
    }
    // Handle job application logic
  };
  
  return (
    <>
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 relative pb-16 md:pb-0">
        <div className="flex flex-col md:flex-row gap-5">
          {/* Left Sidebar (desktop only) - Removed for now */}
          
          {/* Main content */}
          <div className="w-full md:max-w-4xl flex-1">
            <h1 className="text-2xl font-bold mb-4">Jobs</h1>
            
            {/* Search Card */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Find your next opportunity</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSearch} className="space-y-4">
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                        <Input
                          placeholder="Search job titles, companies, or keywords"
                          className="pl-10"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                        <Input
                          placeholder="Location (city, state, or remote)"
                          className="pl-10"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <Select value={timeframe} onValueChange={setTimeframe}>
                      <SelectTrigger className="w-full md:w-[200px]">
                        <SelectValue placeholder="Date posted" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24h">Past 24 hours</SelectItem>
                        <SelectItem value="week">Past week</SelectItem>
                        <SelectItem value="month">Past month</SelectItem>
                        <SelectItem value="any">Any time</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Button type="submit" disabled={isSearching}>
                      {isSearching ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Search className="mr-2 h-4 w-4" />
                      )}
                      Search
                    </Button>
                  </div>
                  
                  {/* Active filters */}
                  {(searchQuery || location || timeframe) && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {searchQuery && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <span>{searchQuery}</span>
                          <button
                            type="button"
                            onClick={() => setSearchQuery("")}
                            className="ml-1 h-4 w-4 rounded-full bg-neutral-200 text-neutral-500 inline-flex items-center justify-center hover:bg-neutral-300"
                          >
                            <span className="sr-only">Remove</span>
                            <i className="fas fa-times text-xs"></i>
                          </button>
                        </Badge>
                      )}
                      
                      {location && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <span>{location}</span>
                          <button
                            type="button"
                            onClick={() => setLocation("")}
                            className="ml-1 h-4 w-4 rounded-full bg-neutral-200 text-neutral-500 inline-flex items-center justify-center hover:bg-neutral-300"
                          >
                            <span className="sr-only">Remove</span>
                            <i className="fas fa-times text-xs"></i>
                          </button>
                        </Badge>
                      )}
                      
                      {timeframe && (
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <span>
                            {timeframe === "24h" ? "Past 24 hours" : 
                             timeframe === "week" ? "Past week" : 
                             timeframe === "month" ? "Past month" : "Any time"}
                          </span>
                          <button
                            type="button"
                            onClick={() => setTimeframe("")}
                            className="ml-1 h-4 w-4 rounded-full bg-neutral-200 text-neutral-500 inline-flex items-center justify-center hover:bg-neutral-300"
                          >
                            <span className="sr-only">Remove</span>
                            <i className="fas fa-times text-xs"></i>
                          </button>
                        </Badge>
                      )}
                      
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSearchQuery("");
                          setLocation("");
                          setTimeframe("");
                        }}
                        className="text-xs"
                      >
                        Clear all
                      </Button>
                    </div>
                  )}
                </form>
              </CardContent>
            </Card>
            
            {/* Job Results */}
            <Card>
              <CardHeader>
                <CardTitle>Job Results {jobs && jobs.length > 0 ? `(${jobs.length})` : ""}</CardTitle>
              </CardHeader>
              <Separator />
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : error ? (
                  <div className="p-6 text-center text-neutral-500">
                    Error loading jobs.
                  </div>
                ) : jobs && jobs.length > 0 ? (
                  jobs.map((job, index) => (
                    <JobCard 
                      key={job.id} 
                      job={job} 
                      isLast={index === jobs.length - 1}
                    />
                  ))
                ) : (
                  <div className="p-6 text-center text-neutral-500">
                    No jobs found matching your criteria. Try broadening your search.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      {/* Remove Mobile Navigation for now */}
    </>
  );
}
