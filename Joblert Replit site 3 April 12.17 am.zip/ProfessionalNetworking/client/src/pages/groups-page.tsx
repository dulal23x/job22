import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Header from "@/components/layout/header";
import { Loader2, Search, Users, Plus, BellOff, UserPlus, Lock } from "lucide-react";

interface Group {
  id: number;
  name: string;
  members: number;
  avatar?: string;
  description: string;
  isPrivate: boolean;
  isMember: boolean;
}

export default function GroupsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("my-groups");
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock groups data
  const myGroups: Group[] = [];
  
  const suggestedGroups: Group[] = [
    {
      id: 1,
      name: "Web Development Professionals",
      members: 15482,
      description: "A community for web developers to share knowledge, ask questions, and network with peers.",
      isPrivate: false,
      isMember: false
    },
    {
      id: 2,
      name: "UX/UI Designers Hub",
      members: 8794,
      description: "Connect with UX/UI designers from around the world to discuss trends, tools, and techniques.",
      isPrivate: false,
      isMember: false
    },
    {
      id: 3,
      name: "Product Management Leaders",
      members: 12305,
      description: "A group for product managers to share insights, resources, and best practices.",
      isPrivate: true,
      isMember: false
    }
  ];
  
  // Function to get initials from group name
  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const filteredGroups = (groups: Group[]) => {
    if (!searchQuery) return groups;
    return groups.filter(group => 
      group.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      group.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 mt-16">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-2/3">
            <Card className="shadow-sm mb-4">
              <CardHeader className="pb-0">
                <div className="flex justify-between items-center mb-4">
                  <h1 className="text-2xl font-bold">Groups</h1>
                  <Button size="sm" className="gap-1">
                    <Plus className="h-4 w-4" /> Create Group
                  </Button>
                </div>
                
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <Input 
                    placeholder="Search groups" 
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <Tabs defaultValue="my-groups" onValueChange={setActiveTab} className="w-full">
                  <TabsList className="w-full mb-4">
                    <TabsTrigger value="my-groups" className="flex-1">My Groups</TabsTrigger>
                    <TabsTrigger value="discover" className="flex-1">Discover</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="my-groups">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : myGroups.length > 0 ? (
                      <div className="space-y-4">
                        {filteredGroups(myGroups).map(group => (
                          <Card key={group.id} className="overflow-hidden">
                            <CardContent className="p-0">
                              <div className="flex items-start p-4">
                                <Avatar className="h-12 w-12 mr-4">
                                  <AvatarImage src={group.avatar} />
                                  <AvatarFallback className="bg-primary/10 text-primary font-bold">
                                    {getInitials(group.name)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex justify-between">
                                    <div>
                                      <h3 className="font-semibold">{group.name}</h3>
                                      <p className="text-sm text-neutral-500">{group.members.toLocaleString()} members</p>
                                    </div>
                                    <Button variant="outline" size="sm" className="gap-1">
                                      <BellOff className="h-4 w-4" />
                                      <span className="hidden sm:inline">Notifications</span>
                                    </Button>
                                  </div>
                                  <p className="mt-2 text-sm text-neutral-600">{group.description}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10 px-6 bg-neutral-50 rounded-lg border border-dashed border-neutral-200">
                        <Users className="h-10 w-10 text-neutral-300 mx-auto mb-3" />
                        <h3 className="text-lg font-semibold mb-2">You haven't joined any groups yet</h3>
                        <p className="text-neutral-600 mb-6">
                          Groups are a great way to connect with people who share your interests
                        </p>
                        <Button 
                          onClick={() => setActiveTab("discover")} 
                          className="bg-primary hover:bg-primary/90"
                        >
                          Discover groups
                        </Button>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="discover">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {filteredGroups(suggestedGroups).map(group => (
                          <Card key={group.id} className="overflow-hidden">
                            <CardContent className="p-0">
                              <div className="flex items-start p-4">
                                <Avatar className="h-12 w-12 mr-4">
                                  <AvatarImage src={group.avatar} />
                                  <AvatarFallback className="bg-primary/10 text-primary font-bold">
                                    {getInitials(group.name)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex justify-between">
                                    <div className="flex items-center gap-2">
                                      <h3 className="font-semibold">{group.name}</h3>
                                      {group.isPrivate && (
                                        <Lock className="h-4 w-4 text-neutral-500" />
                                      )}
                                    </div>
                                    <Button size="sm" className="gap-1">
                                      <UserPlus className="h-4 w-4" />
                                      <span className="hidden sm:inline">Join</span>
                                    </Button>
                                  </div>
                                  <p className="text-sm text-neutral-500">{group.members.toLocaleString()} members</p>
                                  <p className="mt-2 text-sm text-neutral-600">{group.description}</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardHeader>
            </Card>
          </div>
          
          <div className="w-full md:w-1/3">
            <Card className="shadow-sm mb-4">
              <CardHeader>
                <CardTitle className="text-lg">Your invitations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-4">
                  <p className="text-neutral-500">No pending invitations</p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Groups you may like</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {suggestedGroups.slice(0, 2).map(group => (
                  <div key={group.id} className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10 text-primary font-bold">
                        {getInitials(group.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">{group.name}</h4>
                      <p className="text-xs text-neutral-500">{group.members.toLocaleString()} members</p>
                    </div>
                    <Button variant="outline" size="sm" className="flex-shrink-0">
                      Join
                    </Button>
                  </div>
                ))}
                <Button variant="link" className="w-full mt-2">
                  Show more
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}