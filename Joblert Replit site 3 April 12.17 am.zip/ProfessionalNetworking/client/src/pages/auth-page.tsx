import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { registerSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, { message: "Username is required" }),
  password: z.string().min(1, { message: "Password is required" }),
});

type LoginValues = z.infer<typeof loginSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [_, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("login");

  useEffect(() => {
    if (user) {
      setLocation("/feed");
    }
  }, [user, setLocation]);

  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      headline: "",
      email: "",
      terms: false,
    },
  });

  function onLoginSubmit(data: LoginValues) {
    loginMutation.mutate(data);
  }

  function onRegisterSubmit(data: z.infer<typeof registerSchema>) {
    registerMutation.mutate(data);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-primary/10 bg-[url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?q=80&w=2070')] bg-cover bg-center bg-blend-overlay">
      {/* Main content - keep the header visible always */}
      <div className="container mx-auto pt-8 pb-16">
        <div className="text-center mb-8">
          <div>
            <h1 className="text-[#0a66c2] text-4xl font-bold">Xubly</h1>
            <p className="mt-2 text-[#4b5563] text-xl font-light">Make the most of your professional life</p>
          </div>
        </div>

        <div className="flex justify-center">
          <Card className="w-full max-w-md bg-white shadow-lg rounded-lg">
            <CardHeader className="space-y-1 px-8 pt-8">
              <CardTitle className="text-2xl font-bold text-[#000000E6]">
                {activeTab === "login" ? "Sign in" : "Join Xubly"}
              </CardTitle>
              <CardDescription>
                {activeTab === "login" 
                  ? "Stay updated on your professional world" 
                  : "Create your professional profile"}
              </CardDescription>
            </CardHeader>
            <CardContent className="px-8">
              {activeTab === "login" ? (
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input placeholder="Email or Username" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input type="password" placeholder="Password" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full h-12 bg-[#0a66c2] hover:bg-[#084182] text-lg" 
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Sign in
                    </Button>
                  </form>
                </Form>
              ) : (
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input placeholder="Email" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input placeholder="Username" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input type="password" placeholder="Password (6+ characters)" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input placeholder="Full name" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="headline"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input placeholder="Headline" className="h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm text-[#00000099]">
                              I agree to the Xubly User Agreement, Privacy Policy, and Cookie Policy
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full h-12 bg-[#0a66c2] hover:bg-[#084182] text-lg"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Join Xubly
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
            <CardFooter className="px-8 pb-8 flex flex-col items-center">
              <div className="w-full text-center mb-6">
                {activeTab === "login" ? (
                  <p className="text-[#00000099]">
                    New to Xubly?{" "}
                    <button
                      onClick={() => setActiveTab("register")}
                      className="text-[#0a66c2] hover:underline font-semibold"
                    >
                      Join now
                    </button>
                  </p>
                ) : (
                  <p className="text-[#00000099]">
                    Already on Xubly?{" "}
                    <button
                      onClick={() => setActiveTab("login")}
                      className="text-[#0a66c2] hover:underline font-semibold"
                    >
                      Sign in
                    </button>
                  </p>
                )}
              </div>
              
              {/* Back button at bottom center */}
              <button 
                onClick={() => setLocation("/")}
                className="text-[#0a66c2] hover:text-[#084182] transition-colors mt-4 flex items-center"
              >
                ← Back to home
              </button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}