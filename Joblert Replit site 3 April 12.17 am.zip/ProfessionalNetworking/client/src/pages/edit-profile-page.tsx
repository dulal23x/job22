import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/header";
import { Loader2, Upload, Camera, X } from "lucide-react";
import { useLocation } from "wouter";

// Form schema for profile editing
const profileSchema = z.object({
  fullName: z.string().min(1, "Name is required"),
  headline: z.string().optional(),
  about: z.string().optional(),
  website: z.string().url().optional().or(z.literal("")),
  location: z.string().optional(),
  industry: z.string().optional(),
  email: z.string().email("Invalid email address").min(1, "Email is required"),
  phoneNumber: z.string().optional(),
  profileImage: z.string().optional(),
  coverImage: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

export default function EditProfilePage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(user?.profileImage || null);
  const [coverImageFile, setCoverImageFile] = useState<File | null>(null);
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(user?.coverImage || null);
  
  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      headline: user?.headline || "",
      about: user?.about || "",
      website: "",
      location: "",
      industry: "",
      email: user?.email || "",
      phoneNumber: "",
      profileImage: user?.profileImage || "",
      coverImage: user?.coverImage || "",
    },
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const res = await apiRequest("PATCH", "/api/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      navigate("/in/" + user?.username);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileImageFile(file);
      setProfileImagePreview(URL.createObjectURL(file));
    }
  };
  
  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCoverImageFile(file);
      setCoverImagePreview(URL.createObjectURL(file));
    }
  };
  
  const clearProfileImage = () => {
    setProfileImageFile(null);
    setProfileImagePreview(null);
    form.setValue("profileImage", "");
  };
  
  const clearCoverImage = () => {
    setCoverImageFile(null);
    setCoverImagePreview(null);
    form.setValue("coverImage", "");
  };
  
  const onSubmit = async (data: ProfileFormData) => {
    // In a real implementation, you would upload images to a server first
    // and then update the form data with the image URLs
    
    // Simulate image upload
    if (profileImageFile) {
      // This would be replaced with actual image upload
      data.profileImage = profileImagePreview || "";
    }
    
    if (coverImageFile) {
      // This would be replaced with actual image upload
      data.coverImage = coverImagePreview || "";
    }
    
    updateProfileMutation.mutate(data);
  };
  
  const handleCancel = () => {
    navigate("/in/" + user?.username);
  };
  
  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-3xl mx-auto px-4 py-4 md:py-6 mt-16">
        <Card className="shadow-sm mb-6">
          <CardHeader>
            <CardTitle className="text-xl">Edit profile</CardTitle>
            <CardDescription>
              Update your profile information to make your profile more discoverable
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-8">
                  {/* Profile Photo */}
                  <div>
                    <h3 className="text-base font-medium mb-3">Profile photo</h3>
                    <div className="flex items-center gap-6">
                      <div className="relative">
                        <Avatar className="h-24 w-24 border-2 border-neutral-200">
                          <AvatarImage src={profileImagePreview || undefined} />
                          <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                            {user?.fullName ? user.fullName.charAt(0) : "U"}
                          </AvatarFallback>
                        </Avatar>
                        {profileImagePreview && (
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-white shadow-sm border"
                            onClick={clearProfileImage}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                      <div>
                        <Button
                          type="button"
                          variant="outline"
                          className="gap-2"
                        >
                          <label htmlFor="profile-image" className="cursor-pointer flex items-center gap-2">
                            <Camera className="h-4 w-4" />
                            <span>Change photo</span>
                          </label>
                          <Input
                            id="profile-image"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleProfileImageChange}
                          />
                        </Button>
                        <p className="text-sm text-neutral-500 mt-2">
                          JPG, PNG or GIF, max 5MB
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Cover Photo */}
                  <div>
                    <h3 className="text-base font-medium mb-3">Cover photo</h3>
                    <div className="relative h-48 w-full bg-gradient-to-r from-primary/30 to-primary/10 rounded-md overflow-hidden">
                      {coverImagePreview && (
                        <img
                          src={coverImagePreview}
                          alt="Cover"
                          className="w-full h-full object-cover"
                        />
                      )}
                      <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                        <Button
                          type="button"
                          variant="secondary"
                          className="gap-2"
                        >
                          <label htmlFor="cover-image" className="cursor-pointer flex items-center gap-2">
                            <Upload className="h-4 w-4" />
                            <span>Change cover</span>
                          </label>
                          <Input
                            id="cover-image"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleCoverImageChange}
                          />
                        </Button>
                      </div>
                      {coverImagePreview && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white shadow-sm border"
                          onClick={clearCoverImage}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  {/* Basic Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>Full name*</FormLabel>
                          <FormControl>
                            <Input placeholder="Your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="headline"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>Headline</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Software Engineer at Microsoft | Web Developer | React Expert" {...field} />
                          </FormControl>
                          <FormDescription>
                            A brief professional headline that describes your role or expertise
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="industry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Industry</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Information Technology" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: San Francisco, CA" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email address*</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="your.email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone number</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: +1 (555) 123-4567" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>Website</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: https://yourwebsite.com" {...field} />
                          </FormControl>
                          <FormDescription>
                            Add a personal website, portfolio, or blog
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="about"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>About</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Tell people about your work experience, education, accomplishments, interests, or current professional goals"
                              className="min-h-[150px]"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            You can include your background, experience, skills, interests, and goals
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                  
                  <Button
                    type="submit"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}