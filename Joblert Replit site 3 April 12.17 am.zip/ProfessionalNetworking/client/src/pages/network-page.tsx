import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, UserPlus, UsersRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import ConnectionSuggestion from "@/components/network/connection-suggestion";
import ConnectionRequest from "@/components/network/connection-request";
import { useAuth } from "@/hooks/use-auth";
import { User, Connection } from "@shared/schema";

export default function NetworkPage() {
  const { user } = useAuth();
  
  const { data: acceptedConnections, isLoading: isLoadingAccepted } = useQuery({
    queryKey: ["/api/connections/status/accepted"],
    queryFn: async () => {
      const response = await fetch("/api/connections/status/accepted");
      if (!response.ok) throw new Error("Failed to fetch accepted connections");
      return await response.json();
    },
    enabled: !!user,
  });
  
  const { data: pendingConnections, isLoading: isLoadingPending } = useQuery({
    queryKey: ["/api/connections/pending"],
    queryFn: async () => {
      const response = await fetch("/api/connections/pending");
      if (!response.ok) throw new Error("Failed to fetch pending connections");
      return await response.json();
    },
    enabled: !!user,
  });
  
  const { data: suggestedConnections, isLoading: isLoadingSuggested } = useQuery({
    queryKey: ["/api/connections/suggested"],
    queryFn: async () => {
      const response = await fetch("/api/connections/suggested");
      if (!response.ok) throw new Error("Failed to fetch suggested connections");
      return await response.json();
    },
    enabled: !!user,
  });

  // Helper to get user data from a connection
  const getConnectionUser = (connection: Connection, currentUserId: number): User => {
    const otherUserId = connection.requesterId === currentUserId 
      ? connection.requesteeId 
      : connection.requesterId;
    
    // This should be enriched from the API, but for now use a placeholder
    return {
      id: otherUserId,
      username: `user${otherUserId}`,
      password: "",
      email: `user${otherUserId}@xubly.com`,
      fullName: `User ${otherUserId}`,
      headline: "Works at Xubly",
      profileImage: null,
      coverImage: null,
      about: null
    };
  };

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="container mx-auto max-w-7xl px-4 grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-3 hidden lg:block">
            {user && <LeftSidebar user={user} />}
          </div>
          
          <div className="lg:col-span-6 py-5">
            <h1 className="text-2xl font-bold mb-5">My Network</h1>
            
            <Tabs defaultValue="suggestions">
              <TabsList className="w-full mb-5">
                <TabsTrigger value="suggestions" className="flex-1">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Suggestions
                </TabsTrigger>
                <TabsTrigger value="pending" className="flex-1">
                  Pending
                  {!isLoadingPending && pendingConnections && pendingConnections.length > 0 && (
                    <span className="bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ml-2">
                      {pendingConnections.length}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="connections" className="flex-1">
                  <UsersRound className="h-4 w-4 mr-2" />
                  Connections
                  {!isLoadingAccepted && acceptedConnections && (
                    <span className="bg-primary/10 text-primary text-xs rounded-full h-5 w-5 flex items-center justify-center ml-2">
                      {acceptedConnections.length}
                    </span>
                  )}
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="suggestions">
                {isLoadingSuggested ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : suggestedConnections && suggestedConnections.length > 0 ? (
                  <div>
                    {suggestedConnections.map((suggestion: any, index) => (
                      <ConnectionSuggestion
                        key={suggestion.id}
                        user={suggestion}
                        mutualConnections={suggestion.mutualConnections || 0}
                        isLast={index === suggestedConnections.length - 1}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 text-neutral-500">
                    No connection suggestions available at this time.
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="pending">
                {isLoadingPending ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : pendingConnections && pendingConnections.length > 0 ? (
                  <div>
                    {pendingConnections
                      .filter((conn: Connection) => conn.requesteeId === user?.id)
                      .map((connection: Connection, index, filteredConnections) => {
                        const connectionUser = getConnectionUser(connection, user?.id || 0);
                        return (
                          <ConnectionRequest
                            key={connection.id}
                            user={connectionUser}
                            mutualConnections={0} // This should be retrieved from the API
                            isLast={index === filteredConnections.length - 1}
                            connectionId={connection.id}
                          />
                        );
                      })}
                    
                    {pendingConnections
                      .filter((conn: Connection) => conn.requesterId === user?.id)
                      .length > 0 && (
                        <div className="mt-6">
                          <h3 className="text-lg font-semibold mb-3">Sent Requests</h3>
                          {pendingConnections
                            .filter((conn: Connection) => conn.requesterId === user?.id)
                            .map((connection: Connection, index, filteredConnections) => {
                              const connectionUser = getConnectionUser(connection, user?.id || 0);
                              return (
                                <ConnectionRequest
                                  key={connection.id}
                                  user={connectionUser}
                                  mutualConnections={0} // This should be retrieved from the API
                                  isLast={index === filteredConnections.length - 1}
                                  isPending={true}
                                  connectionId={connection.id}
                                />
                              );
                            })}
                        </div>
                      )
                    }
                  </div>
                ) : (
                  <div className="text-center py-10 text-neutral-500">
                    No pending connection requests.
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="connections">
                {isLoadingAccepted ? (
                  <div className="flex justify-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : acceptedConnections && acceptedConnections.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {acceptedConnections.map((connection: Connection) => {
                      const connectionUser = getConnectionUser(connection, user?.id || 0);
                      return (
                        <div key={connection.id} className="flex items-center p-3 border rounded-lg">
                          <Avatar className="h-12 w-12 border mr-3">
                            <AvatarImage src={connectionUser.profileImage || undefined} />
                            <AvatarFallback className="bg-primary/10 text-primary font-bold">
                              {connectionUser.fullName ? connectionUser.fullName.charAt(0) : "U"}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-semibold">{connectionUser.fullName}</div>
                            <div className="text-xs text-neutral-500">{connectionUser.headline || ""}</div>
                            <div className="flex mt-1 gap-2">
                              <Button size="sm" variant="outline" className="h-7 text-xs">Message</Button>
                              <Button size="sm" variant="ghost" className="h-7 text-xs">Remove</Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-10 text-neutral-500">
                    You don't have any connections yet.
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
          
          <div className="lg:col-span-3 hidden lg:block">
            <RightSidebar />
          </div>
        </div>
      </main>
    </>
  );
}