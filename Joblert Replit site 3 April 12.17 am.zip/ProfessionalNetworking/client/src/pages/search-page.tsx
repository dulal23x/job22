import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { User, Job } from "@shared/schema";
import { Search, Users, Briefcase, Building, Filter, Loader2, AlertCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { Alert, AlertDescription } from "@/components/ui/alert";

type SearchResults = {
  users?: User[];
  jobs?: Job[];
  companies?: any[]; // Replace with actual type when implemented
};

export default function SearchPage() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("people");
  const { user, isLoading: authLoading } = useAuth();
  
  // Get search query and tab from URL params
  const params = new URLSearchParams(window.location.search);
  const queryParam = params.get("q") || "";
  const tabParam = params.get("tab") || "people";
  
  // Initialize searchQuery from URL on first load
  useEffect(() => {
    if (queryParam) {
      setSearchQuery(queryParam);
    }
  }, []);
  
  // Set active tab from URL on initial load
  useEffect(() => {
    if (tabParam && tabParam !== activeTab) {
      setActiveTab(tabParam);
    }
  }, [tabParam, activeTab]);
  
  const { data: searchResults, isLoading } = useQuery<SearchResults>({
    queryKey: ["/api/search", queryParam, activeTab],
    queryFn: async () => {
      const searchParams = new URLSearchParams({
        q: queryParam,
        tab: activeTab
      });
      const res = await fetch(`/api/search?${searchParams.toString()}`);
      return res.json();
    },
    enabled: !!queryParam,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Update URL query parameter
      const newParams = new URLSearchParams();
      newParams.set("q", searchQuery);
      newParams.set("tab", activeTab);
      setLocation(`/search?${newParams.toString()}`);
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    if (queryParam) {
      const newParams = new URLSearchParams();
      newParams.set("q", queryParam);
      newParams.set("tab", value);
      setLocation(`/search?${newParams.toString()}`);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Authentication Prompt */}
        {!authLoading && !user && (
          <Alert className="mb-6 border-primary/20 bg-primary/5">
            <AlertCircle className="h-4 w-4 text-primary" />
            <AlertDescription className="flex justify-between items-center">
              <span>Sign in to connect with professionals, apply to jobs, and access more features</span>
              <Button 
                variant="default" 
                size="sm" 
                className="ml-4"
                onClick={() => setLocation('/auth')}
              >
                Sign in / Register
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        {/* Search Form */}
        <Card className="border-none shadow-sm mb-6">
          <CardContent className="pt-6">
            <form onSubmit={handleSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input 
                  placeholder="Search for people, jobs, companies..." 
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button type="submit" className="bg-primary text-white hover:bg-primary-dark">
                Search
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Search Results */}
        {queryParam && (
          <div>
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <div className="flex justify-between items-center mb-4">
                <TabsList>
                  <TabsTrigger value="people" className="flex gap-1">
                    <Users className="h-4 w-4" />
                    People
                  </TabsTrigger>
                  <TabsTrigger value="jobs" className="flex gap-1">
                    <Briefcase className="h-4 w-4" />
                    Jobs
                  </TabsTrigger>
                  <TabsTrigger value="companies" className="flex gap-1">
                    <Building className="h-4 w-4" />
                    Companies
                  </TabsTrigger>
                </TabsList>
                
                <Button variant="outline" size="sm" className="flex gap-1">
                  <Filter className="h-4 w-4" />
                  Filter
                </Button>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <>
                  <TabsContent value="people">
                    {searchResults?.users?.length ? (
                      <div className="space-y-4">
                        {searchResults.users.map(user => (
                          <Card key={user.id} className="border-none shadow-sm hover:shadow cursor-pointer" 
                                onClick={() => user ? setLocation(`/in/${user.username}`) : setLocation('/auth')}>
                            <CardContent className="pt-6">
                              <div className="flex gap-4">
                                <Avatar className="h-16 w-16">
                                  <AvatarImage src={user.profileImage || ""} alt={user.fullName} />
                                  <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <h3 className="text-lg font-semibold">{user.fullName}</h3>
                                      <p className="text-muted-foreground">{user.headline || "No headline"}</p>
                                    </div>
                                    {!authLoading && !user && (
                                      <Button 
                                        variant="outline" 
                                        size="sm" 
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setLocation('/auth');
                                        }}
                                      >
                                        Sign in to connect
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        No people found matching "{queryParam}"
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="jobs">
                    {searchResults?.jobs?.length ? (
                      <div className="space-y-4">
                        {searchResults.jobs.map(job => (
                          <Card key={job.id} className="border-none shadow-sm hover:shadow cursor-pointer"
                                onClick={() => user ? setLocation(`/jobs/view/${job.id}`) : setLocation('/auth')}>
                            <CardContent className="pt-6">
                              <div className="flex justify-between">
                                <div>
                                  <h3 className="text-lg font-semibold">{job.title}</h3>
                                  <p className="text-muted-foreground">{job.company} • {job.location}</p>
                                </div>
                                <div className="flex items-start gap-2">
                                  <Badge variant="outline">{job.type}</Badge>
                                  {job.remote && <Badge className="bg-primary text-white">Remote</Badge>}
                                </div>
                              </div>
                              <div className="flex justify-between items-center mt-2">
                                <p className="text-sm line-clamp-2 flex-1">{job.description}</p>
                                {!authLoading && !user && (
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="ml-4 shrink-0"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setLocation('/auth');
                                    }}
                                  >
                                    Sign in to apply
                                  </Button>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-muted-foreground">
                        No jobs found matching "{queryParam}"
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="companies">
                    <div className="text-center py-12 text-muted-foreground">
                      Company search not implemented yet
                    </div>
                  </TabsContent>
                </>
              )}
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
}

// Helper function to get initials from full name
function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .substring(0, 2);
}