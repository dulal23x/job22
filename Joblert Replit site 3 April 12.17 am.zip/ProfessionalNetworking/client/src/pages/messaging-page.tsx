import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import { User, Message } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useParams, useLocation } from "wouter";

export default function MessagingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const params = useParams<{ userId?: string }>();
  const initialUserId = params.userId ? Number(params.userId) : undefined;
  const [selectedConversation, setSelectedConversation] = useState<{user: User, lastMessage: Message} | null>(null);
  const [messageText, setMessageText] = useState("");
  
  // Used when direct messaging from profile
  const { data: directMessageUser } = useQuery<User>({
    queryKey: ["/api/users/by-id", initialUserId],
    enabled: !!initialUserId && !!user,
    queryFn: async () => {
      if (!initialUserId) return null;
      try {
        const response = await fetch(`/api/users/by-id/${initialUserId}`);
        if (!response.ok) throw new Error("Failed to fetch user");
        return await response.json();
      } catch (error) {
        console.error("Error fetching user:", error);
        toast({
          title: "Error",
          description: "Could not load user information",
          variant: "destructive"
        });
        return null;
      }
    }
  });

  const { data: conversations, isLoading: isLoadingConversations } = useQuery({
    queryKey: ["/api/messages/conversations"],
    queryFn: async () => {
      const response = await fetch("/api/messages/conversations");
      if (!response.ok) throw new Error("Failed to fetch conversations");
      return await response.json();
    },
    enabled: !!user,
  });

  const { data: messages, isLoading: isLoadingMessages } = useQuery({
    queryKey: ["/api/messages", selectedConversation?.user.id],
    queryFn: async () => {
      if (!selectedConversation) return [];
      const response = await fetch(`/api/messages/${selectedConversation.user.id}`);
      if (!response.ok) throw new Error("Failed to fetch messages");
      return await response.json();
    },
    enabled: !!user && !!selectedConversation,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/messages", {
        receiverId: selectedConversation?.user.id,
        content: messageText
      });
      return await res.json();
    },
    onSuccess: () => {
      setMessageText("");
      queryClient.invalidateQueries({ queryKey: ["/api/messages", selectedConversation?.user.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages/conversations"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // When direct messaging from a profile, find that conversation
  useEffect(() => {
    if (directMessageUser && conversations) {
      // Try to find an existing conversation with this user
      const existingConversation = conversations.find(
        (conv: any) => conv.user.id === directMessageUser.id
      );
      
      if (existingConversation) {
        // If there's an existing conversation, select it
        setSelectedConversation(existingConversation);
      } else if (directMessageUser) {
        // If no conversation exists yet, create a placeholder conversation
        setSelectedConversation({
          user: directMessageUser,
          lastMessage: { 
            id: 0, 
            content: "", 
            createdAt: new Date(), 
            read: true,
            senderId: user!.id,
            receiverId: directMessageUser.id 
          }
        });
      }
    }
  }, [directMessageUser, conversations, user]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !selectedConversation) return;
    
    sendMessageMutation.mutate();
  };

  return (
    <>
      <Header />
      <main className="pt-16 min-h-screen bg-neutral-50">
        <div className="container mx-auto max-w-6xl px-4 py-5">
          <div className="flex flex-col md:flex-row gap-5 h-[calc(100vh-120px)]">
            {/* Conversations List */}
            <div className="w-full md:w-1/3 flex flex-col h-full">
              <h2 className="text-xl font-bold mb-3">Messages</h2>
              <Card className="flex-1 overflow-hidden">
                <div className="h-full flex flex-col">
                  <div className="p-3 border-b">
                    <Input placeholder="Search messages..." className="w-full" />
                  </div>
                  
                  <div className="flex-1 overflow-y-auto">
                    {isLoadingConversations ? (
                      <div className="flex justify-center items-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : conversations && conversations.length > 0 ? (
                      conversations.map((conversation: any) => (
                        <div 
                          key={conversation.user.id}
                          className={`flex items-center gap-3 p-3 hover:bg-neutral-100 cursor-pointer ${
                            selectedConversation?.user.id === conversation.user.id ? 'bg-neutral-100' : ''
                          }`}
                          onClick={() => setSelectedConversation(conversation)}
                        >
                          <Avatar className="h-12 w-12 border">
                            <AvatarImage src={conversation.user.profileImage || undefined} />
                            <AvatarFallback className="bg-primary/10 text-primary font-bold">
                              {conversation.user.fullName ? conversation.user.fullName.charAt(0) : "U"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                              <span className="font-semibold truncate">{conversation.user.fullName}</span>
                              <span className="text-xs text-neutral-500">
                                {formatDistanceToNow(new Date(conversation.lastMessage.createdAt), { addSuffix: true })}
                              </span>
                            </div>
                            <div className="text-sm text-neutral-600 truncate">
                              {conversation.lastMessage.content}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="flex flex-col justify-center items-center h-full text-center p-4">
                        <p className="text-neutral-500 mb-3">No messages yet</p>
                        <p className="text-sm text-neutral-400">
                          Start a conversation with your connections
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </div>
            
            {/* Message Thread */}
            <div className="w-full md:w-2/3 flex flex-col h-full">
              {selectedConversation ? (
                <Card className="flex-1 flex flex-col overflow-hidden">
                  <div className="p-3 border-b flex items-center gap-3">
                    <Avatar className="h-10 w-10 border">
                      <AvatarImage src={selectedConversation.user.profileImage || undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary font-bold">
                        {selectedConversation.user.fullName ? selectedConversation.user.fullName.charAt(0) : "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-semibold">{selectedConversation.user.fullName}</div>
                      <div className="text-xs text-neutral-500">{selectedConversation.user.headline || ""}</div>
                    </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-4">
                    {isLoadingMessages ? (
                      <div className="flex justify-center items-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : messages && messages.length > 0 ? (
                      <div className="flex flex-col gap-3">
                        {messages.map((message: Message) => (
                          <div
                            key={message.id}
                            className={`flex ${
                              message.senderId === user?.id ? "justify-end" : "justify-start"
                            }`}
                          >
                            <div
                              className={`max-w-[70%] p-3 rounded-lg ${
                                message.senderId === user?.id
                                  ? "bg-primary text-white"
                                  : "bg-neutral-200"
                              }`}
                            >
                              <div className="text-sm">{message.content}</div>
                              <div className={`text-xs mt-1 ${
                                message.senderId === user?.id
                                  ? "text-primary-foreground/80"
                                  : "text-neutral-500"
                              }`}>
                                {formatDistanceToNow(new Date(message.createdAt), { addSuffix: true })}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex justify-center items-center h-full text-neutral-500">
                        Start a conversation
                      </div>
                    )}
                  </div>
                  
                  <CardContent className="p-3 border-t">
                    <form onSubmit={handleSendMessage} className="flex gap-2">
                      <Textarea
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 min-h-[60px] max-h-[120px] resize-none"
                      />
                      <Button 
                        type="submit" 
                        disabled={!messageText.trim() || sendMessageMutation.isPending}
                        className="h-auto self-end"
                      >
                        {sendMessageMutation.isPending ? (
                          <Loader2 className="h-5 w-5 animate-spin" />
                        ) : (
                          <Send className="h-5 w-5" />
                        )}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              ) : (
                <div className="flex-1 flex flex-col justify-center items-center text-center gap-3 bg-neutral-100 rounded-lg p-8">
                  <div className="text-neutral-400 p-4 rounded-full bg-neutral-200 mb-2">
                    <Send className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-bold">Your Messages</h3>
                  <p className="text-neutral-500 max-w-md">
                    Send private messages to your connections and start conversations
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </>
  );
}