
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { PostWithAuthor } from "@shared/schema";
import { Link } from "wouter";

import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import RightSidebar from "@/components/layout/right-sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import PostCreator from "@/components/feed/post-creator";
import PostCard from "@/components/feed/post-card";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight, Briefcase, Users, BookOpen, LightbulbIcon, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

function AuthenticatedView() {
  const { user } = useAuth();
  const [unreadNotifications] = useState(3);

  // Fetch feed posts
  const { data: posts, isLoading, error } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/feed"],
    enabled: !!user,
  });

  // Fetch news items for right sidebar
  const { data: news } = useQuery({
    queryKey: ["/api/news"],
    enabled: !!user,
    queryFn: async () => {
      try {
        const res = await fetch("/api/news", { credentials: "include" });
        if (!res.ok) return [];
        return await res.json();
      } catch (error) {
        return [];
      }
    },
  });

  // Fetch connection suggestions
  const { data: connectionSuggestions } = useQuery({
    queryKey: ["/api/connections/suggested"],
    enabled: !!user,
    queryFn: async () => {
      try {
        const res = await fetch("/api/connections/suggested", { credentials: "include" });
        if (!res.ok) return [];
        return await res.json().then(users => users.map((user: any) => ({
          user,
          mutualConnections: Math.floor(Math.random() * 10)
        })));
      } catch (error) {
        return [];
      }
    },
  });

  // Fetch job recommendations
  const { data: jobRecommendations } = useQuery({
    queryKey: ["/api/jobs", { recommended: true }],
    enabled: !!user,
    queryFn: async () => {
      try {
        const res = await fetch("/api/jobs?recommended=true", { credentials: "include" });
        if (!res.ok) return [];
        return await res.json();
      } catch (error) {
        return [];
      }
    },
  });

  // Create mutation for sending connection requests
  const connectMutation = useMutation({
    mutationFn: (receiverId: number) => {
      return apiRequest("POST", "/api/connections", { receiverId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggested"] });
    },
  });

  // Handler for liking/reacting to posts
  const handleReaction = async (postId: number, hasReacted: boolean, type = "like") => {
    if (hasReacted) {
      await apiRequest("DELETE", `/api/reactions/${postId}`);
    } else {
      await apiRequest("POST", "/api/reactions", { postId, type });
    }
    queryClient.invalidateQueries({ queryKey: ["/api/feed"] });
  };

  // Sample news data for the right sidebar
  const sampleNewsData = news || [
    {
      id: 1,
      title: "AI tools revolutionizing career advancement strategies",
      timeAgo: "3h ago",
      readers: 7893,
      imageUrl: ""
    },
    {
      id: 2,
      title: "Global skill shortages create unprecedented opportunities",
      timeAgo: "5h ago",
      readers: 5241,
      imageUrl: ""
    },
    {
      id: 3,
      title: "Career pivot success stories: From tech to sustainability",
      timeAgo: "8h ago",
      readers: 3190,
      imageUrl: ""
    }
  ];

  return (
    <>
      <Header unreadNotifications={unreadNotifications} />
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 relative pb-16 md:pb-0 bg-[#F0F4F8] mt-16">
        <div className="flex flex-col md:flex-row gap-5">
          <LeftSidebar user={user} />
          
          <div className="w-full md:max-w-xl flex-1">
            <PostCreator user={user} />
            
            <div className="flex items-center justify-between mb-4 mt-3">
              <hr className="flex-1 border-neutral-300" />
              <div className="flex items-center mx-3">
                <span className="text-neutral-600 text-sm font-medium mr-2">Sort by:</span>
                <Button variant="ghost" className="flex items-center text-sm font-semibold text-primary h-auto py-1 px-2 rounded-full bg-primary/5 hover:bg-primary/10">
                  <span>Trending</span>
                  <TrendingUp className="ml-1 h-3.5 w-3.5" />
                </Button>
              </div>
              <hr className="flex-1 border-neutral-300" />
            </div>
            
            {isLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-10 text-neutral-500">
                Error loading feed. Please try again.
              </div>
            ) : posts && posts.length > 0 ? (
              posts.map((post) => (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  onReaction={(hasReacted) => handleReaction(post.id, hasReacted)}
                />
              ))
            ) : (
              <div className="text-center py-10 text-neutral-600 bg-white rounded-lg shadow-sm p-6">
                <LightbulbIcon className="h-12 w-12 text-primary/60 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Your feed is waiting for you</h3>
                <p className="text-neutral-500 mb-4">
                  Connect with professionals in your industry to see their posts, insights, and updates here.
                </p>
                <Button className="bg-primary hover:bg-primary/90">
                  Find connections
                </Button>
              </div>
            )}
          </div>
          
          <RightSidebar 
            newsList={sampleNewsData}
            connectionSuggestions={connectionSuggestions || []}
            jobRecommendations={jobRecommendations || []}
            onConnect={(userId) => connectMutation.mutate(userId)}
            onIgnoreConnection={(userId) => {
              queryClient.setQueryData(["/api/connections/suggested"], 
                connectionSuggestions?.filter(s => s.user.id !== userId)
              );
            }}
          />
        </div>
      </main>
      
      <MobileNav unreadNotifications={unreadNotifications} />
    </>
  );
}

function PublicView() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-neutral-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-8">
              <Link href="/">
                <h1 className="text-primary font-bold text-2xl">Xubly</h1>
              </Link>
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/jobs" className="text-neutral-600 hover:text-primary font-medium">
                  Find Jobs
                </Link>
                <Link href="/post-job" className="text-neutral-600 hover:text-primary font-medium">
                  Post Jobs
                </Link>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/auth">
                <Button variant="outline" className="font-medium">
                  Sign in
                </Button>
              </Link>
              <Link href="/auth">
                <Button className="bg-primary hover:bg-primary/90 font-medium">
                  Join now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-b from-[#F0F4F8] to-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="md:w-1/2 md:pr-10">
              <h1 className="text-4xl md:text-5xl font-bold text-neutral-900 leading-tight">
                Unlock Your Professional Potential with Xubly
              </h1>
              <p className="mt-6 text-xl text-neutral-600 leading-relaxed">
                Build your network, discover opportunities, and advance your career with the professional community that puts your growth first.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link href="/auth">
                  <Button size="lg" className="bg-primary hover:bg-primary/90 w-full sm:w-auto text-lg font-medium">
                    Join the community
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg font-medium">
                  Learn more
                </Button>
              </div>
            </div>
            <div className="mt-10 md:mt-0 md:w-1/2">
              <div className="relative">
                <div className="bg-white shadow-xl rounded-xl p-6 md:p-8">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src="" alt="Profile" />
                      <AvatarFallback className="bg-primary/10 text-primary font-medium">JD</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold">Jane Doe</h3>
                      <p className="text-sm text-neutral-500">Product Designer at Design Co.</p>
                      <p className="mt-4 text-neutral-700">Just finished a product design sprint with an amazing team! Excited to share our case study next week. #ProductDesign #UX</p>
                      <div className="mt-4 flex items-center gap-3">
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">32 reactions</span>
                        <span className="text-xs bg-neutral-100 text-neutral-700 px-2 py-1 rounded-full font-medium">12 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute -right-4 -bottom-4 bg-primary/5 w-40 h-40 rounded-full -z-10"></div>
                <div className="absolute -left-4 -top-4 bg-primary/5 w-20 h-20 rounded-full -z-10"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Why professionals choose Xubly</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="shadow-sm hover:shadow-md transition-shadow border-t-4 border-t-primary">
              <CardContent className="pt-6 px-6 pb-8">
                <Briefcase className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Career Opportunities</h3>
                <p className="text-neutral-600">
                  Discover job opportunities tailored to your skills and experience, with insights from your professional network.
                </p>
                <Button variant="link" className="p-0 mt-4 text-primary font-medium">
                  Explore jobs <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
            <Card className="shadow-sm hover:shadow-md transition-shadow border-t-4 border-t-primary">
              <CardContent className="pt-6 px-6 pb-8">
                <Users className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Meaningful Connections</h3>
                <p className="text-neutral-600">
                  Build genuine professional relationships with peers, mentors, and industry leaders who share your interests.
                </p>
                <Button variant="link" className="p-0 mt-4 text-primary font-medium">
                  Grow your network <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
            <Card className="shadow-sm hover:shadow-md transition-shadow border-t-4 border-t-primary">
              <CardContent className="pt-6 px-6 pb-8">
                <BookOpen className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Knowledge Sharing</h3>
                <p className="text-neutral-600">
                  Access industry insights, learn from thought leaders, and share your expertise with professionals worldwide.
                </p>
                <Button variant="link" className="p-0 mt-4 text-primary font-medium">
                  Discover insights <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to advance your career?</h2>
          <p className="text-xl text-neutral-600 max-w-3xl mx-auto mb-8">
            Join millions of professionals building connections, sharing insights, and growing their careers on Xubly.
          </p>
          <Link href="/auth">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg font-medium">
              Join Xubly today
            </Button>
          </Link>
        </div>
      </section>

      <footer className="bg-neutral-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">Xubly</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-neutral-400 hover:text-white">About</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Careers</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Press</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Blog</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Products</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-neutral-400 hover:text-white">Networking</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Jobs</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Learning</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Premium</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-neutral-400 hover:text-white">Help Center</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Guidelines</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Testimonials</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Developers</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-neutral-400 hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Cookie Policy</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white">Copyright</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-neutral-800 text-center text-neutral-400 text-sm">
            <p>© {new Date().getFullYear()} Xubly Corporation. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  return user ? <AuthenticatedView /> : <PublicView />;
}
