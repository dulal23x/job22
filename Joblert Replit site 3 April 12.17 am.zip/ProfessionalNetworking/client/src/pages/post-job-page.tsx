import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertJobSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

import Header from "@/components/layout/header";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowRight, AlertCircle, Loader2, Check } from "lucide-react";

// Extended schema with validation rules
const postJobSchema = insertJobSchema.extend({
  title: z.string().min(5, { message: "Job title must be at least 5 characters" }),
  company: z.string().min(2, { message: "Company name is required" }),
  location: z.string().min(2, { message: "Location is required" }),
  description: z.string().min(50, { message: "Job description must be at least 50 characters" }),
  type: z.string().min(2, { message: "Job type is required" }),
  salary: z.string().optional(),
  remote: z.boolean().optional(),
});

type PostJobFormValues = z.infer<typeof postJobSchema>;

export default function PostJobPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [submissionState, setSubmissionState] = useState<"idle" | "success" | "error">("idle");
  
  // Initialize form
  const form = useForm<PostJobFormValues>({
    resolver: zodResolver(postJobSchema),
    defaultValues: {
      title: "",
      company: "",
      location: "",
      description: "",
      type: "Full-time",
      salary: "",
      remote: false,
      userId: user?.id || 0,
    },
  });
  
  // Create job mutation
  const mutation = useMutation({
    mutationFn: async (data: PostJobFormValues) => {
      if (!user) {
        // Save form data in session storage for after login
        sessionStorage.setItem("pendingJobPost", JSON.stringify(data));
        navigate("/auth?returnTo=/post-job");
        return;
      }
      
      // Include user ID from auth context
      const jobData = {
        ...data,
        userId: user.id,
      };
      
      const res = await apiRequest("POST", "/api/jobs", jobData);
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to post job");
      }
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setSubmissionState("success");
      form.reset();
      toast({
        title: "Job posted successfully",
        description: "Your job listing has been published.",
      });
    },
    onError: (error: Error) => {
      setSubmissionState("error");
      toast({
        title: "Failed to post job",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: PostJobFormValues) => {
    setSubmissionState("idle");
    mutation.mutate(data);
  };
  
  return (
    <>
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Post a Job</h1>
          
          {!user && (
            <Alert className="mb-6 bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Authentication required</AlertTitle>
              <AlertDescription>
                You'll need to sign in or create an account to post a job. Your job details will be saved.
              </AlertDescription>
            </Alert>
          )}
          
          {submissionState === "success" && (
            <Alert className="mb-6 bg-green-50 border-green-200">
              <Check className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Job Posted Successfully</AlertTitle>
              <AlertDescription className="text-green-700">
                Your job has been published and is now visible to potential candidates.
                <div className="mt-3">
                  <Button 
                    variant="outline" 
                    className="mr-3"
                    onClick={() => form.reset()}
                  >
                    Post Another Job
                  </Button>
                  <Button 
                    onClick={() => navigate("/jobs")}
                  >
                    View All Jobs
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}
          
          <Card>
            <CardHeader>
              <CardTitle>Job Details</CardTitle>
              <CardDescription>
                Provide comprehensive information to attract the right candidates.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Job Title</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Senior Software Engineer" {...field} />
                          </FormControl>
                          <FormDescription>
                            Clear title improves visibility in search results.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Acme Inc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. New York, NY or Remote" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Job Type</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Full-time, Part-time, Contract" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="salary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Salary Range (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. $80,000 - $120,000" {...field} />
                          </FormControl>
                          <FormDescription>
                            Jobs with salary information get more applicants.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="remote"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 mt-8">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Remote Position</FormLabel>
                            <FormDescription>
                              This job can be performed fully remotely.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Job Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe the role, responsibilities, requirements, benefits, and application process..." 
                            className="min-h-[200px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          Provide comprehensive details about the position, requirements, and benefits.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end space-x-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => form.reset()}
                      disabled={mutation.isPending}
                    >
                      Reset
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={mutation.isPending}
                      className="min-w-[120px]"
                    >
                      {mutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Posting...
                        </>
                      ) : (
                        <>
                          Post Job
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          <div className="mt-10 space-y-4 bg-neutral-50 p-6 rounded-lg border border-neutral-200">
            <h2 className="text-xl font-semibold">Why Post a Job on Xubly?</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                <span>Reach thousands of qualified professionals in your industry</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                <span>Intelligent matching algorithm connects you with the right candidates</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                <span>Simple, streamlined application process reduces drop-offs</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                <span>Built-in tools to screen, sort, and manage applications</span>
              </li>
            </ul>
          </div>
        </div>
      </main>
    </>
  );
}