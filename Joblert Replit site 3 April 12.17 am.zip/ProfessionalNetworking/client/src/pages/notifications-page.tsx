import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { NotificationWithInitiator } from "@shared/schema";

import Header from "@/components/layout/header";
import LeftSidebar from "@/components/layout/left-sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import NotificationCard from "@/components/notifications/notification-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

export default function NotificationsPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("all");

  // Fetch user's notifications
  const {
    data: notifications,
    isLoading,
    error,
  } = useQuery<NotificationWithInitiator[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      return apiRequest("PUT", `/api/notifications/${notificationId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  // Filter notifications based on active tab
  const getFilteredNotifications = () => {
    if (!notifications) return [];
    
    switch (activeTab) {
      case "unread":
        return notifications.filter(notification => !notification.isRead);
      case "connections":
        return notifications.filter(
          notification => notification.type === "connection_request" || notification.type === "connection_accepted"
        );
      case "jobs":
        return notifications.filter(
          notification => notification.type === "job_application" || notification.type === "job_recommendation"
        );
      case "all":
      default:
        return notifications;
    }
  };

  // Calculate unread notifications count
  const unreadCount = notifications?.filter(notification => !notification.isRead).length || 0;
  
  // If user info is not available yet, return null
  if (!user) return null;

  return (
    <>
      <Header unreadNotifications={unreadCount} />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 relative pb-16 md:pb-0">
        <div className="flex flex-col md:flex-row gap-5">
          {/* Left Sidebar (desktop only) */}
          <LeftSidebar user={user} />
          
          {/* Main content */}
          <div className="w-full md:max-w-2xl flex-1">
            <h1 className="text-2xl font-bold mb-4">Notifications</h1>
            
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="unread">
                  Unread
                  {unreadCount > 0 && (
                    <span className="ml-1 inline-flex items-center justify-center w-5 h-5 text-xs font-medium rounded-full bg-primary text-white">
                      {unreadCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="connections">My Network</TabsTrigger>
                <TabsTrigger value="jobs">Jobs</TabsTrigger>
              </TabsList>
              
              <Card>
                <CardHeader>
                  <CardTitle>
                    {activeTab === "all" ? "All Notifications" :
                     activeTab === "unread" ? "Unread Notifications" :
                     activeTab === "connections" ? "Network Notifications" :
                     "Job Notifications"}
                  </CardTitle>
                </CardHeader>
                <Separator />
                <CardContent className="p-0">
                  {isLoading ? (
                    <div className="flex justify-center py-10">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : error ? (
                    <div className="p-6 text-center text-neutral-500">
                      Error loading notifications.
                    </div>
                  ) : getFilteredNotifications().length > 0 ? (
                    getFilteredNotifications().map((notification) => (
                      <NotificationCard
                        key={notification.id}
                        notification={notification}
                        onMarkAsRead={() => markAsReadMutation.mutate(notification.id)}
                      />
                    ))
                  ) : (
                    <div className="p-6 text-center text-neutral-500">
                      No notifications in this category.
                    </div>
                  )}
                </CardContent>
              </Card>
            </Tabs>
          </div>
        </div>
      </main>
      
      {/* Mobile Navigation */}
      <MobileNav unreadNotifications={unreadCount} />
    </>
  );
}
