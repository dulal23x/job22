import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Loader2, Edit, MapPin, Briefcase, Building, UserPlus, ChevronDown, MessageSquare, UserCheck, UserX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Connection button component based on connection status
interface ConnectionButtonProps {
  profileUser: User;
  connectionStatus: { id?: number; status?: string; isRequester?: boolean } | null;
}

function ConnectionButton({ profileUser, connectionStatus }: ConnectionButtonProps) {
  const { toast } = useToast();

  // Send connection request
  const sendConnectionMutation = useMutation({
    mutationFn: async () => {
      if (!profileUser?.id) {
        throw new Error("Invalid user ID");
      }
      console.log("Sending connection request to user ID:", profileUser.id);
      const res = await apiRequest("POST", "/api/connections", { userId: profileUser.id });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to send connection request");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Connection request sent",
        description: `Your connection request has been sent to ${profileUser.fullName}`,
      });

      // Optimistically update the connection status without waiting for a refetch
      queryClient.setQueryData(["/api/connections/status", profileUser.id], {
        id: data.id,
        status: "pending",
        isRequester: true
      });

      // Also invalidate queries to ensure data consistency
      queryClient.invalidateQueries({ queryKey: ["/api/connections/status", profileUser.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/requests"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send connection request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Accept connection request
  const respondToConnectionMutation = useMutation({
    mutationFn: async ({ id, action }: { id: number; action: "accept" | "reject" }) => {
      if (!id) {
        throw new Error("Invalid connection ID");
      }
      console.log("Responding to connection request:", id, action);
      const res = await apiRequest("PUT", `/api/connections/${id}`, { action });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to update connection");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Connection request updated",
        description: `You've updated the connection request with ${profileUser.fullName}`,
      });
      // Invalidate queries to update UI
      queryClient.invalidateQueries({ queryKey: ["/api/connections/status", profileUser.id] });
      // Also invalidate the connections list in network page
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/requests"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update connection",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (!connectionStatus) {
    return (
      <Button 
        className="bg-primary text-white hover:bg-primary-dark gap-1"
        onClick={() => sendConnectionMutation.mutate()}
        disabled={sendConnectionMutation.isPending}
      >
        {sendConnectionMutation.isPending 
          ? <Loader2 className="h-4 w-4 animate-spin" /> 
          : <UserPlus className="h-4 w-4" />
        }
        Connect
      </Button>
    );
  }

  // Connection exists
  switch (connectionStatus.status) {
    case "pending":
      // If we sent the request
      if (connectionStatus.isRequester) {
        return (
          <Button variant="outline" disabled className="gap-1">
            <UserCheck className="h-4 w-4" />
            Pending
          </Button>
        );
      }
      // If we received the request
      return (
        <div className="flex gap-2">
          <Button 
            className="bg-primary text-white hover:bg-primary-dark gap-1"
            onClick={() => respondToConnectionMutation.mutate({ id: connectionStatus.id!, action: "accept" })}
            disabled={respondToConnectionMutation.isPending}
          >
            <UserCheck className="h-4 w-4" />
            Accept
          </Button>
          <Button 
            variant="outline"
            onClick={() => respondToConnectionMutation.mutate({ id: connectionStatus.id!, action: "reject" })}
            disabled={respondToConnectionMutation.isPending}
          >
            <UserX className="h-4 w-4" />
            Ignore
          </Button>
        </div>
      );
    case "accepted":
      return (
        <Button variant="outline" className="gap-1">
          <UserCheck className="h-4 w-4" />
          Connected
        </Button>
      );
    case "rejected":
      return (
        <Button 
          className="bg-primary text-white hover:bg-primary-dark gap-1"
          onClick={() => sendConnectionMutation.mutate()}
          disabled={sendConnectionMutation.isPending}
        >
          <UserPlus className="h-4 w-4" />
          Connect
        </Button>
      );
    default:
      return (
        <Button 
          className="bg-primary text-white hover:bg-primary-dark gap-1"
          onClick={() => sendConnectionMutation.mutate()}
          disabled={sendConnectionMutation.isPending}
        >
          <UserPlus className="h-4 w-4" />
          Connect
        </Button>
      );
  }
}

export default function ProfilePage() {
  const { username } = useParams<{ username?: string }>();
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // If no username is provided, use the current user's username
  const profileUsername = username || currentUser?.username;

  const { data: profileUser, isLoading } = useQuery<User>({
    queryKey: ["/api/users", profileUsername],
    enabled: !!profileUsername,
    queryFn: async () => {
      if (!profileUsername) throw new Error("No username provided");
      const response = await fetch(`/api/users/${profileUsername}`);
      if (!response.ok) throw new Error("Failed to fetch user data");
      return await response.json();
    }
  });

  // Get connection status
  const { data: connectionStatus, isLoading: isLoadingConnection } = useQuery({
    queryKey: ["/api/connections/status", profileUser?.id],
    enabled: !!profileUser && !!currentUser && currentUser.id !== profileUser.id,
    queryFn: async () => {
      try {
        // Make sure we have a valid ID
        if (!profileUser?.id || isNaN(profileUser.id)) {
          console.error("Invalid profile user ID:", profileUser?.id);
          return null;
        }
        const response = await fetch(`/api/connections/status/${profileUser.id}`);
        if (!response.ok) {
          const errorData = await response.json();
          console.error("Connection status error:", errorData);
          return null;
        }
        return await response.json();
      } catch (error) {
        console.error("Error fetching connection status:", error);
        return null;
      }
    }
  });

  const isCurrentUser = !username || currentUser?.username === username;

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">User not found</h1>
        <p>The profile you're looking for doesn't exist or has been removed.</p>
      </div>
    );
  }

  function getInitials(name: string | undefined): string {
    if (!name) return "UN";
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card className="border-none shadow-sm mb-6 overflow-hidden">
          <div className="h-40 bg-gradient-to-r from-primary/30 to-primary/10 w-full">
            {profileUser.coverImage && (
              <img 
                src={profileUser.coverImage} 
                alt="Cover" 
                className="w-full h-full object-cover"
              />
            )}
          </div>

          <CardContent className="pt-0">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="-mt-12 z-10">
                <Avatar className="h-32 w-32 border-4 border-white">
                  <AvatarImage src={profileUser.profileImage || ""} alt={profileUser.fullName} />
                  <AvatarFallback className="text-3xl">{getInitials(profileUser.fullName)}</AvatarFallback>
                </Avatar>
              </div>

              <div className="flex flex-col md:flex-row justify-between w-full pt-4">
                <div>
                  <h1 className="text-2xl font-bold">{profileUser.fullName}</h1>
                  <p className="text-muted-foreground">{profileUser.headline || "No headline"}</p>

                  <div className="flex flex-wrap gap-x-4 mt-2 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      Location
                    </span>
                    <span className="flex items-center gap-1">
                      <Building className="h-4 w-4" />
                      Company
                    </span>
                    <span className="flex items-center gap-1">
                      <Briefcase className="h-4 w-4" />
                      Industry
                    </span>
                  </div>
                </div>

                <div className="mt-4 md:mt-0 flex space-x-2">
                  {isCurrentUser ? (
                    <Button 
                      variant="outline" 
                      className="gap-1"
                      onClick={() => navigate("/edit-profile")}
                    >
                      <Edit className="h-4 w-4" />
                      Edit Profile
                    </Button>
                  ) : (
                    <>
                      <ConnectionButton profileUser={profileUser} connectionStatus={connectionStatus} />
                      <Button 
                        variant="outline"
                        onClick={() => navigate(`/messaging/${profileUser.id}`)}
                        disabled={!connectionStatus || connectionStatus.status !== "accepted"}
                        className="gap-1"
                      >
                        <MessageSquare className="h-4 w-4" />
                        Message
                      </Button>
                    </>
                  )}
                  <Button variant="outline">
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm mb-6">
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-3">About</h2>
            <p className="whitespace-pre-line">
              {profileUser.about || "This user hasn't added any information about themselves yet."}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}