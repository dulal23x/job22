import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Header from "@/components/layout/header";
import { Loader2, Search, CalendarPlus, Calendar, Plus, MapPin, ExternalLink } from "lucide-react";
import { format } from "date-fns";

interface Event {
  id: number;
  title: string;
  organizerName: string;
  organizerAvatar?: string;
  date: Date;
  location: string;
  isOnline: boolean;
  attendees: number;
  description: string;
  imageUrl?: string;
  isAttending?: boolean;
}

export default function EventsPage() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock events data
  const yourEvents: Event[] = [];
  
  const suggestedEvents: Event[] = [
    {
      id: 1,
      title: "Annual Tech Conference 2025",
      organizerName: "Tech Industry Association",
      date: new Date("2025-06-15T10:00:00"),
      location: "San Francisco, CA",
      isOnline: false,
      attendees: 2845,
      description: "Join us for the biggest tech event of the year, featuring keynote speakers, workshops, and networking opportunities."
    },
    {
      id: 2,
      title: "Digital Marketing Workshop",
      organizerName: "Marketing Professionals Network",
      date: new Date("2025-05-22T14:00:00"),
      location: "Zoom Webinar",
      isOnline: true,
      attendees: 713,
      description: "Learn the latest digital marketing strategies and tools from industry experts."
    },
    {
      id: 3,
      title: "Product Management Summit",
      organizerName: "Product Managers Association",
      date: new Date("2025-07-10T09:00:00"),
      location: "New York City, NY",
      isOnline: false,
      attendees: 1250,
      description: "A summit dedicated to product management best practices, featuring case studies and panel discussions."
    }
  ];
  
  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const filteredEvents = (events: Event[]) => {
    if (!searchQuery) return events;
    return events.filter(event => 
      event.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.organizerName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-7xl mx-auto px-4 py-4 md:py-6 mt-16">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-2/3">
            <Card className="shadow-sm mb-4">
              <CardHeader className="pb-0">
                <div className="flex justify-between items-center mb-4">
                  <h1 className="text-2xl font-bold">Events</h1>
                  <Button size="sm" className="gap-1">
                    <Plus className="h-4 w-4" /> Create Event
                  </Button>
                </div>
                
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <Input 
                    placeholder="Search events" 
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <Tabs defaultValue="your-events" className="w-full">
                  <TabsList className="w-full mb-4">
                    <TabsTrigger value="your-events" className="flex-1">Your Events</TabsTrigger>
                    <TabsTrigger value="discover" className="flex-1">Discover</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="your-events">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : yourEvents.length > 0 ? (
                      <div className="grid grid-cols-1 gap-4">
                        {filteredEvents(yourEvents).map(event => (
                          <EventCard key={event.id} event={event} isAttending />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10 px-6 bg-neutral-50 rounded-lg border border-dashed border-neutral-200">
                        <Calendar className="h-10 w-10 text-neutral-300 mx-auto mb-3" />
                        <h3 className="text-lg font-semibold mb-2">You have no upcoming events</h3>
                        <p className="text-neutral-600 mb-6">
                          Browse events that match your interests and add them to your calendar
                        </p>
                        <Button className="bg-primary hover:bg-primary/90">
                          Find events
                        </Button>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="discover">
                    {isLoading ? (
                      <div className="flex justify-center py-10">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-4">
                        {filteredEvents(suggestedEvents).map(event => (
                          <EventCard key={event.id} event={event} />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardHeader>
            </Card>
          </div>
          
          <div className="w-full md:w-1/3">
            <Card className="shadow-sm mb-4">
              <CardHeader>
                <CardTitle className="text-lg">Upcoming Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {suggestedEvents.slice(0, 2).map(event => (
                    <div key={event.id} className="flex items-start gap-3">
                      <div className="bg-neutral-100 rounded-md p-2 flex-shrink-0 flex flex-col items-center justify-center w-12">
                        <span className="text-xs font-medium text-neutral-500">
                          {format(event.date, 'MMM')}
                        </span>
                        <span className="text-lg font-bold">
                          {format(event.date, 'd')}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm">{event.title}</h4>
                        <div className="flex items-center text-xs text-neutral-500 mt-1">
                          <CalendarPlus className="h-3 w-3 mr-1" />
                          <span>{format(event.date, 'E, MMM d • h:mm a')}</span>
                        </div>
                        <div className="flex items-center text-xs text-neutral-500 mt-1">
                          <MapPin className="h-3 w-3 mr-1" />
                          <span>{event.location}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="link" className="w-full mt-4 pl-0">
                  View all events
                </Button>
              </CardContent>
            </Card>
            
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Online Events For You</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {suggestedEvents
                    .filter(event => event.isOnline)
                    .map(event => (
                      <div key={event.id} className="flex items-start gap-3">
                        <div className="bg-neutral-100 rounded-md p-2 flex-shrink-0 flex flex-col items-center justify-center w-12">
                          <span className="text-xs font-medium text-neutral-500">
                            {format(event.date, 'MMM')}
                          </span>
                          <span className="text-lg font-bold">
                            {format(event.date, 'd')}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm">{event.title}</h4>
                          <div className="flex items-center text-xs text-neutral-500 mt-1">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            <span>Online Event</span>
                          </div>
                          <div className="flex items-center text-xs text-neutral-500 mt-1">
                            <CalendarPlus className="h-3 w-3 mr-1" />
                            <span>{format(event.date, 'E, MMM d • h:mm a')}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
                <Button variant="link" className="w-full mt-4 pl-0">
                  Browse more online events
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

interface EventCardProps {
  event: Event;
  isAttending?: boolean;
}

function EventCard({ event, isAttending }: EventCardProps) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="flex flex-col md:flex-row">
          {event.imageUrl ? (
            <div className="w-full md:w-48 h-32 md:h-auto">
              <img 
                src={event.imageUrl} 
                alt={event.title} 
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <div className="w-full md:w-48 h-32 md:h-auto bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center">
              <Calendar className="h-10 w-10 text-primary/70" />
            </div>
          )}
          
          <div className="p-4 flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{event.title}</h3>
                <p className="text-sm text-neutral-500">Organized by {event.organizerName}</p>
              </div>
              <Button 
                variant={isAttending ? "outline" : "default"}
                size="sm"
              >
                {isAttending ? "Attending" : "Attend"}
              </Button>
            </div>
            
            <div className="mt-3 space-y-1">
              <div className="flex items-center text-sm text-neutral-600">
                <CalendarPlus className="h-4 w-4 mr-2 text-neutral-500" />
                <span>{format(event.date, 'EEEE, MMMM d, yyyy • h:mm a')}</span>
              </div>
              <div className="flex items-center text-sm text-neutral-600">
                <MapPin className="h-4 w-4 mr-2 text-neutral-500" />
                <span>{event.location}</span>
              </div>
            </div>
            
            <p className="mt-3 text-sm text-neutral-600 line-clamp-2">
              {event.description}
            </p>
            
            <div className="mt-3 text-sm text-neutral-500">
              {event.attendees.toLocaleString()} attendees
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}