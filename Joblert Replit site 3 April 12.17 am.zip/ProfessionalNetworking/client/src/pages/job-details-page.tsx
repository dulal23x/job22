import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Job } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function JobDetailsPage() {
  const { id } = useParams<{ id: string }>();
  
  const { data: job, isLoading } = useQuery<Job>({
    queryKey: ["/api/jobs", id],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Job not found</h1>
        <p>The job you're looking for doesn't exist or has been removed.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card className="border-none shadow-sm mb-6">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl font-bold">{job.title}</CardTitle>
                <CardDescription className="text-lg">{job.company} • {job.location}</CardDescription>
              </div>
              <div className="flex flex-col items-end">
                <Badge variant="outline" className="mb-2">{job.type}</Badge>
                {job.remote && <Badge className="bg-primary text-white">Remote</Badge>}
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="mb-6">
              {job.salary && (
                <div className="mb-4">
                  <h3 className="text-lg font-semibold mb-1">Salary</h3>
                  <p>{job.salary}</p>
                </div>
              )}
              
              <div>
                <h3 className="text-lg font-semibold mb-1">Description</h3>
                <div className="whitespace-pre-line">
                  {job.description}
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button variant="outline">Share</Button>
            <Button className="bg-primary text-white hover:bg-primary-dark">Apply Now</Button>
          </CardFooter>
        </Card>
        
        <div className="text-center mt-8">
          <h3 className="text-lg font-semibold mb-2">Job posted on {new Date(job.createdAt).toLocaleDateString()}</h3>
          <p className="text-muted-foreground">Job ID: {job.id}</p>
        </div>
      </div>
    </div>
  );
}