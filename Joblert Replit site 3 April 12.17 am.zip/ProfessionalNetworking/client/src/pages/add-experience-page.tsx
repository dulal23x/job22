import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/header";
import { Loader2, Calendar, Building, Briefcase, GraduationCap, X, Upload, Search } from "lucide-react";
import { useLocation } from "wouter";

// Form schemas
const workExperienceSchema = z.object({
  title: z.string().min(1, "Title is required"),
  company: z.string().min(1, "Company is required"),
  location: z.string().optional(),
  isCurrentPosition: z.boolean().default(false),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  description: z.string().optional(),
  skills: z.string().optional(),
  industryName: z.string().optional(),
  employmentType: z.string().optional(),
  headline: z.string().optional(),
});

const educationSchema = z.object({
  school: z.string().min(1, "School name is required"),
  degree: z.string().optional(),
  fieldOfStudy: z.string().optional(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  grade: z.string().optional(),
  activities: z.string().optional(),
  description: z.string().optional(),
});

type WorkExperience = z.infer<typeof workExperienceSchema>;
type Education = z.infer<typeof educationSchema>;

export default function AddExperiencePage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("work");
  const { toast } = useToast();
  
  // Work Experience Form
  const workForm = useForm<WorkExperience>({
    resolver: zodResolver(workExperienceSchema),
    defaultValues: {
      title: "",
      company: "",
      location: "",
      isCurrentPosition: false,
      startDate: "",
      endDate: "",
      description: "",
      skills: "",
      industryName: "",
      employmentType: "Full-time",
      headline: "",
    },
  });
  
  // Education Form
  const educationForm = useForm<Education>({
    resolver: zodResolver(educationSchema),
    defaultValues: {
      school: "",
      degree: "",
      fieldOfStudy: "",
      startDate: "",
      endDate: "",
      grade: "",
      activities: "",
      description: "",
    },
  });
  
  // Add work experience mutation
  const addWorkExperienceMutation = useMutation({
    mutationFn: async (data: WorkExperience) => {
      const res = await apiRequest("POST", "/api/profile/experience", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Work experience added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      navigate("/in/" + user?.username);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add work experience: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Add education mutation
  const addEducationMutation = useMutation({
    mutationFn: async (data: Education) => {
      const res = await apiRequest("POST", "/api/profile/education", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Education added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      navigate("/in/" + user?.username);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add education: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const onWorkSubmit = (data: WorkExperience) => {
    if (data.isCurrentPosition) {
      data.endDate = undefined;
    }
    addWorkExperienceMutation.mutate(data);
  };
  
  const onEducationSubmit = (data: Education) => {
    addEducationMutation.mutate(data);
  };
  
  const handleCancel = () => {
    navigate("/in/" + user?.username);
  };

  return (
    <div className="min-h-screen bg-[#F0F4F8]">
      <Header unreadNotifications={0} />
      
      <main className="max-w-3xl mx-auto px-4 py-4 md:py-6 mt-16">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl">Add profile section</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full mb-4">
                <TabsTrigger value="work" className="flex-1 gap-2">
                  <Briefcase className="h-4 w-4" />
                  <span>Work Experience</span>
                </TabsTrigger>
                <TabsTrigger value="education" className="flex-1 gap-2">
                  <GraduationCap className="h-4 w-4" />
                  <span>Education</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="work">
                <Form {...workForm}>
                  <form onSubmit={workForm.handleSubmit(onWorkSubmit)} className="space-y-6">
                    <div className="space-y-4">
                      <FormField
                        control={workForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title*</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: Software Engineer" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="employmentType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Employment type</FormLabel>
                            <FormControl>
                              <select
                                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                {...field}
                              >
                                <option value="Full-time">Full-time</option>
                                <option value="Part-time">Part-time</option>
                                <option value="Self-employed">Self-employed</option>
                                <option value="Freelance">Freelance</option>
                                <option value="Contract">Contract</option>
                                <option value="Internship">Internship</option>
                                <option value="Apprenticeship">Apprenticeship</option>
                              </select>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Company name*</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input placeholder="Ex: Microsoft" {...field} />
                                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: San Francisco, CA" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="isCurrentPosition"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base">I am currently working in this role</FormLabel>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={workForm.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Start date*</FormLabel>
                              <FormControl>
                                <Input type="month" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {!workForm.watch("isCurrentPosition") && (
                          <FormField
                            control={workForm.control}
                            name="endDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>End date</FormLabel>
                                <FormControl>
                                  <Input type="month" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                      </div>
                      
                      <FormField
                        control={workForm.control}
                        name="industryName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Industry</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: Information Technology" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Describe your role, accomplishments, and responsibilities"
                                className="min-h-[120px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={workForm.control}
                        name="skills"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Skills</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: JavaScript, React, Node.js (comma separated)" {...field} />
                            </FormControl>
                            <FormDescription>
                              Add skills that you used in this role. Separate multiple skills with commas.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleCancel}
                      >
                        Cancel
                      </Button>
                      
                      <Button
                        type="submit"
                        disabled={addWorkExperienceMutation.isPending}
                      >
                        {addWorkExperienceMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save
                      </Button>
                    </div>
                  </form>
                </Form>
              </TabsContent>
              
              <TabsContent value="education">
                <Form {...educationForm}>
                  <form onSubmit={educationForm.handleSubmit(onEducationSubmit)} className="space-y-6">
                    <div className="space-y-4">
                      <FormField
                        control={educationForm.control}
                        name="school"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>School*</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input placeholder="Ex: University of California, Berkeley" {...field} />
                                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-500" />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={educationForm.control}
                        name="degree"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Degree</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: Bachelor's" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={educationForm.control}
                        name="fieldOfStudy"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Field of study</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: Computer Science" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={educationForm.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Start date*</FormLabel>
                              <FormControl>
                                <Input type="month" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={educationForm.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>End date (or expected)</FormLabel>
                              <FormControl>
                                <Input type="month" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={educationForm.control}
                        name="grade"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Grade</FormLabel>
                            <FormControl>
                              <Input placeholder="Ex: 3.8 GPA" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={educationForm.control}
                        name="activities"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Activities and societies</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Ex: Student Government, Robotics Club, Debate Team"
                                className="min-h-[80px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={educationForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Add a description of notable accomplishments during your education"
                                className="min-h-[120px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleCancel}
                      >
                        Cancel
                      </Button>
                      
                      <Button
                        type="submit"
                        disabled={addEducationMutation.isPending}
                      >
                        {addEducationMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save
                      </Button>
                    </div>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}