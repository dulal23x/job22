import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Header from "@/components/layout/header";
import { useAuth } from "@/hooks/use-auth";

// Pages
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import NetworkPage from "@/pages/network-page";
import JobsPage from "@/pages/jobs-page";
import JobDetailsPage from "@/pages/job-details-page";
import PostJobPage from "@/pages/post-job-page";
import MessagingPage from "@/pages/messaging-page";
import NotificationsPage from "@/pages/notifications-page";
import ProfilePage from "@/pages/profile-page";
import SearchPage from "@/pages/search-page";
import GroupsPage from "@/pages/groups-page";
import EventsPage from "@/pages/events-page";
import HashtagsPage from "@/pages/hashtags-page";
import DiscoverPage from "@/pages/discover-page";
import AddExperiencePage from "@/pages/add-experience-page";
import EditProfilePage from "@/pages/edit-profile-page";
import DesignGalleryPage from "@/pages/design-gallery-page";

function RouterContent() {
  const { user } = useAuth();
  const [location] = useLocation();
  
  // Prevents rendering the layout on authentication page
  const isAuthPage = location === '/auth';
  
  return (
    <>
      {!isAuthPage && <Header />}
      
      <Switch>
        <Route path="/" component={HomePage} />
        <ProtectedRoute path="/feed" component={HomePage} />
        <ProtectedRoute path="/mynetwork" component={NetworkPage} />
        <Route path="/jobs" component={JobsPage} />
        <Route path="/post-job" component={PostJobPage} />
        <ProtectedRoute path="/jobs/view/:id" component={JobDetailsPage} />
        <ProtectedRoute path="/messaging" component={MessagingPage} />
        <ProtectedRoute path="/messaging/:userId" component={MessagingPage} />
        <ProtectedRoute path="/notifications" component={NotificationsPage} />
        <ProtectedRoute path="/profile" component={ProfilePage} />
        <ProtectedRoute path="/profile/:username" component={ProfilePage} />
        <ProtectedRoute path="/in/:username" component={ProfilePage} />
        <Route path="/search" component={SearchPage} />
        <ProtectedRoute path="/groups" component={GroupsPage} />
        <ProtectedRoute path="/events" component={EventsPage} />
        <ProtectedRoute path="/hashtags" component={HashtagsPage} />
        <ProtectedRoute path="/discover" component={DiscoverPage} />
        <ProtectedRoute path="/profile/add-experience" component={AddExperiencePage} />
        <ProtectedRoute path="/profile/edit" component={EditProfilePage} />
        <ProtectedRoute path="/edit-profile" component={EditProfilePage} />
        <Route path="/design-gallery" component={DesignGalleryPage} />
        <Route path="/auth" component={AuthPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <RouterContent />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
